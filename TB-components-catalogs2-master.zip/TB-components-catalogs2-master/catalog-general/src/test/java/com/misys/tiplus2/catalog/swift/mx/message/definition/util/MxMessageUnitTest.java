package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.FileLoader;
import com.misys.tiplus2.catalog.swift.mx.message.definition.MXMessageNamespace;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessage;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessages;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Restriction;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

public class MxMessageUnitTest {

	private static String getValidXML() throws Exception {

		return FileLoader.loadFile("mx-messages.xml");

	}

	private SAXElement parse(String s) throws IOException {
		XMLParser parser = new XMLParser(MXMessageNamespace.getNamespaces());
		Reader reader = new StringReader(s);
		SAXElement saxElement = parser.getSAXElement(reader);
		return saxElement;
	}

	@Test
	public void testMessageDocument() throws Exception {

		SAXElement saxElement = parse(getValidXML());

		MxMessages mxMsgs = (MxMessages) saxElement;

		String act = mxMsgs.getVersion();
		String exp = "1.0";
		assertEquals(exp, act);

		Map<String, MxMessage> messageMap = mxMsgs.getMessageMap();
		int actual = messageMap.size();
		int expected = 17;
		assertEquals(expected, actual);
		
		Map<String, Tag> tagMap = mxMsgs.getTags().getTagMap();
		actual = tagMap.size();
		expected = 278;
		assertEquals(expected, actual);

		for (Entry<String, Tag> entry:tagMap.entrySet()) {
			String key = entry.getKey();
			System.out.println(key);
		}
		MxMessage message = mxMsgs.getMessageById("pacs.008.001.08");
	
		Map<String, Field> fieldMap = message.getFieldMap();
		actual =fieldMap.size();
		expected = 818;
		assertEquals(expected, actual);

		for (Entry<String, Field> entry:fieldMap.entrySet()) {
			Field field = entry.getValue(); 
			String path = field.getPath();
			String tagName = field.getTag();
			String type = field.getType();
			String desc = field.getDescription();
			String mand = field.getMandatory();
			Tag tag = tagMap.get(tagName);

			if (tag != null) {
				String tagType = tag.getType();

				if (tag.getRestriction() != null) {
					Restriction rest = tag.getRestriction();
					String minL = null;
					String maxL = null;
					String pattern = null;
					String enumeration = null;
					String fDgt = null;
					String tDgt = null;
					if (rest.getMinLength() != null) {
						minL = rest.getMinLength().getValue();
					}
					if (rest.getMaxLength() != null) {
						maxL = rest.getMaxLength().getValue();
					}
					if (rest.getPattern() != null) {
						pattern = rest.getPattern().getValue();
					}
					if (rest.getEnumeration() != null) {
						enumeration = rest.getEnumeration().getValue();
					}
					if (rest.getFractionDigits() != null) {
						fDgt = rest.getFractionDigits().getValue();
					}
					if (rest.getTotalDigits() != null) {
						tDgt = rest.getTotalDigits().getValue();
					}
				}
			}
		}
	}

}
