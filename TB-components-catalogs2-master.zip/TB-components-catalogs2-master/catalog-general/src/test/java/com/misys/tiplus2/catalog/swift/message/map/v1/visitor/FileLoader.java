package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import java.io.InputStreamReader;

public class FileLoader {

    public static String loadFile(String fileName) throws Exception {

        ClassLoader loader = FileLoader.class.getClassLoader();
        InputStreamReader in = new InputStreamReader(loader.getResourceAsStream(fileName));
        StringBuffer stringBuf = new StringBuffer();
        char[] charBuf = new char[4096];
        int len;

        while ((len = in.read(charBuf)) != -1) {
            stringBuf.append(charBuf, 0, len);
        }
        in.close();

        return stringBuf.toString();
    }
}
