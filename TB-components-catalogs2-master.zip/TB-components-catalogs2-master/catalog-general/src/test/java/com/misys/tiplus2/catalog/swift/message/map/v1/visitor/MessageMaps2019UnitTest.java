package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.map.MessageMapNamespace;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMaps;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

public class MessageMaps2019UnitTest {

    private static String getValidXML() throws Exception {

        return FileLoader.loadFile("fbti-generic-2021.xml");

    }

    private SAXElement parse(String s) throws IOException {
        XMLParser parser = new XMLParser(MessageMapNamespace.getNamespaces());
        Reader reader = new StringReader(s);
        SAXElement saxElement = parser.getSAXElement(reader);
        return saxElement;
    }

    @Test
    public void testMessageMaps() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        String act = maps.getVersion();
        String exp = "2021";
        assertEquals(exp, act);
        List<MessageMap> list = maps.getMessageMaps();
        int actual = list.size();
        int expected = 142;
        assertEquals(expected, actual);
    }

    @Test
    public void testMessageMapEnvelope() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        List<MessageMap> list = maps.getMessageMaps();
        MessageMap envelope_b1 = list.get(0);
        MessageMap envelope_b2I = list.get(1);
        MessageMap envelope_b2O = list.get(2);
        MessageMap envelope_b3 = list.get(3);
        MessageMap envelope_b5 = list.get(4);

        String expected = "MT192";
        String actual = envelope_b5.getName();
        assertEquals(expected, actual);

        expected = "ReceiverAddress";
        actual = envelope_b1.getHeaderFields().get(2).getTag();
        assertEquals(expected, actual);

    }

    @Test
    public void testMessageMap() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        MessageMap mt103 = maps.getMessageByName("MT103");

        List<HeaderField> listOfHeaderFields = mt103.getHeaderFields();
        List<DataField> listOfDataFields = mt103.getDataFields();
        List<DataBlock> listOfDataBlocks = mt103.getDataBlocks();

        int actual = listOfHeaderFields.size();
        int expected = 0;
        assertEquals(expected, actual);

        actual = listOfDataFields.size();
        expected = 12;
        assertEquals(expected, actual);

        actual = listOfDataBlocks.size();
        expected = 3;
        assertEquals(expected, actual);

        for (DataTypeChoice choice : mt103.getDataTypeChoices()) {
            switch (choice.getChosen()) {
            case DATAFIELD:
                String tag = choice.getDataField().getTag();
                System.out.println("field tag: " + tag);
                break;
            case DATABLOCK:
                String name = choice.getDataBlock().getName();
                System.out.println("block name: " + name);
                break;
            case MARKERFIELD:
                String t = choice.getDataBlock().getName();
                System.out.println("empty tag: " + t);
                break;
            default:
                break;
            }
        }
    }

    @Test
    public void testMessageMapEmptyField() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        List<MessageMap> list = maps.getMessageMaps();
        MessageMap mt760 = list.get(52);
        String expected = "MT760";
        String actual = mt760.getName();
        assertEquals(expected, actual);

        MarkerField field = mt760.getMarkerField("15A", "A");
        expected = "15A";
        actual = field.getTag();
        assertEquals(expected, actual);

        List<MarkerField> eFs = mt760.getMarkerFields();
        assertEquals(3, eFs.size());

        for (DataTypeChoice choice : mt760.getDataTypeChoices()) {
            switch (choice.getChosen()) {
            case DATAFIELD:
                String tag = choice.getDataField().getTag();
                System.out.println("field tag: " + tag);
                break;
            case MARKERFIELD:
                String t = choice.getMarkerField().getTag();
                System.out.println("empty tag: " + t);
                break;
            default:
                break;
            }
        }
    }

    @Test
    public void testMessageMapIncludeMessage() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        MessageMap mt798Score = maps.getMessageByName("MT798Score");

        List<DataField> listOfDataFields = mt798Score.getDataFields();
        List<Embedded> listIncludeMessages = mt798Score.getEmbeddedMessages();

        assertEquals(4, listOfDataFields.size());

        Embedded includeMessage = listIncludeMessages.get(1);

        assertEquals("Details", includeMessage.getName());
    }
}
