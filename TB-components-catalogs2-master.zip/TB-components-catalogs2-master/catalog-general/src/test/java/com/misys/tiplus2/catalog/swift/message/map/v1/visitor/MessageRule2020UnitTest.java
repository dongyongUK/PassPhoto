package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.rule.MessageRuleNamespace;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.MessageRules;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Statement;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

public class MessageRule2020UnitTest {

    private static String getRulesXML() throws Exception {

        return FileLoader.loadFile("swift-message-rules-2020.xml");

    }

    private SAXElement parse(String s) throws IOException {
        XMLParser parser = new XMLParser(MessageRuleNamespace.getNamespaces());
        Reader reader = new StringReader(s);
        SAXElement saxElement = parser.getSAXElement(reader);
        return saxElement;
    }

    @Test
    public void testMessageDocument() throws Exception {

        SAXElement saxElement = parse(getRulesXML());

        MessageRules msgRules = (MessageRules) saxElement;


        List<Construct> messageRuleList = msgRules.getMessageRuleList();

        int size = messageRuleList.size();

        assertEquals(4, size);

        Construct construct1 = messageRuleList.get(0);
        
        Statement statement1 = construct1.getStatement();
        
        Construct const2 = construct1.getConstruct();
        
        Procedure proc1 = construct1.getProcedure();
        
        List<Component> comps = statement1.getComponents();
        
        size = comps.size();
        
        
    }

}
