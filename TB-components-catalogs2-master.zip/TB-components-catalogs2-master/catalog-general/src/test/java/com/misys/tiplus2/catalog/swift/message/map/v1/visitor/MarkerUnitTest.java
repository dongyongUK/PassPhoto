package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Marker;

public class MarkerUnitTest {

    @Test
    public void testGetName() {
        Marker marker = new Marker();

        marker.setTag("15A");

        String expected = "15A";
        String actual = marker.getName();
        assertEquals(expected, actual);
    }

}
