package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.definition.FinMessageNamespace;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessages;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.message.map.MessageMapNamespace;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMaps;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

public class FieldCheckUnitTest {

   
    private SAXElement parse(String s) throws IOException {
        XMLParser parser = new XMLParser(MessageMapNamespace.getNamespaces());
        Reader reader = new StringReader(s);
        SAXElement saxElement = parser.getSAXElement(reader);
        return saxElement;
    }
    
    private SAXElement parseFin(String s) throws IOException {
        XMLParser parser = new XMLParser(FinMessageNamespace.getNamespaces());
        Reader reader = new StringReader(s);
        SAXElement saxElement = parser.getSAXElement(reader);
        return saxElement;
    }

    @Test
    public void testMessageMaps() throws Exception {

        SAXElement saxElement = parse(FileLoader.loadFile("fbti-generic-2021.xml"));
        MessageMaps maps = (MessageMaps) saxElement;
        List<MessageMap> list = maps.getMessageMaps();
        
        SAXElement saxElement2 = parseFin(FileLoader.loadFile("fin-message-2021.xml"));
        FinMessages fmsgs = (FinMessages) saxElement2;
        Tags tags = fmsgs.getTags();
        Map<String, Tag> tagMap = tags.getTagsByName();
        
        int k=0;
        for (MessageMap mm:list){
            List<DataField>  dfList = mm.getDataFields();
            String message= mm.getMessage();
            System.out.println("Message:"+message);
            if (isDigit(message))
            for (DataField df: dfList){
                String tagName= df.getTag();
                Tag tag =tagMap.get(tagName);
                if (tag==null){
                    System.out.println("Missing tag: "+tagName);
                    k++;
                }
            }
         }
      
        System.out.println("Total messages: "+list.size());
        System.out.println("Total fields: "+tagMap.size());
        System.out.println("Total missing fields: "+k);
        
    }

    private boolean isDigit(String term) {
        
        boolean result = false;
        
        try {
            Integer.parseInt(term);
            result = true;
        } catch (Exception e){
            ;
        }
        return result;
    }
}
