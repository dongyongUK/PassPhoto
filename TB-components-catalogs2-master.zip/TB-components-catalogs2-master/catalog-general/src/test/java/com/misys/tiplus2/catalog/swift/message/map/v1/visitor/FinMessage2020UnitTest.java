package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.definition.FinMessageNamespace;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Block;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessage;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessages;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Options;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Sequence;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Variant;
import com.misys.tiplus2.catalog.swift.message.definition.v1.groups.FieldTypeChoice;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

public class FinMessage2020UnitTest {

    private static String getValidXML() throws Exception {

        return FileLoader.loadFile("fin-message-2021.xml");

    }

    private SAXElement parse(String s) throws IOException {
        XMLParser parser = new XMLParser(FinMessageNamespace.getNamespaces());
        Reader reader = new StringReader(s);
        SAXElement saxElement = parser.getSAXElement(reader);
        return saxElement;
    }

    @Test
    public void testMessageDocument() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        FinMessages fmsgs = (FinMessages) saxElement;

        String act = fmsgs.getVersion();
        String exp = "1.0";
        assertEquals(exp, act);

        List<FinMessage> finMessageList = fmsgs.getFinMessageList();
        Tags tags = fmsgs.getTags();

        int actual = finMessageList.size();
        int expected = 2;
        assertEquals(expected, actual);

        actual = finMessageList.get(0).getBlockList().size();
        expected = 5;
        assertEquals(expected, actual);

        actual = tags.getTagsByName().size();
        expected = 245;
        assertEquals(expected, actual);

        act = tags.findTagByName("45A").getFormat();
        exp = "100*65z";
        assertEquals(exp, act);

        Block block2 = finMessageList.get(0).getBlockList().get(1);
        actual = block2.getVariants().size();
        expected = 2;
        assertEquals(expected, actual);

        Block block4 = finMessageList.get(0).getBlockList().get(3);

        actual = block4.getVariants().size();
        expected = 113;
        assertEquals(expected, actual);
        
        Variant mt760 = block4.getVariants().get("760");
        
        List<FieldTypeChoice> listOfChoice = mt760.getFieldTypeChoices();
        
        for (FieldTypeChoice choice:listOfChoice) {
            
            switch (choice.getChosen()) {
            case FIELD:
                Field field = choice.getField();
                String tag = field.getTag();
                break;
            case MARKER:
                choice.getMarker();
                break;
            case REPEAT:
                choice.getRepeat();
                break;
            case OPTIONS:
                Options options = choice.getOptions();
                for (Field f:options.getFields()) {
                    //String fKey = f.getKey();
                    String ftag =f.getTag();
                }
                break;
            case SEQUENCE:
               Sequence sequence = choice.getSequence();
               for (FieldTypeChoice schoice:sequence.getFieldTypeChoices()) {
                   switch (schoice.getChosen()) {
                   case FIELD:
                       Field sfield = schoice.getField();
                       String stag = sfield.getTag();
                       break;
                   case MARKER:
                       schoice.getMarker();
                       break;
                   case REPEAT:
                       schoice.getRepeat();
                       break;
                   case OPTIONS:
                       Options soptions = schoice.getOptions();
                       for (Field f:soptions.getFields()) {
                           //String fKey = f.getKey();
                           String ftag =f.getTag();
                       }
                       break;
                   default:
                       break;
                   }
               }
                break;
            default:
                break;
            }
        }
    }

}
