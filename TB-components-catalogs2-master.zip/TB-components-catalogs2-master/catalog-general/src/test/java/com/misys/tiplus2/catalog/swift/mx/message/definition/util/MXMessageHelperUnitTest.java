package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class MXMessageHelperUnitTest {

	@Test
	public void testExtractFieldAtt() {
		String field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf.|Strd[n].|Invcr\" tag=\"|Nm\" description=\"Name\" type=\"string\" />";
		String actual =  MXMessageHelper.extractFieldAtt("path",field);
		String expected = "Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf.|Strd[n].|Invcr";
		assertEquals(expected, actual);
		
		field = "<field tag=\"|Nm\" description=\"Name\" type=\"string\" />";
		actual =  MXMessageHelper.extractFieldAtt("path",field);
		assertNull(actual);
		
		field = "<field path=\"\" tag=\"|Nm\" description=\"Name\" type=\"string\" />";
		actual =  MXMessageHelper.extractFieldAtt("path",field);
		assertTrue(actual.isEmpty());
		
		field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf.|Strd[n].|Invcr\" tag=\"|Nm\" description=\"Name\" type=\"string\" />";
		actual =  MXMessageHelper.extractFieldAtt("tag",field);
		expected = "|Nm";
		assertEquals(expected, actual);
	}

	@Test
	public void testExtractFirstRepeat() {
		String path = "Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf.|Strd[n].|Invcr";
		String actual = MXMessageHelper.extractFirstRepeat(path);
		String expected="n";
		assertEquals(expected, actual);
		
		path = "Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf.|Strd.|Invcr";
		actual = MXMessageHelper.extractFirstRepeat(path);
		assertNull(actual);
		
		path = "Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf[12].|Strd.|Invcr";
		actual = MXMessageHelper.extractFirstRepeat(path);
		expected="12";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testReformatField_tag() {
		
		String field = "<field path=\"Document.FIToFICstmrCdtTrf.GrpHdr\" tag=\"MsgId\" description=\"MessageIdentification\" type=\"string\" mandatory=\"true\" />";
		String path = MXMessageHelper.extractFieldAtt("path",field);
		String tag = MXMessageHelper.extractFieldAtt("tag",field);
		String actual = MXMessageHelper.reformatField(field, path, tag, null, null);
		String expected = field;
		assertEquals(expected, actual);
		
		field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.Dbtr.|PstlAdr\" tag=\"|AdrLine[3]\" description=\"AddressLine\" type=\"string\" />";
		path = MXMessageHelper.extractFieldAtt("path",field);
		tag = MXMessageHelper.extractFieldAtt("tag",field);
		actual = MXMessageHelper.reformatField(field, path, tag, null,null);
	    assertTrue(actual.contains("<block name=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.Dbtr.|PstlAdr\" repeat=\"3\" >"));
	    assertTrue(actual.contains("<field path=\"\" tag=\"|AdrLine\" description=\"AddressLine\" type=\"string\" />"));
	    assertTrue(actual.contains("</block>"));
	    
	}
	
	@Test
	public void testReformatField_path_first() {
		
		String field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Agt.FinInstnId\" tag=\"|BICFI\" description=\"BICFI\" type=\"string\" />";
		String path = MXMessageHelper.extractFieldAtt("path",field);
		String tag = MXMessageHelper.extractFieldAtt("tag",field);
		String postPath = "Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Agt.FinInstnId";
		String actual = MXMessageHelper.reformatField(field, path, tag, null, postPath);
		assertTrue(actual.contains("<block name=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf\" repeat=\"n\" >"));
		assertTrue(actual.contains("<field path=\"Agt.FinInstnId\" tag=\"|BICFI\" description=\"BICFI\" type=\"string\" />"));
		
	}
	
	@Test
	public void testReformatField_path_within() {
		
		String field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Agt.FinInstnId\" tag=\"|BICFI\" description=\"BICFI\" type=\"string\" />";
		String path = MXMessageHelper.extractFieldAtt("path",field);
		String tag = MXMessageHelper.extractFieldAtt("tag",field);
		String prePath = path;
		String postPath = path;
		String actual = MXMessageHelper.reformatField(field, path, tag, prePath, postPath);
		assertFalse(actual.contains("<block name=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf\" repeat=\"n\" >"));
		assertTrue(actual.contains("<field path=\"Agt.FinInstnId\" tag=\"|BICFI\" description=\"BICFI\" type=\"string\" />"));
	}

	@Test
	public void testReformatField_path_last() {
		
		String field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Agt.FinInstnId\" tag=\"|BICFI\" description=\"BICFI\" type=\"string\" />";
		String path = MXMessageHelper.extractFieldAtt("path",field);
		String tag = MXMessageHelper.extractFieldAtt("tag",field);
		String prePath = path;
		String postPath = "Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|Address";
		String actual = MXMessageHelper.reformatField(field, path, tag, prePath, postPath);
		assertFalse(actual.contains("<block name=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf\" repeat=\"n\" >"));
		assertTrue(actual.contains("<field path=\"Agt.FinInstnId\" tag=\"|BICFI\" description=\"BICFI\" type=\"string\" />"));
		assertTrue(actual.contains("</block>"));
	}
	
	@Test
	public void testReformatField_netted_path_first() {
		
		String field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Agt.FinInstnId.|PstlAdr\" tag=\"|AdrLine[3]\" description=\"AddressLine\" type=\"string\" />";
		String path = MXMessageHelper.extractFieldAtt("path",field);
		String tag = MXMessageHelper.extractFieldAtt("tag",field);
		String postPath = path;
		String actual = MXMessageHelper.reformatField(field, path, tag, null, postPath);
		assertTrue(actual.contains("<block name=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf\" repeat=\"n\" >"));
		assertTrue(actual.contains("<block name=\"Agt.FinInstnId.|PstlAdr\" repeat=\"3\" >"));
		assertTrue(actual.contains("<field path=\"\" tag=\"|AdrLine\" description=\"AddressLine\" type=\"string\" />"));
		assertTrue(actual.contains("</block>"));
	}
	
	@Test
	public void testReformatField_netted_path1() {
	
		// first in block
		String field = "<field path=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf.|Strd[n].|RfrdDocInf[n].|Tp.CdOrPrtry\" tag=\"Cd\" description=\"Code\" type=\"string\" />";
		String path = MXMessageHelper.extractFieldAtt("path",field);
		String tag = MXMessageHelper.extractFieldAtt("tag",field);
		String prePath="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf";
		String postPath =path;
		String actual = MXMessageHelper.reformatField(field, path, tag,prePath, postPath);
		assertTrue(actual.contains("<block name=\"Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|RmtInf.|Strd\" repeat=\"n\" >"));
		assertTrue(actual.contains("<field path=\"|Tp.CdOrPrtry\" tag=\"Cd\" description=\"Code\" type=\"string\" />"));
		
		int i=100;
	}
}
