package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.definition.FinMessageNamespace;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Block;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessage;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessages;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tags;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

public class FinMessage2018UnitTest {

    private static String getValidXML() throws Exception {

        return FileLoader.loadFile("fin-message-2018.xml");

    }

    private SAXElement parse(String s) throws IOException {
        XMLParser parser = new XMLParser(FinMessageNamespace.getNamespaces());
        Reader reader = new StringReader(s);
        SAXElement saxElement = parser.getSAXElement(reader);
        return saxElement;
    }

    @Test
    public void testMessageDocument() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        FinMessages fmsgs = (FinMessages) saxElement;

        String act = fmsgs.getVersion();
        String exp = "1.0";
        assertEquals(exp, act);

        List<FinMessage> finMessageList = fmsgs.getFinMessageList();
        Tags tags = fmsgs.getTags();

        int actual = finMessageList.size();
        int expected = 2;
        assertEquals(expected, actual);

        actual = finMessageList.get(0).getBlockList().size();
        expected = 5;
        assertEquals(expected, actual);

        actual = tags.getTagsByName().size();
        expected = 242;
        assertEquals(expected, actual);

        act = tags.findTagByName("45A").getFormat();
        exp = "100*65z";
        assertEquals(exp, act);

        Block block2 = finMessageList.get(0).getBlockList().get(1);
        actual = block2.getVariants().size();
        expected = 2;
        assertEquals(expected, actual);

        Block block4 = finMessageList.get(0).getBlockList().get(3);

        actual = block4.getVariants().size();
        expected = 108;
        assertEquals(expected, actual);

    }

}
