package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import org.junit.Test;

public class XMLPrettyPrinterUnitTest {

	@Test
	public void testPrettyPrint() {
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
	"<root><tag><nested>hello</nested></tag></root>";
		String actual = XMLPrettyPrinter.prettyPrint(xml);
		
		System.out.println(actual);
	}

}
