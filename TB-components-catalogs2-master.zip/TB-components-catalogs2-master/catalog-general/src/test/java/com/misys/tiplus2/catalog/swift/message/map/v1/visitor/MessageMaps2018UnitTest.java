package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.map.MessageMapNamespace;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMaps;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

public class MessageMaps2018UnitTest {

    private static String getValidXML() throws Exception {

        return FileLoader.loadFile("fbti-generic-2018.xml");

    }

    private SAXElement parse(String s) throws IOException {
        XMLParser parser = new XMLParser(MessageMapNamespace.getNamespaces());
        Reader reader = new StringReader(s);
        SAXElement saxElement = parser.getSAXElement(reader);
        return saxElement;
    }

    @Test
    public void testMessageMaps() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        String act = maps.getVersion();
        String exp = "2018";
        assertEquals(exp, act);
        List<MessageMap> list = maps.getMessageMaps();
        int actual = list.size();
        int expected = 136;
        assertEquals(expected, actual);
    }

    @Test
    public void testMessageMapEnvelope() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        List<MessageMap> list = maps.getMessageMaps();
        MessageMap envelope_b1 = list.get(0);
        MessageMap envelope_b2I = list.get(1);
        MessageMap mt192 = list.get(4);

        String expected = "MT192";
        String actual = mt192.getName();
        assertEquals(expected, actual);

        expected = "ReceiverAddress";
        actual = envelope_b1.getHeaderFields().get(2).getTag();
        assertEquals(expected, actual);
    }

    @Test
    public void testMessageMap() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        MessageMap mt103 = maps.getMessageByName("MT103");

        List<HeaderField> listOfHeaderFields = mt103.getHeaderFields();
        List<DataField> listOfDataFields = mt103.getDataFields();
        List<DataBlock> listOfDataBlocks = mt103.getDataBlocks();

        int actual = listOfHeaderFields.size();
        int expected = 0;
        assertEquals(expected, actual);

        actual = listOfDataFields.size();
        expected = 12;
        assertEquals(expected, actual);

        actual = listOfDataBlocks.size();
        expected = 3;
        assertEquals(expected, actual);

        for (DataTypeChoice choice : mt103.getDataTypeChoices()) {
            switch (choice.getChosen()) {
            case DATAFIELD:
                String tag = choice.getDataField().getTag();
                System.out.println("tag: " + tag);
                break;
            case DATABLOCK:
                String name = choice.getDataBlock().getName();
                System.out.println("name: " + name);
                break;
            default:
                break;
            }
        }
    }

    @Test
    public void testMessageMapIncludeMessage() throws Exception {

        SAXElement saxElement = parse(getValidXML());

        MessageMaps maps = (MessageMaps) saxElement;
        MessageMap mt798Score = maps.getMessageByName("MT798Score");

        String expectedIndlude = "header-fields";
        String include = mt798Score.getInclude();
        assertEquals(expectedIndlude, include);

        List<DataField> listOfDataFields = mt798Score.getDataFields();
        List<Embedded> listIncludeMessages = mt798Score.getEmbeddedMessages();

        assertEquals(4, listOfDataFields.size());

        Embedded includeMessage = listIncludeMessages.get(1);

        assertEquals("Details", includeMessage.getName());
    }
}
