package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Enumeration;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.FractionDigits;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MaxLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MinLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Pattern;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Restriction;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.TotalDigits;
import com.misys.tiplus2.foundations.xml.XMLException;

import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XMLSchemaNode;
import oracle.xml.parser.schema.XSDComplexType;
import oracle.xml.parser.schema.XSDException;
import oracle.xml.parser.schema.XSDNode;
import oracle.xml.parser.schema.XSDSimpleType;
import oracle.xml.parser.v2.XMLElement;
import oracle.xml.parser.v2.XMLNodeList;

/**
 * 
 * @author DaiD1
 *
 */
public class MXSchemaToMXMessageConverter {

	XMLSchemaNode rootNode;
	final static String XS = "xs:";
	private String preName;
	private String extension;
	private Node extensionElement;
	private String attribute;
	private String elmDescription;
	private boolean isChoice;
	private String msgId;

	public String convertMXSchema(XMLSchema schema) {

		String result = null;
		try {
			@SuppressWarnings("unchecked")
			Hashtable<String, XMLSchemaNode> schemaTable = schema.getXMLSchemaNodeTable();

			StringBuilder outputBuilder = new StringBuilder();
			List<String> fieldList = new ArrayList<String>();

			for (String key : schemaTable.keySet()) {
				if (key.contains(":iso:20022:")) {
					XMLSchemaNode schemaNode = schemaTable.get(key);
					if (rootNode == null) {
						rootNode = schemaNode;
					}
					msgId = SchemaConverterHelper.getMessageId(schema);
					String msgHd = "\r\n\t<mx-message message-id=\"" + msgId + "\" >";
					outputBuilder.append(msgHd);
					fieldList.add(msgHd);

					XSDNode[] elemSet = schemaNode.getElementSet();
					Map<String, Tag> tagMap = new HashMap<String, Tag>();

					parseXSDNodes(elemSet, XSDType.Element, tagMap, outputBuilder, fieldList);

					outputBuilder.append("\r\n\t</mx-message>");
					fieldList.add("\r\n\t</mx-message>");

					// String allField = printFields(fieldList);
					// print out tags
					SchemaConverterHelper.printTags(tagMap, outputBuilder);
					result = outputBuilder.toString();
					break;
				}
			}
		} catch (XSDException e) {
			System.out.println("XSDException: " + e.getMessage());
		} catch (MalformedURLException e) {
			System.out.println("MalformedURLException: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
		return result;
	}

	public String convertMXSchema(XMLSchema schema, Map<String, Tag> tagMap) {

		String result = null;
		try {
			@SuppressWarnings("unchecked")
			Hashtable<String, XMLSchemaNode> schemaTable = schema.getXMLSchemaNodeTable();

			StringBuilder outputBuilder = new StringBuilder();
			List<String> fieldList = new ArrayList<String>();
			for (String key : schemaTable.keySet()) {
				if (key.contains(":iso:20022:")) {
					XMLSchemaNode schemaNode = schemaTable.get(key);
					if (rootNode == null) {
						rootNode = schemaNode;
					}
					msgId = SchemaConverterHelper.getMessageId(schema);
					String msgH = "\r\n\t<mx-message message-id=\"" + msgId + "\" >";

					fieldList.add(msgH);
					outputBuilder.append(msgH);

					XSDNode[] elemSet = schemaNode.getElementSet();
					parseXSDNodes(elemSet, XSDType.Element, tagMap, outputBuilder, fieldList);

					outputBuilder.append("\r\n\t</mx-message>");
					fieldList.add("\r\n\t</mx-message>");

					result = outputBuilder.toString();
					break;
				}
			}
		} catch (XSDException e) {
			// System.out.println("XSDException: " + e.getMessage());
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// System.out.println("MalformedURLException: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println("Exception: " + e.getMessage());
		}
		return result;
	}

	private void parseXSDNodes(XSDNode[] nodeArray, XSDType type, Map<String, Tag> tagMap,
			StringBuilder outputBuilder, List<String> fieldList) throws Exception {

		for (XSDNode node : nodeArray) {
			String name = node.getName();
			Node elmDom = (Node) node.getDomNode();
			XMLNodeList elmList = new XMLNodeList();
			elmList.addNode(elmDom);

			for (int count = 0; count < elmList.getLength(); count++) {
				Node elmNode = elmList.item(count);
				String elmNodeName = elmNode.getNodeName();
				preName = null;
				elmDescription = null;
				parseElement(elmNode, type, null, null,null,tagMap, outputBuilder, fieldList);
			}
		}

	}

	private void parseElement(Node element, XSDType type, String path,String types, String descps, Map<String, Tag> tagMap,
			StringBuilder outputBuilder, List<String> fieldList) throws Exception {

		if (element.getNodeType() == Node.ELEMENT_NODE) {

			String elementName = null;
			String elementType = null;
			String base = null;
			String minOccurs = null;
			String maxOccurs = null;

			String rest_minLength = null;
			String rest_maxLength = null;
			String rest_enumeration = null;
			String rest_fractionDigits = null;
			String rest_totalDigits = null;
			String rest_pattern = null;

			String name_desc = null;

			String nn = element.getNodeName();
			if (nn.startsWith(XS)) {
				nn = nn.substring(3);
			}

			switch (nn) {
			case "element":

				if (element.hasAttributes()) {
					// get attributes names and values
					NamedNodeMap nodeMap = element.getAttributes();
					for (int i = 0; i < nodeMap.getLength(); i++) {
						Node node = nodeMap.item(i);
						String attName = node.getNodeName();
						String attVal = node.getNodeValue();
						ElementAttribute elementAtt = ElementAttribute.valueOf(attName);
						switch (elementAtt) {
						case name:
							elementName = attVal;
							break;
						case type:
							elementType = attVal;
							break;
						case minOccurs:
							// In all the MX schema minOccurs is either "0" or "1" only
							// if a node is optional, then all of it's children will be optional
							if (attVal != null && "0".equals(attVal.trim())) {
								minOccurs = attVal;
							}
							break;
						case maxOccurs:
							// when maxOccurs > 1, then it is repeated field
							if (attVal != null && !"1".equals(attVal.trim())) {
								maxOccurs = attVal;
							}
							break;
						default:
							break;
						}
					}

					if (elementName != null) {
					    if (isChoice) {
					        elementName = "?" + elementName;
					        isChoice=false;
					    }
						if ("0".equals(minOccurs)) {
							elementName = "|" + elementName;
						}

						if (maxOccurs != null && !maxOccurs.trim().equals("1")) {
							if ("unbounded".equals(maxOccurs.trim())) {
								elementName = elementName + "[n]";
							} else {
								elementName = elementName + "[" + maxOccurs + "]";
							}
						}
						path = (path == null) ? elementName : path + "." + elementName;
						types= (types==null)? elementType:types +"."+elementType;
					}

				}

				// set description from annotation.document
				if (element.hasChildNodes()) {
					NodeList annList = element.getChildNodes();
					for (int count = 0; count < annList.getLength(); count++) {
						Node annNode = annList.item(count);
						String annName = annNode.getNodeName();
						if (annName.startsWith(XS)) {
							annName = annName.substring(3);
						}
						if ("annotation".equals(annName)) {
							if (annNode.hasChildNodes()) {
								for (int ct = 0; ct < annNode.getChildNodes().getLength(); ct++) {
									Node docNode = annNode.getChildNodes().item(ct);
									String docName = docNode.getNodeName();
									if (docName.startsWith(XS)) {
										docName = docName.substring(3);
									}
									if ("documentation".equals(docName)) {
										String txtCont = docNode.getTextContent();
										NamedNodeMap atts = docNode.getAttributes();
										Node srcNode = atts.getNamedItem("source");
										if ("Name".equals(srcNode.getNodeValue())) {
											name_desc = txtCont;
											elmDescription = name_desc;
											
											if (descps==null) {
	                                            descps = elmDescription;
	                                        } else {
	                                           // if (!descps.equals(elmDescription) && !descps.endsWith("."+elmDescription)) {
	                                            if (!descps.equals(elmDescription)) {
	                                                descps= descps +"."+elmDescription; 
	                                            }
	                                        }
										}
									}
								}
							}
						}
					}
				}

				if (elementType != null) {
					processType(elementName, path,types,descps, elementType, tagMap, outputBuilder, fieldList);
				}

				break;
			case "restriction":
				if (type == XSDType.SimpleType) {
					elementName = "base";
					// elementType = path;
					if (element.hasAttributes()) {
						NamedNodeMap nodeMap = element.getAttributes();
						Node baseNode = nodeMap.getNamedItem(elementName);
						String attVal = baseNode.getNodeValue();
						if (attVal.startsWith(XS)) {
							attVal = attVal.substring(3);
						}
						base = attVal;
					}

					// set restriction item's values
					StringBuilder enumBuilder = new StringBuilder();
					if (element.hasChildNodes()) {
						NodeList restList = element.getChildNodes();
						for (int count = 0; count < restList.getLength(); count++) {
							Node restNode = restList.item(count);
							String restName = restNode.getNodeName();
							if (restName.startsWith(XS)) {
								restName = restName.substring(3);
							}
							switch (restName) {
							case "minLength":
								rest_minLength = restNode.getAttributes().getNamedItem("value").getNodeValue();
								break;
							case "maxLength":
								rest_maxLength = restNode.getAttributes().getNamedItem("value").getNodeValue();
								break;
							case "pattern":
								rest_pattern = restNode.getAttributes().getNamedItem("value").getNodeValue();
								break;
							case "fractionDigits":
								rest_fractionDigits = restNode.getAttributes().getNamedItem("value").getNodeValue();
								break;
							case "totalDigits":
								rest_totalDigits = restNode.getAttributes().getNamedItem("value").getNodeValue();
								break;
							case "enumeration":
								String eV = restNode.getAttributes().getNamedItem("value").getNodeValue();
								enumBuilder.append(eV).append("|");
								break;
							default:
								break;
							}
						}
					}

					if (enumBuilder.length() > 1) {
						rest_enumeration = enumBuilder.toString();
						if (rest_enumeration.endsWith("|")) {
							rest_enumeration = rest_enumeration.substring(0, rest_enumeration.length() - 1);
						}
						//  change  base from string to enum
						base="enum";  
					}

				}
				break;
			case "extension":
				// SimpleContext's extension
				if (element.hasAttributes()) {
					NamedNodeMap nodeMap = element.getAttributes();
					Node baseNode = nodeMap.getNamedItem("base");
					String attVal = baseNode.getNodeValue();
					if (attVal.startsWith(XS)) {
						attVal = attVal.substring(3);
					}
					elementType = attVal;
					int indx = path.lastIndexOf(".");
					extension = path.substring(indx + 1);
					extensionElement = element;
					//types = types + "."+ elementType;
					processType(elementName, path, types, descps, elementType, tagMap, outputBuilder, fieldList);
				}

				break;
			case "attribute":
				// Attribute from extension
				NamedNodeMap nodeMap = element.getAttributes();
				for (int i = 0; i < nodeMap.getLength(); i++) {
					Node node = nodeMap.item(i);
					String attName = node.getNodeName();
					String attVal = node.getNodeValue();
					ElementAttribute eAtt = ElementAttribute.valueOf(attName);
					switch (eAtt) {
					case name:
						elementName = attVal;
						attribute = attVal;
						break;
					case type:
						elementType = attVal;
						break;
					case use:
						if ("required".equals(attVal.trim())) {
							minOccurs = "1";
						}
						break;
					default:
						break;
					}
				}

				if (elementType != null) {
					processType(elementName, path, types,descps, elementType, tagMap, outputBuilder, fieldList);
				}
				break;
			default:
				break;
			}

			if (!printSimpleType(type, path, types, descps,base, rest_minLength, rest_maxLength, rest_enumeration,
					rest_fractionDigits, rest_totalDigits, rest_pattern, tagMap, outputBuilder, fieldList)) {

				// process nodes which are not "element" and " restriction", such as sequence,
				// simpleContent, annotation and etc.
				if (!"element".equals(nn) && !"extension".equals(nn)  || elementType == null) {
					if (type!=XSDType.SimpleType) {
						procChildren(element, type, path, types,descps,tagMap, outputBuilder, fieldList, elementName);
					}
				}
			}
		}
	}

	private void procChildren(Node element, XSDType type, String path, String types, String descps,  Map<String, Tag> tagMap,
			StringBuilder outputBuilder, List<String> fieldList, String elementName) throws Exception {
		if (element.hasChildNodes()) {
			NodeList nodeList = element.getChildNodes();
			for (int count = 0; count < nodeList.getLength(); count++) {
				Node aNode = nodeList.item(count);
				String aNodeName = aNode.getNodeName();
				preName = elementName;
				if (!"#text".equals(aNodeName)) {
					parseElement(aNode, type, path, types, descps, tagMap, outputBuilder, fieldList);
				}
			}
		}
	}

	private void processType(String elementName, String path, String types, String descps, String elementType, Map<String, Tag> tagMap,
			StringBuilder outputBuilder, List<String> fieldList) throws Exception {
		XSDType type;
		Object ob = rootNode.getComplexTypeTable().get(elementType);
		if (ob == null) {
			ob = rootNode.getSimpleTypeTable().get(elementType);
		}

		if (ob != null) {
			XSDNode xsdNode = (XSDNode) ob;
			String xsdNodeName = xsdNode.getName();
			if (xsdNodeName.startsWith(XS)) {
				xsdNodeName = xsdNodeName.substring(3);
			}
			if (ob instanceof XSDComplexType) {
				type = XSDType.ComplexType;
			} else if (ob instanceof XSDSimpleType) {
				type = XSDType.SimpleType;
			} else {
				type = XSDType.Element;
			}

			XMLElement xmlElm = xsdNode.getDomNode();
			if (xmlElm != null && xmlElm.hasChildNodes()) {
				NodeList nodeList = xmlElm.getChildNodes();
				for (int count = 0; count < nodeList.getLength(); count++) {
					Node aNode = nodeList.item(count);
					String aNodeName = aNode.getNodeName();
					if (!aNodeName.endsWith("annotation") && !aNodeName.equals("#text")) {
						preName = (extension == null) ? elementName : extension;
						if (aNodeName.endsWith("choice")) {
						    isChoice=true;
						}
						parseElement(aNode, type, path,types,descps,tagMap, outputBuilder, fieldList);
					}
				}
			}
		}
	}

	private boolean printSimpleType(XSDType type, String path,String types, String descps, String base, String rest_minLength,
			String rest_maxLength, String rest_enumeration, String rest_fractionDigits, String rest_totalDigits,
			String rest_pattern, Map<String, Tag> tagMap, StringBuilder outputBuilder, List<String> fieldList)
			throws Exception {

		boolean result = false;
		// print out
		switch (type) {
		case Element:
			/*
			 * if (elementName != null) { System.out.print("\r\nname=" + elementName);
			 * outputBuilder.append("\r\nname=").append(elementName); } if (elementType !=
			 * null) { System.out.print("\t\ttype=" + elementType);
			 * outputBuilder.append("\t\ttype=").append(elementType); }
			 */
			break;
		case ComplexType:
			/*
			 * if (elementName != null) { System.out.print("\r\nname=" + elementName);
			 * outputBuilder.append("\r\nname=").append(elementName); } if (elementType !=
			 * null) { System.out.print("\t\ttype=" + elementType);
			 * outputBuilder.append("\t\ttype=").append(elementType); }
			 */
			break;
		case SimpleType:
			if (path != null && base != null) {
				if (attribute == null) {
					StringBuilder fieldBuilder = new StringBuilder("\r\n\t\t<field path=");
					String tag = preName;
					if (extension==null) {
					    int indx = path.lastIndexOf(tag) - 1;
					    fieldBuilder.append("\"").append(path.subSequence(0, indx)).append("\" ");
					    fieldBuilder.append("tag=\"").append(tag).append("\" ");
					} else {
					    // extension to BigDecimal 
					    fieldBuilder.append("\"").append(path).append("\" ");
					    fieldBuilder.append("tag=\"Value\" ");
					}
					
					

					if (types != null) {
					    // remove "__" or "_" from type's name
					    types = types.replaceAll("_", "");
						fieldBuilder.append("type=\"").append(types).append("\" ");
					}
					
					if (descps != null) {
					    // replace space with _ in words
					    descps = descps.trim();
					    descps = descps.replace(" ", "_");
					    fieldBuilder.append("description=\"").append(descps).append("\" ");
                    }
					
					fieldBuilder.append("tag-type=\"").append(base).append("\" ");
					
					Node aNode = null;
					if (extension != null) {
						NodeList nodeList = extensionElement.getChildNodes();
						String nodeType = null;
						for (int count = 0; count < nodeList.getLength(); count++) {
							aNode = nodeList.item(count);
							String aNodeName = aNode.getNodeName();
							preName = tag;
							if (aNodeName.endsWith("attribute")) {
								NamedNodeMap nodeMap = aNode.getAttributes();
								for (int i = 0; i < nodeMap.getLength(); i++) {
									Node node = nodeMap.item(i);
									String attName = node.getNodeName();
									String attVal = node.getNodeValue();
									ElementAttribute eAtt = ElementAttribute.valueOf(attName);
									switch (eAtt) {
									case name:
										attribute = attVal;
										break;
									case type:
										nodeType = attVal;
										break;
									case use:
										if ("required".equals(attVal.trim())) {
											// minOccurs = "1";
										}
										break;
									default:
										break;
									}
								}
								break;
							}
						}
						extension = null;
					}

					if (path != null && !path.contains("|")) {
						fieldBuilder.append("mandatory=\"true\" ");
					}

					if (attribute != null) {
						fieldBuilder.append("attribute=\"").append(attribute).append("\" ");
					}
					fieldBuilder.append("/>");
					outputBuilder.append(fieldBuilder.toString());
					fieldList.add(fieldBuilder.toString());

					// Build tag
					String tagName = MXMessageHelper.removeSigns(tag);
					Tag newTag = createTag(base, rest_minLength, rest_maxLength, rest_enumeration,
                            rest_fractionDigits, rest_totalDigits, rest_pattern, tagName);

					// attribute's tag
                    if (attribute != null) {
                        parseElement(aNode, type, path, types, descps, tagMap, outputBuilder, fieldList);
                        attribute = null;
                    }
                    
                    String ctype = SchemaConverterHelper.getCtype(types);
                    newTag.setCtype(ctype);
                    String key = tagName+":"+base;
                    Tag extTag = tagMap.get(key);
                    if(extTag==null) {
                        tagMap.put(key, newTag);
                    } else {
                        if (!SchemaConverterHelper.restrictionEquals(newTag.getRestriction(),
                                extTag.getRestriction())){
                            key=key+":"+ctype;
                            extTag = tagMap.get(key);
                            if (extTag==null) {
                                tagMap.put(key, newTag);
                            } else {
                                if (!SchemaConverterHelper.restrictionEquals(newTag.getRestriction(),
                                        extTag.getRestriction())){
                                // this shouldn't happen
                                    System.out.println("Error in create tag:"+newTag.toString());
                                }
                            }
                        }
                    }
					preName = null;
					result = true;
				} else { // print attribute's tag
					String tag = attribute;
					Tag newTag = createTag(base, rest_minLength, rest_maxLength, rest_enumeration,
                            rest_fractionDigits, rest_totalDigits, rest_pattern, tag);
					
					String key = tag + ":"+base;
					Tag extTag = tagMap.get(key);
					if (extTag==null) {
					    tagMap.put(key, newTag);
					} else {
					    if (!SchemaConverterHelper.restrictionEquals(newTag.getRestriction(),
                                extTag.getRestriction())){
					        System.out.println("Error in create attribute tag:"+newTag.toString());
					    }
					}
					attribute = null;
				}
			}
			break;
		default:
			break;
		}
		return result;
	}
	
	private  Tag  createTag(String base, String rest_minLength, String rest_maxLength, String rest_enumeration,
            String rest_fractionDigits, String rest_totalDigits, String rest_pattern, String tagName) throws XMLException {
         Tag result = null;
           result = new Tag();
           
           MinLength minLength= new MinLength();
           minLength.setText(rest_minLength);
           MaxLength maxLength= new MaxLength();
           maxLength.setText(rest_maxLength);
           
           FractionDigits fractionDigits = new FractionDigits();
           fractionDigits.setText(rest_fractionDigits);
           TotalDigits totalDigits = new TotalDigits();
           totalDigits.setText(rest_totalDigits);
           
           
           Enumeration enumeration = new Enumeration();
           enumeration.setText(rest_enumeration);
           
           Pattern pattern = new Pattern();
           pattern.setText(rest_pattern);
           
           Restriction restriction = new Restriction();
           restriction.setElement(pattern);
           restriction.setElement(minLength);
           restriction.setElement(maxLength);
           restriction.setElement(fractionDigits);
           restriction.setElement(totalDigits);
           restriction.setElement(enumeration);
           
           result.setName(tagName);
           result.setType(base);
           result.setMessage(msgId);
          
           result.setElement(restriction);
           
         return result;
	}
}