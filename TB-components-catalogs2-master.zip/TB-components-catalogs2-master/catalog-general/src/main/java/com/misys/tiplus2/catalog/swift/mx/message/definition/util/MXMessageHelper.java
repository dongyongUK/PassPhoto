package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * A helper for handling field, tag of MX Message
 * 
 * @author DaiD1
 *
 */
public class MXMessageHelper {

	public static void printTags(Map<String, String> tagMap, StringBuilder strBuilder) {

		if (tagMap != null) {
			strBuilder.append("<tags>");
			for (Entry<String, String> entry : tagMap.entrySet()) {
				String value = entry.getValue();
				strBuilder.append(value);
			}
			strBuilder.append("</tags>");
		}
	}

	public static String printFields(List<String> fieldList) {

		String result = null;
		StringBuilder fieldsBuilder = new StringBuilder();
		String prePath = null;
		String postPath = null;
		int count = 0;
		int listSize = fieldList.size();
		while (count < listSize) {
			String field = fieldList.get(count);
			count++;
			String path = extractFieldAtt("path", field);
			String tag = extractFieldAtt("tag", field);

			if (count < listSize) {
				postPath = extractFieldAtt("path", fieldList.get(count));
				count++;
			}
			String rformated = reformatField(field, path, tag, prePath, postPath);
			prePath = path;
			fieldsBuilder.append(rformated);
		}

		result = fieldsBuilder.toString();
		return result;
	}

	public static String extractFieldAtt(String attName, String field) {

		String result = null;
		if (field != null && attName != null && field.contains(attName.trim())) {
			attName = attName.trim();
			int attLength = attName.length();
			int idx = field.indexOf(attName);
			result = field.substring(idx + attLength + 1);
			idx = result.indexOf("\"");
			int idx2 = result.indexOf("\"", idx + 1);
			result = result.substring(idx + 1, idx2);

		}
		return result;
	}

	public static String reformatField(String field, String path, String tag, String prePath, String postPath) {

		String result = null;

		if (path != null) {
			int idx1 = path.indexOf("[");
			int idx2 = path.indexOf("]");

			// path contains no repeat
			if (idx1 == -1 && idx2 == -1) {

				idx1 = tag.indexOf("[");
				idx2 = tag.indexOf("]");
				// tag contains no repeat
				if (idx1 == -1 && idx2 == -1) {
					result = field;
					// tag contains repeat
				} else if (idx1 > 0 && idx2 > idx1) {
					StringBuilder fBuilder = new StringBuilder();
					String repeat = extractFirstRepeat(tag);

					fBuilder.append("<block name=\"").append(path).append("\"").append(" repeat=\"").append(repeat)
							.append("\" >");

					field = field.replace("path=\"" + path + "\"", "path=\"\"");
					field = field.replace("tag=\"" + tag + "\"", "tag=\"" + tag.substring(0, idx1) + "\"");
					fBuilder.append(field);

					fBuilder.append("</block>");
					result = fBuilder.toString();
				}
				// path contains repeat
			} else if (idx1 > 0 && idx2 > idx1) {
				StringBuilder fBuilder = new StringBuilder();
				String blockName = path.substring(0, idx1);
				String repeat = extractFirstRepeat(path);
				String newPath = path.substring(idx2 + 2);
				String newField = field.replace("path=\"" + path + "\"", "path=\"" + newPath + "\"");
				// first field of block
				if (prePath!=null && !prePath.equals(postPath)  && !blockName.equals(prePath) && !path.equals(prePath)
					|| (prePath==null && blockName!=null)) {
					fBuilder.append("<block name=\"").append(blockName).append("\"").append(" repeat=\"").append(repeat)
							.append("\" >");
				}
				prePath = newPath;
				if (postPath!=null && postPath.startsWith(path)) {
					postPath = postPath.substring(idx2+2);
				}
				
				String format = reformatField(newField, newPath, tag, prePath, postPath);
				fBuilder.append(format);

				// last field of block
				if ((postPath==null && blockName!=null)|| (postPath!=null && !postPath.startsWith(blockName)) ) {

					fBuilder.append("</block>");
				}
				result = fBuilder.toString();
			}
		}
		return result;
	}

	public static String extractFirstRepeat(String path) {

		String result = null;
		if (path != null && path.contains("[") && path.contains("]")) {
			int idx1 = path.indexOf("[");
			int idx2 = path.indexOf("]");
			result = path.substring(idx1 + 1, idx2);
		}
		return result;
	}
	
	 /**
     * remove optional sign (|) and multiple sign ([n]) from field and tag
     * @param field
     */
    public static String  removeSigns(String pathortag) {
        
        String result = pathortag;
        if (pathortag!=null) {
            if (pathortag.contains("|")) {
               pathortag = pathortag.replace("|", "");
            }
            if (pathortag.contains("?")) {
                pathortag = pathortag.replace("?", "");
             }
            if (pathortag.contains("[") && pathortag.contains("]")) {
                int idx = pathortag.indexOf("[");
                pathortag = pathortag.substring(0,idx);
            }
            result = pathortag;    
        }
        return result;
    }
}
