/**
 * 
 */
package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMaps;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.SequenceMap;

/**
 * @author DaiD1
 *
 */
public class NoopMessageMapVisitor implements MessageMapVisitor {

    @Override
    public Object visit(DataField value, Object data) {

        return null;
    }

    @Override
    public Object visit(MarkerField value, Object data) {

        return null;
    }

    @Override
    public Object visit(DataBlock value, Object data) {

        return null;
    }
    
    @Override
    public Object visit(FieldOptions value, Object data) {

        return null;
    }

    @Override
    public Object visit(MessageMap value, Object data) {

        return null;
    }

    @Override
    public Object visit(MessageMaps value, Object data) {

        return null;
    }

    @Override
    public Object visit(HeaderField value, Object data) {

        return null;
    }

    @Override
    public Object visit(Embedded value, Object data) {
       
        return null;
    }

    @Override
    public Object visit(SequenceMap value, Object data) {
        
        return null;
    }
}
