package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * MessageMaps
 * 
 * 
 * 
 * @author DaiD1
 * 
 */
public class FinMessage extends SAXBaseElement {

    public static final String ELEMENT = "fin-message";

    private String serviceId;
    private List<Block> blockList = new ArrayList<Block>();

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("service-id".equals(name)) {
            setServiceId(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Block) {
            addBlock((Block) element);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public List<Block> getBlockList() {
        return blockList;
    }

    public void addBlock(Block block) {

        blockList.add(block);
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }
}