package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

public enum XSDType {

	ComplexType,
	SimpleType,
	Element;
}
