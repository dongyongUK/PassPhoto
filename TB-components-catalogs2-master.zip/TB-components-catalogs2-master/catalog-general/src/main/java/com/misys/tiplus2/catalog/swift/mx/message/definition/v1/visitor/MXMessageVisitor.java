package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Enumeration;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.FractionDigits;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MaxLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MinLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessage;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessages;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Pattern;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Restriction;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.TotalDigits;
import com.misys.tiplus2.foundations.xml.Visitor;

public interface MXMessageVisitor extends Visitor {

	Object visit(MxMessages value, Object data);

	Object visit(MxMessage value, Object data);
	
	Object visit(Field value, Object data);

	Object visit(Tags value, Object data);

	Object visit(Tag value, Object data);

	Object visit(Restriction value, Object data);

	Object visit(Pattern value, Object data);

	Object visit(MinLength value, Object data);

	Object visit(MaxLength value, Object data);
	
	Object visit(FractionDigits value, Object data);
	
	Object visit(TotalDigits value, Object data);
	
	Object visit(Enumeration value, Object data);

}
