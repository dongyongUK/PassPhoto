package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.groups.FieldTypeChoice;
import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * DataBlock
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class Repeat extends SAXBaseElement {

    public static final String ELEMENT = "repeat";

    private String name;
    private String repeat;
  
    private List<FieldTypeChoice> fieldTypeChoices = new ArrayList<FieldTypeChoice>();
    
    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Field) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Field) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Options) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Options) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("name".equals(name)) {
            setName(value);
        } else if ("repeat".equals(name)) {
            setRepeat(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getRepeat() {
        return repeat;
    }

    private void setRepeat(String repeat) {
        this.repeat = repeat;
    }

    public void addFieldTypeChoice(FieldTypeChoice choice) {
        this.fieldTypeChoices.add(choice);
    }

    public List<FieldTypeChoice> getFieldTypeChoices() {
        return this.fieldTypeChoices;
    }
}
