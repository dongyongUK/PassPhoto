package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor.MXMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Tag
 * 
 * @author DaiD1
 * 
 */
public class Tag extends SAXBaseElement {

    public static final String ELEMENT = "tag";
    //name of tag
    private String name;
    //data type of the tag
    private String type;
    //class type of the tag
    private String ctype;
    //message of the tag
    private String message;
    private String errorCode;
    private Restriction restriction;

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("name".equals(name)) {
            setName(value);
        } else if ("type".equals(name)) {
            setType(value);
        } else if ("ctype".equals(name)) {
            setCtype(value);
        } else if ("message".equals(name)) {
                setMessage(value);
        } else if ("error-code".equals(name)) {
            setErrorCode(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Restriction) {
            restriction = (Restriction) element;
        } else {
            super.setElement(element);
        }
    }
    
    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MXMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }


    public String getName() {
        return name;
    }

    public void setName(String tag) {
        this.name = tag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public Restriction getRestriction() {
		return restriction;
	}

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCtype() {
        return ctype;
    }

    public void setCtype(String ctype) {
        this.ctype = ctype;
    }
}
