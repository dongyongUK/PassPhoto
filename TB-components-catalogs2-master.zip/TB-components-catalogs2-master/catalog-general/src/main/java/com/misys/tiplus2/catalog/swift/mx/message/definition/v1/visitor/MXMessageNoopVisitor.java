/**
 * 
 */
package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Enumeration;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.FractionDigits;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MaxLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MinLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessage;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessages;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Pattern;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Restriction;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.TotalDigits;

/**
 * @author DaiD1
 *
 */
public class MXMessageNoopVisitor implements MXMessageVisitor {


    @Override
    public Object visit(Field value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Tags value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(MxMessage value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Tag value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(MxMessages value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public Object visit(Restriction value, Object data) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Object visit(Pattern value, Object data) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Object visit(MinLength value, Object data) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Object visit(MaxLength value, Object data) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Object visit(FractionDigits value, Object data) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Object visit(TotalDigits value, Object data) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Object visit(Enumeration value, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

}
