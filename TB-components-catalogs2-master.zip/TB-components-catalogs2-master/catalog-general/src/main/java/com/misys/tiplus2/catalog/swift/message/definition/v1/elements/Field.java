package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * A generic field, could be a header field, marker field or date field
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class Field extends SAXBaseElement {

    public static final String ELEMENT = "field";
    private String tag;
    private String description;
    private String mandatory = "";
    private String defaultValue;
    private String codes;

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("tag".equals(name)) {
            setTag(value);
        } else if ("description".equals(name)) {
            setDescription(value);
        } else if ("mandatory".equals(name)) {
            setMandatory(value);
        } else if ("default".equals(name)) {
            setDefaultValue(value);
        } else if ("codes".equals(name)) {
            setCodes(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getDescription() {
        return description;
    }

    private void setDescription(String description) {
        this.description = description;
    }

    public String getMandatory() {
        return mandatory;
    }

    private void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public String getCodes() {
        return codes;
    }

    private void setCodes(String codes) {
        this.codes = codes;
    }    
}
