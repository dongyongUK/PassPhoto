package com.misys.tiplus2.catalog.swift.message.definition.v1.visitor;

import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Block;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessage;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessages;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Marker;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Options;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Repeat;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Sequence;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Variant;
import com.misys.tiplus2.foundations.xml.Visitor;

public interface FinMessageVisitor extends Visitor {

    //Object visit(Blocks value, Object data);

    Object visit(FinMessages value, Object data);
    Object visit(FinMessage value, Object data);
    Object visit(Block value, Object data);
    Object visit(Variant value, Object data);
 
    Object visit(Field value, Object data);
    Object visit(Marker value, Object data);
    Object visit(Repeat value, Object data);
    Object visit(Options value, Object data);
    Object visit(Sequence value, Object data);

    Object visit(Tags value, Object data);
    Object visit(Tag value, Object data);
}
