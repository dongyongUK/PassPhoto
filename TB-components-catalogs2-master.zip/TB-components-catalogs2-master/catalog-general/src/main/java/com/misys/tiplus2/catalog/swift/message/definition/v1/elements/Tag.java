package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Tag
 * 
 * @author DaiD1
 * 
 */
public class Tag extends SAXBaseElement {

    public static final String ELEMENT = "tag";
    private String name;
    private String format;
    private String type;

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("name".equals(name)) {
            setName(value);
        } else if ("format".equals(name)) {
            setFormat(value);
        } else if ("type".equals(name)) {
            setType(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getName() {
        return name;
    }

    public void setName(String tag) {
        this.name = tag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
