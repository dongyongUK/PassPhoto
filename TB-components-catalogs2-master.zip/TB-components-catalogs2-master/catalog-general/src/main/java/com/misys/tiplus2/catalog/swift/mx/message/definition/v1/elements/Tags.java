package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor.MXMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 *
 * MxTags
 *
 * @author DaiD1
 *
 */
public class Tags extends SAXBaseElement {

    public static final String ELEMENT = "tags";

    private Map<String, Tag> tagMap = new LinkedHashMap<String, Tag>();

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Tag) {
            addTag((Tag) element);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MXMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public Map<String, Tag> getTagMap() {
        return tagMap;
    }

    public void addTag(Tag tag) {
        String key = tag.getName()+":"+tag.getType();
        String ctype=tag.getCtype();
        if (ctype!=null && !ctype.isEmpty()) {
            key = key+":"+ctype;
        } 
        tagMap.put(key, tag);
    }


    public Tag getTagByKey(String key) {
        return tagMap.get(key);
    }
    
    public Tag getTag(String name, String type) {
        return tagMap.get(name+":"+type);
    }
    
    public Tag getTag(String name, String type, String ctype) {

        String key = name+":"+type;
        if (ctype!=null && !ctype.isEmpty()) {
            key = key + ":"+ctype;
        } 
        return  tagMap.get(key);
    }
}
