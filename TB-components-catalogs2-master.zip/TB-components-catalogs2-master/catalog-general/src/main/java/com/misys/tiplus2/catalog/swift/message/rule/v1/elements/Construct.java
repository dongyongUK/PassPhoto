package com.misys.tiplus2.catalog.swift.message.rule.v1.elements;

import java.util.ArrayList;
import java.util.List;

import com.misys.tiplus2.catalog.swift.message.rule.v1.groups.ItemTypeChoice;
import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.MessageRuleVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * There are 3 forms of constructs:
 * 1.    IF <statement>
 *            THEN <procedure>|<construct> 
 *       ENDIF
 * 2.    IF <statement>
 *            THEN <procedure>|<construct>
 *            ELSE <procedure>|<construct> 
 *       ENDIF 
 * 3.    FOR <statement>
 *          <procedure>|<construct> 
 *       ENDFOR
 *       
 * @author DaiD1
 * TSDS-40844
 *
 */
public class Construct extends SAXBaseElement {

    public static final String ELEMENT = "custruct";

    private String ruleId;
    private String type;
    
    private Statement statement;
    private Procedure procedure;
    private Construct construct;
    private List<ItemTypeChoice> itemTypeChoices = new ArrayList<ItemTypeChoice>();

    @Override
    public void setElement(SAXElement element) throws XMLException {

        if (element instanceof Statement) {
            ItemTypeChoice itemTypeChoice = new ItemTypeChoice((Statement) element);
            addItemTypeChoice(itemTypeChoice);
            statement = (Statement) element;
        } else if (element instanceof Procedure) {
            ItemTypeChoice itemTypeChoice = new ItemTypeChoice((Procedure) element);
            addItemTypeChoice(itemTypeChoice);
            procedure = (Procedure) element;
        } else if (element instanceof Construct) {
            ItemTypeChoice itemTypeChoice = new ItemTypeChoice((Construct) element);
            addItemTypeChoice(itemTypeChoice);
            construct = (Construct) element;
        } else {
            super.setElement(element);
        }
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("rule-id".equals(name)) {
            setRuleId(value);
        } else if ("type".equals(name)) {
            setType(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    public Statement getStatement() {
        return statement;
    }

    private void setStatement(Statement statement) {
        this.statement = statement;
    }

    public Procedure getProcedure() {
        return procedure;
    }

    private void setProcedure(Procedure procedure) {
        this.procedure = procedure;
    }

    public Construct getConstruct() {
        return construct;
    }

    private void setConstruct(Construct construct) {
        this.construct = construct;
    }

    public String getRuleId() {
        return ruleId;
    }

    private void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getType() {
        return type;
    }

    private void setType(String type) {
        this.type = type;
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageRuleVisitor) visitor).visit(this, data);
    }

    public void addItemTypeChoice(ItemTypeChoice choice) {
        this.itemTypeChoices.add(choice);
    }

    public List<ItemTypeChoice> getItemTypeChoices() {
        return itemTypeChoices;
    }

    public void setItemTypeChoices(List<ItemTypeChoice> itemTypeChoices) {
        this.itemTypeChoices = itemTypeChoices;
    }
}
