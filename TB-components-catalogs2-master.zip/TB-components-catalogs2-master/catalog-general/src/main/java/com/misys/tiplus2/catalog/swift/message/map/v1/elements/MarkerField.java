package com.misys.tiplus2.catalog.swift.message.map.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.MessageMapVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * MarkerField
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class MarkerField extends SAXBaseElement {

    public static final String ELEMENT = "marker-field";
    private String tag;
    private String name;

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("name".equals(name)) {
            setName(value);
        } else if ("tag".equals(name)) {
            setTag(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageMapVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }
}
