package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor.MXMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * maxLength of String
 * 
 * @author DaiD1
 * 
 */
public class MaxLength extends SAXBaseElement {

	public static final String ELEMENT = "maxLength";
	   
	 private String value;
	 
    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MXMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }
    
    @Override
    public void setText(String value) {
    	this.value = value;
    }
    
    public String getValue() {
    	return value;
    }
}
