package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements;
        
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor.MXMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Mx restriction
 * 
 * @author DaiD1
 * 
 */
public class Restriction extends SAXBaseElement {

    public static final String ELEMENT = "restriction";
   
    private MinLength  minLength;
    private MaxLength  maxLength;
    private Pattern pattern;
    private Enumeration enumeration;
    private FractionDigits fractionDigits;
    private TotalDigits totalDigits;
    
    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MXMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof MinLength) {
            minLength = (MinLength) element;
        } else if (element instanceof MaxLength) {
            maxLength = (MaxLength) element;
        } else if (element instanceof Enumeration) {
        	enumeration = (Enumeration) element;
        } 
        else if (element instanceof FractionDigits) {
        	fractionDigits = (FractionDigits) element;
        } 
        else if (element instanceof TotalDigits) {
        	totalDigits = (TotalDigits) element;
        } 
        else if (element instanceof Pattern) {
            pattern = (Pattern) element;
        } else {
            super.setElement(element);
        }
    }
    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

	public MinLength getMinLength() {
		return minLength;
	}

	public void setMinLength(MinLength minLength) {
		this.minLength = minLength;
	}

	public MaxLength getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(MaxLength maxLength) {
		this.maxLength = maxLength;
	}

	public Pattern getPattern() {
		return pattern;
	}

	public void setPattern(Pattern pattern) {
		this.pattern = pattern;
	}

	public Enumeration getEnumeration() {
		return enumeration;
	}

	public FractionDigits getFractionDigits() {
		return fractionDigits;
	}

	public TotalDigits getTotalDigits() {
		return totalDigits;
	}

}
