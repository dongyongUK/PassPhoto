package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

/**
 * Convert MX schema into MX message definition  -- single file only
 * 
  * @author DaiD1
 */
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;

import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XMLSchemaNode;
import oracle.xml.parser.schema.XSDBuilder;

public class MXSchemaToMXMessage2 {

    static String INPUT_DIR = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
            + File.separator + "resources" + File.separator + "MXSchema";
    static String OUtPUT_DIR = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
            + File.separator + "resources" + File.separator + "MXMessage";
    
	static String outFileName = "mx-message.xml";
	static StringBuilder outputBuilder;
	static XMLSchemaNode rootNode;
	final static String XS = "xs:";

	public static void main(String[] args) {

		if (args.length <= 0) {
			System.out.println("usage: MXSchemaToMXMessage xsdFile outputFile");
			System.out.println("xsdFile -- schema file");
			System.out.println("outFile -- output File name ");
			
		}
		// Schema file
		String xsdFileName = args[0];

		// output file name
		if (args.length > 1) {
			outFileName = args[1];
		}

		File outFile = new File(OUtPUT_DIR, outFileName);
		FileOutputStream fout = null;

		try {
			XSDBuilder builder = new XSDBuilder();
			File xsdfile = new File(INPUT_DIR, xsdFileName);
			URL url = xsdfile.toURI().toURL();
			// Build XML Schema Object
			XMLSchema schema = (XMLSchema) builder.build(url);
			MXSchemaToMXMessageConverter converter = new MXSchemaToMXMessageConverter();
			Map<String, Tag> tagMap = new HashMap<String, Tag>();
			String msgBody = converter.convertMXSchema(schema, tagMap);
			StringBuilder tagsBuilder = new StringBuilder();
			SchemaConverterHelper.printTags(tagMap, tagsBuilder);

			fout = new FileOutputStream(outFile);

			fout.write(msgBody.getBytes(StandardCharsets.UTF_8));
			fout.write(tagsBuilder.toString().getBytes(StandardCharsets.UTF_8));
			fout.close();
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		} finally {
			if (fout != null) {
				try {
					fout.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}