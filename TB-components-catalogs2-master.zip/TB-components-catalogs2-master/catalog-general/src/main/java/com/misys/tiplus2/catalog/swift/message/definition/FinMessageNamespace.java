package com.misys.tiplus2.catalog.swift.message.definition;

import com.misys.tiplus2.catalog.swift.message.definition.v1.ElementBroker;
import com.misys.tiplus2.foundations.xml.namespace.Namespace;
import com.misys.tiplus2.foundations.xml.namespace.NamespaceException;
import com.misys.tiplus2.foundations.xml.namespace.Namespaces;
import com.misys.tiplus2.foundations.xml.namespace.StrictNamespaces;

public class FinMessageNamespace {

    public static final String URI = "urn:definition.message.swift.catalog.tiplus2.misys.com";
    public static final String PREFIX = "fm";

    public static final String DOCUMENT_ELEMENT = "fin-message-definition";

    public static final Namespace NAMESPACE;
    static {
        NAMESPACE = new Namespace(URI, PREFIX);
        NAMESPACE.addDefaultElementBroker(DOCUMENT_ELEMENT, "1.0", new ElementBroker());
    }

    public static class Attributes {
        public static final String VERSION = "version";
        public static final String NAME = "name";
        public static final String KEY = "key";
        public static final String MESSAGE = "nessage";
        public static final String TAG = "tag";
        public static final String MANDATORY = "mandatory";
        public static final String DESCRIPTION = "description";
        public static final String INCLUDE = "include";
        public static final String FORMAT = "format";
        public static final String NUMBER = "number";
        public static final String REG = "reg";
        public static final String REPEAT = "repeat";
        public static final String TYPE = "type";
        public static final String VARIANT = "variant";
        public static final String VARIANT_TYPE = "variant-type";
        public static final String VALUE = "value";
        public static final String DEFAULT_VALUE = "default";
        public static final String OPTIONS = "options";
        public static final String CODES = "Codes";
        public static final String MAX_LENGTH = "max-length";
        public static final String SERVICE_ID = "service-id";

    }

    public static Namespaces getNamespaces() {
        Namespaces result = new StrictNamespaces();
        addToNamespaces(result);
        return result;
    }

    public static void addToNamespaces(Namespaces namespaces) {
        try {
            namespaces.addNamespace(NAMESPACE);
        } catch (NamespaceException ne) {
            // TODO throw runtime exception
        }
    }
}
