package com.misys.tiplus2.catalog.swift.message.rule.v1.elements;

import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.MessageRuleVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * A component has following attributes
 *  message -- message type  
 *             Single message: message=700
 *             multiple messages: message=700|720, 700 or 720
 *             all message: *
 *  sequence -- sequence (such as B, C...)
 *  field -- message field 
 *           single field: field=23X
 *           optional field field=52a
 *           Wild card field: field=50*
 *           multiple field:  field=53C|25A   (53C or 25A)
 *  value --  value for checking against field's value. 
 *            single value: value=ICCO
 *            multiple values: value=ISSO|ICCO|PPPX
 *  pattern -- regular expression pattern to match the field value 
 *  subValueIndex-- String index for sub value, if it is "*" which means contains given value 
 *            start from: sub-value-index=5 
 *            start and end: sub-value-index==3-8
 *            contains a given value: sub-value-index=*  
 *             
 * predicate -- Predicate id for using Lambda predicate interface to validate a field 
 *              Field value is the first argument of the test method of Predicate, Message type is 
 *              the second argument of the test method
 * arguments -- further arguments after field value and message type for the test method. multiple 
 *                arguments are separated by "|" (e.g: "arg1|arg2|arg3").     
 *   
 *   
 * @author DaiD1
 *TSDS-40844
 */
public class Component extends SAXBaseElement {

    public static final String ELEMENT = "component";

    private String message;
    private String sequence;
    private String field;
    private String subValueIndex;
    private String value;
    private String pattern;
    
    private String predicate;
    private String arguments;
  

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("message".equals(name)) {
            setMessage(value);
        } else if ("sequence".equals(name)) {
            setSequence(value);
        } else if ("field".equals(name)) {
            setField(value);
        } else if ("sub-value-index".equals(name)) {
            setSubValueIndex(value);
        } else if ("value".equals(name)) {
            setValue(value);
        } else if ("predicate".equals(name)) {
            setPredicate(value);
        } else if ("pattern".equals(name)) {
            setPattern(value);
        } else if ("arguments".equals(name)) {
            setArguments(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    public String getMessage() {
        return message;
    }

    private void setMessage(String message) {
        this.message = message;
    }

    public String getSequence() {
        return sequence;
    }

    private void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getField() {
        return field;
    }

    private void setField(String field) {
        this.field = field;
    }

    public String getSubValueIndex() {
        return subValueIndex;
    }

    private void setSubValueIndex(String subValueIndex) {
        this.subValueIndex = subValueIndex;
    }

    public String getValue() {
        return value;
    }

    private void setValue(String value) {
        this.value = value;
    }

    public String getPredicate() {
		return predicate;
	}

	private void setPredicate(String predicate) {
		this.predicate = predicate;
	}


	public String getArguments() {
		return arguments;
	}

	private void setArguments(String arguments) {
		this.arguments = arguments;
	}

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    @Override
    public Object accept(Visitor visitor, Object data) {

        return ((MessageRuleVisitor) visitor).visit(this, data);
    }
}
