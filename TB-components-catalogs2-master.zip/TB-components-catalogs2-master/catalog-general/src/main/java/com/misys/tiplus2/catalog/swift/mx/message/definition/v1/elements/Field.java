package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor.MXMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * A generic field,
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class Field extends SAXBaseElement {

    public static final String ELEMENT = "field";
    private String tag;
    private String description;
    private String mandatory = "";
    private String repeat;
    private String type;
    private String path;
    private String attribute;
    private String tagType;

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("tag".equals(name)) {
            setTag(value);
        } else if ("description".equals(name)) {
            setDescription(value);
        } else if ("mandatory".equals(name)) {
            setMandatory(value);
        } else if ("repeat".equals(name)) {
            setRepeat(value);
        } else if ("type".equals(name)) {
            setType(value);
        } else if ("path".equals(name)) {
            setPath(value);
        } else if ("attribute".equals(name)) {
                setAttribute(value);
        } else if ("tag-type".equals(name)) {
            setTagType(value);
        }else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MXMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getDescription() {
        return description;
    }

    private void setDescription(String description) {
        this.description = description;
    }

    public String getMandatory() {
        return mandatory;
    }

    private void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }

    public String getType() {
        return type;
    }

    private void setType(String type) {
        this.type = type;
    }

    public String getPath() {
        return path;
    }

    private void setPath(String path) {
        this.path = path;
    }

    public String getRepeat() {
        return repeat;
    }

    public void setRepeat(String repeat) {
        this.repeat = repeat;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getTagType() {
        return tagType;
    }

    public void setTagType(String tagType) {
        this.tagType = tagType;
    }
    
}
