package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor.MXMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * FinMessages
 * 
 * 
 * @author DaiD1
 * 
 */
public class MxMessages extends SAXBaseElement {

	public static final String ELEMENT = "mx-messages";
	private Map<String, MxMessage> messageMap = new LinkedHashMap<String, MxMessage>();
	private Tags tags;
	private String version;

	@Override
	public void setAttribute(String name, String value) throws XMLException {
		if ("version".equals(name)) {
			setVersion(value);
		} else {
			super.setAttribute(name, value);
		}
	}

	@Override
	public void setElement(SAXElement element) throws XMLException {
		if (element instanceof MxMessage) {
			putMessage((MxMessage) element);
		} else if (element instanceof Tags) {
			setTags((Tags) element);
		} else {
			super.setElement(element);
		}
	}

	@Override
	public Object accept(Visitor visitor, Object data) {
		return ((MXMessageVisitor) visitor).visit(this, data);
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).appendSuper(super.toString()).toString();
	}

	public Tags getTags() {
		return tags;
	}

	public void setTags(Tags tags) {
		this.tags = tags;
	}

	public Map<String, MxMessage> getMessageMap() {
		return this.messageMap;
	}

	public void putMessage(MxMessage mxMessage) {
		messageMap.put(mxMessage.getMessageId(), mxMessage);
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public MxMessage getMessageById(String messageId) {

		return messageMap.get(messageId);
	}
}