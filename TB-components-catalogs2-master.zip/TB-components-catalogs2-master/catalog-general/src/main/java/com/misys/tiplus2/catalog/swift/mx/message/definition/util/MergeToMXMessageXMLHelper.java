package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MergeToMXMessageXMLHelper {
    static String DIR = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
            + File.separator + "resources" + File.separator + "MXMessage";
    
    public static void main(String[] args) {
    	
    	// Indivial MX-Message generated file to be merged to main mx-message.xml file. I.e. mx-messages-camt105.xml
    	String inputFile = args[0];
    	
    	// Ideally should be mx-messages.xml
    	String outputFile = args[1];
    	
    	MergeMessageId(inputFile, outputFile);
    	MergeTags(inputFile,outputFile);
    }
    
    private static void MergeMessageId(String inputFile, String outputFile) {
		String inputURL = "";
		String outputURL = "";
		String outputURLFileContent = "";
        // Initialize a list to store the tag contents
        List<String> tagContents = new ArrayList<>();
        
		try {
			File inputFileFullPath = new File(DIR, inputFile);
			inputURL = inputFileFullPath.toURI().toURL().toString();
			inputURL = inputURL.substring(inputURL.indexOf("file:/") + 6 ,inputURL.length());
			
			File outputFileFullPath = new File(DIR, outputFile);
			outputURL = outputFileFullPath.toURI().toURL().toString();
			outputURL = outputURL.substring(outputURL.indexOf("file:/") + 6 ,outputURL.length());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        try {
            byte[] encoded = Files.readAllBytes(Paths.get(outputURL));
            outputURLFileContent = new String(encoded, StandardCharsets.UTF_8);
            //System.out.println("File content:\n" + outputURLFileContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    	XMLTagExtractor xmlTagExtract = new XMLTagExtractor();
    	tagContents = xmlTagExtract.main(inputURL, "mx-message", "message-id");
    	
    	ListIterator<String> tagContentsIterator = tagContents.listIterator();
    	while(tagContentsIterator.hasNext()) {
    		String tag = tagContentsIterator.next();
    		String pattern = "(message-id\\s*=\\s*\"([^\"]+)\")"; //message-id="camt.105.001.02"
    		
    		Pattern regex = Pattern.compile(pattern);
            Matcher matcher = regex.matcher(tag);
            
            if (matcher.find()) {
                String matchedValue = matcher.group(1);
                if (!outputURLFileContent.contains(matchedValue)) { // check if mx-messages contains the tag
                	outputURLFileContent = InsertInMiddle(outputURLFileContent, "\n\t" + tag, outputURLFileContent.lastIndexOf("</mx-message>") + 13);
                	try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputURL, false))) {
                        writer.write(outputURLFileContent);
                        System.out.println("Inserted " + matchedValue + " to " + outputURL);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                System.out.println("No match found.");
            }
            
    	}
    }

    private static void MergeTags(String inputFile, String outputFile) {
		String inputURL = "";
		String outputURL = "";
		String outputURLFileContent = "";
        // Initialize a list to store the tag contents
        List<String> tagContents = new ArrayList<>();
        
		try {
			File inputFileFullPath = new File(DIR, inputFile);
			inputURL = inputFileFullPath.toURI().toURL().toString();
			inputURL = inputURL.substring(inputURL.indexOf("file:/") + 6 ,inputURL.length());
			
			File outputFileFullPath = new File(DIR, outputFile);
			outputURL = outputFileFullPath.toURI().toURL().toString();
			outputURL = outputURL.substring(outputURL.indexOf("file:/") + 6 ,outputURL.length());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        try {
            byte[] encoded = Files.readAllBytes(Paths.get(outputURL));
            outputURLFileContent = new String(encoded, StandardCharsets.UTF_8);
            //System.out.println("File content:\n" + outputURLFileContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    	XMLTagExtractor xmlTagExtract = new XMLTagExtractor();
    	tagContents = xmlTagExtract.main(inputURL, "tag", "name");
    	
    	ListIterator<String> tagContentsIterator = tagContents.listIterator();
    	while(tagContentsIterator.hasNext()) {
    		String tag = tagContentsIterator.next();
    		String pattern = "(name\\s*=\\s*\"([^\"]+)\")"; //name="Id"
    		
    		Pattern regex = Pattern.compile(pattern);
            Matcher matcher = regex.matcher(tag);
            
            if (matcher.find()) {
                String matchedValue = matcher.group(1);
                if (!outputURLFileContent.contains(matchedValue)) { // check if mx-messages contains the tag
                	tag = "\n\t\t" + tag;
                	outputURLFileContent = InsertInMiddle(outputURLFileContent, tag, outputURLFileContent.lastIndexOf("</tag>") + 6);
                	try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputURL, false))) {
                        writer.write(outputURLFileContent);
                        System.out.println("Inserted " + matchedValue + " to " + outputURL);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                System.out.println("No match found.");
            }
            
    	}
    }
    
    public static String InsertInMiddle(String original, String toInsert, int index) {
        String firstPart = original.substring(0, index);
        String secondPart = original.substring(index);
        return firstPart + toInsert + secondPart;
    }
}
