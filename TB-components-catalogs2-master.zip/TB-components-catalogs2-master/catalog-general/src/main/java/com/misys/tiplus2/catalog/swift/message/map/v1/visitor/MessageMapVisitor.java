package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMaps;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.SequenceMap;
import com.misys.tiplus2.foundations.xml.Visitor;

public interface MessageMapVisitor extends Visitor {

    Object visit(HeaderField value, Object data);

    Object visit(DataField value, Object data);

    Object visit(MarkerField value, Object data);

    Object visit(DataBlock value, Object data);
    
    Object visit(FieldOptions value, Object data);
    
    Object visit(SequenceMap value, Object data);

    Object visit(Embedded value, Object data);

    Object visit(MessageMap value, Object data);

    Object visit(MessageMaps value, Object data);

}
