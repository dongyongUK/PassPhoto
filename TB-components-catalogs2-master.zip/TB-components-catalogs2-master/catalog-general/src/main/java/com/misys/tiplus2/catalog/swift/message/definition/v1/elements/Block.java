package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Header block definition
 * 
 * 
 * @author DaiD1
 * 
 */
public class Block extends SAXBaseElement {

    public static final String ELEMENT = "block";

    private String name;
    private String number;
    private String type;
    private String variantType;

    private Variant variant;
    private Map<String, Variant> variants = new LinkedHashMap<String, Variant>();

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Variant) {
            Variant v = (Variant) element;
            if (getVariantType() == null) {
                variant = v;
            } else {
                addVariant((Variant) v);
            }
        } else {
            super.setElement(element);
        }
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("name".equals(name)) {
            setName(value);
        } else if ("number".equals(name)) {
            setNumber(value);
        } else if ("type".equals(name)) {
            setType(value);
        } else if ("variant-type".equals(name)) {
            setVariantType(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public void addVariant(Variant variant) {
        // this.variantList.add(variant);
        this.variants.put(variant.getValue(), variant);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Variant findVariantByValue(String value) {
        return variants.get(value);
    }

    public Map<String, Variant> getVariants() {
        return variants;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVariantType() {
        return variantType;
    }

    public void setVariantType(String variantType) {
        this.variantType = variantType;
    }

    public Variant getVariant() {
        return this.variant;
    }

    public List<Variant> getVariantList() {

        List<Variant> variantList = new ArrayList<Variant>();

        for (Entry<String, Variant> entry : variants.entrySet()) {
            variantList.add(entry.getValue());
        }
        return variantList;
    }
}
