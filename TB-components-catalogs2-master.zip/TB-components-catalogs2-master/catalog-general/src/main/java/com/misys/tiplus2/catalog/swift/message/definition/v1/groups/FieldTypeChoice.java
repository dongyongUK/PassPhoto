package com.misys.tiplus2.catalog.swift.message.definition.v1.groups;


import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Marker;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Options;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Repeat;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Sequence;
import com.misys.tiplus2.foundations.lang.contract.AssertState;

public class FieldTypeChoice {

    public enum Choice {
        FIELD, MARKER, REPEAT, OPTIONS,SEQUENCE
    }

    private Field field;

    private Marker marker;

    private Repeat repeat;
    
    private Options options;
    
    private Sequence sequence;

    private final Choice chosen;

    public FieldTypeChoice(Field field) {
        this.field = field;
        this.chosen = Choice.FIELD;
    }

    public FieldTypeChoice(Marker marker) {
        this.marker = marker;
        this.chosen = Choice.MARKER;
    }

    public FieldTypeChoice(Repeat repeat) {
        this.repeat = repeat;
        this.chosen = Choice.REPEAT;
    }
    
    public FieldTypeChoice(Options options) {
        this.options = options;
        this.chosen = Choice.OPTIONS;
    }
    
    public FieldTypeChoice(Sequence sequence) {
        this.sequence = sequence;
        this.chosen = Choice.SEQUENCE;
    }

    public Choice getChosen() {
        Choice result = chosen;
        if (result == null) {
            result = Choice.FIELD;
        }
        return result;
    }

    public Field getField() {
        AssertState.isTrue(getChosen() == Choice.FIELD, "Field was not chosen");
        return field;
    }

    public Marker getMarker() {
        AssertState.isTrue(getChosen() == Choice.MARKER, "Marker was not chosen");
        return marker;
    }

    public Repeat getRepeat() {
        AssertState.isTrue(getChosen() == Choice.REPEAT, "Repeat was not chosen");
        return repeat;
    }
    
    public Options getOptions() {
        AssertState.isTrue(getChosen() == Choice.OPTIONS, "Options was not chosen");
        return options;
    }

    public Sequence getSequence() {
        AssertState.isTrue(getChosen() == Choice.SEQUENCE, "Sequence was not chosen");
        return sequence;
    }
    @Override
    public String toString() {
        return new ToStringBuilder(this).append("Field", field).append("Repeat", repeat)
                .append("Options",options).append("chosen", chosen)
                .appendSuper(super.toString()).toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((chosen == null) ? 0 : chosen.hashCode());
        result = prime * result + ((field == null) ? 0 : field.hashCode());
        result = prime * result + ((marker == null) ? 0 : marker.hashCode());
        result = prime * result + ((repeat == null) ? 0 : repeat.hashCode());
        result = prime * result + ((options == null) ? 0 : options.hashCode());
        result = prime * result + ((sequence == null) ? 0 : sequence.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        FieldTypeChoice other = (FieldTypeChoice) obj;
        if (chosen != other.chosen) {
            return false;
        }
        if (field == null) {
            if (other.field != null) {
                return false;
            }
        } else if (!field.equals(other.field)) {
            return false;
        }
        if (marker == null) {
            if (other.marker != null) {
                return false;
            }
        } else if (!marker.equals(other.marker)) {
            return false;
        }

        if (repeat == null) {
            if (other.repeat != null) {
                return false;
            }
        } else if (!repeat.equals(other.repeat)) {
            return false;
        }
        
        if (options == null) {
            if (other.options != null) {
                return false;
            }
        } else if (!options.equals(other.options)) {
            return false;
        }
        
        if (sequence == null) {
            if (other.sequence != null) {
                return false;
            }
        } else if (!sequence.equals(other.sequence)) {
            return false;
        }
        
        return true;
    }
}
