/**
 * 
 */
package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor;

import java.util.Map.Entry;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.misys.tiplus2.catalog.swift.mx.message.definition.MXMessageNamespace;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Enumeration;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.FractionDigits;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MaxLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MinLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessage;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MxMessages;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Pattern;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Restriction;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.TotalDigits;
import com.misys.tiplus2.foundations.lang.constants.Empty;
import com.misys.tiplus2.foundations.xml.XMLVisitorException;
import com.misys.tiplus2.foundations.xml.attribute.Attribute;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributes;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributesHelper;

/**
 * @author DaiD1
 *
 */
public class MXMessageDocumentVisitor implements MXMessageVisitor {

	protected ElementAttributes attributes = new ElementAttributes();
	protected String mainNamespaceURI;

	public MXMessageDocumentVisitor() {
		mainNamespaceURI = MXMessageNamespace.URI;
	}

	@Override
	public Object visit(Field field, Object data) {
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			if (field.getTag() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.TAG, Empty.STRING,
						Attribute.Types.CDATA, field.getTag());
			}

			if (field.getMandatory() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.MANDATORY, Empty.STRING,
						Attribute.Types.CDATA, field.getMandatory());
			}
			if (field.getRepeat() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.REPEAT, Empty.STRING,
						Attribute.Types.CDATA, field.getRepeat());
			}
			if (field.getDescription() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.DESCRIPTION, Empty.STRING,
						Attribute.Types.CDATA, field.getDescription());
			}
			if (field.getPath() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.PATH, Empty.STRING,
						Attribute.Types.CDATA, field.getPath());
			}
			if (field.getTagType() != null) {
                attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.TAG_TYPE, Empty.STRING,
                        Attribute.Types.CDATA, field.getTagType());
            }
			if (field.getAttribute() != null) {
                attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.ATTRIBUTE, Empty.STRING,
                        Attribute.Types.CDATA, field.getAttribute());
            }

			handler.startElement(mainNamespaceURI, Field.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, Field.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(Tags tags, Object data) {
		ContentHandler handler = (ContentHandler) data;

		try {
			attributes.clear();

			handler.startElement(mainNamespaceURI, Tags.ELEMENT, Empty.STRING, attributes);

			for (Entry<String, Tag> entry : tags.getTagMap().entrySet()) {
				entry.getValue().accept(this, data);
			}

			handler.endElement(mainNamespaceURI, Tags.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(MxMessages mxMessages, Object data) {
		ContentHandler handler = (ContentHandler) data;

		try {

			handler.startDocument();

			ElementAttributesHelper.addDefaultNamespaceAttribute(attributes.clear(), mainNamespaceURI);
			if (mxMessages.getVersion() != null) {
				attributes.addAttribute(mainNamespaceURI, "version", Empty.STRING, Attribute.Types.CDATA,
						mxMessages.getVersion());
			}

			handler.startElement(mainNamespaceURI, MxMessages.ELEMENT, Empty.STRING, attributes);

			for (Entry<String, MxMessage> entry: mxMessages.getMessageMap().entrySet()) {
				MxMessage mxMessage = entry.getValue();
				mxMessage.accept(this, data);
			}
			
			mxMessages.getTags().accept(this, data);

			handler.endElement(mainNamespaceURI, MxMessages.ELEMENT, Empty.STRING);

			handler.endDocument();

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}

		return data;
	}

	@Override
	public Object visit(Tag tag, Object data) {
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			if (tag.getName() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.TAG, Empty.STRING,
						Attribute.Types.CDATA, tag.getName());
			}


			if (tag.getType() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.TYPE, Empty.STRING,
						Attribute.Types.CDATA, tag.getType());
			}

			if (tag.getCtype() != null) {
                attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.CTYPE, Empty.STRING,
                        Attribute.Types.CDATA, tag.getCtype());
            }
			
			if (tag.getMessage() != null) {
                attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.MESSAGE, Empty.STRING,
                        Attribute.Types.CDATA, tag.getMessage());
            }
			
			if (tag.getErrorCode() != null) {
                attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.ERROR_CODE, Empty.STRING,
                        Attribute.Types.CDATA, tag.getErrorCode());
            }
			
			handler.startElement(mainNamespaceURI, Tag.ELEMENT, Empty.STRING, attributes);

			if (tag.getRestriction()!=null) {
				tag.getRestriction().accept(this, data);
			}
			
			handler.endElement(mainNamespaceURI, Tag.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(MxMessage mxMessage, Object data) {

		ContentHandler handler = (ContentHandler) data;

		try {
			attributes.clear();
			if (mxMessage.getMessageId() != null) {
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.MESSAGE_ID, Empty.STRING,
						Attribute.Types.CDATA, mxMessage.getMessageId());
			}

			handler.startElement(mainNamespaceURI, MxMessage.ELEMENT, Empty.STRING, attributes);

			for (Entry<String, Field> entry: mxMessage.getFieldMap().entrySet()) {
				Field field = entry.getValue();
				field.accept(this, data);
			}
			
			handler.endElement(mainNamespaceURI, MxMessage.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(Restriction restriction, Object data) {
		
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			if (restriction.getMinLength() != null) {
				restriction.getMinLength().accept(this, data);
				MinLength minLength = restriction.getMinLength();
				attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.MINLENGTH, Empty.STRING,
						Attribute.Types.CDATA, minLength.getValue());
			}

			handler.startElement(mainNamespaceURI, Restriction.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, Restriction.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(Pattern value, Object data) {
		
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.PATTERN, Empty.STRING,
						Attribute.Types.CDATA, value.getValue());
			
			handler.startElement(mainNamespaceURI, Pattern.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, Pattern.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(MinLength value, Object data) {

		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.MINLENGTH, Empty.STRING,
						Attribute.Types.CDATA, value.getValue());
			
			handler.startElement(mainNamespaceURI, MinLength.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, MinLength.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(MaxLength value, Object data) {
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.MAXLENGTH, Empty.STRING,
						Attribute.Types.CDATA, value.getValue());
			
			handler.startElement(mainNamespaceURI, MaxLength.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, MaxLength.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(FractionDigits value, Object data) {
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.FRACTIONDIGITS, Empty.STRING,
						Attribute.Types.CDATA, value.getValue());
			
			handler.startElement(mainNamespaceURI, FractionDigits.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, FractionDigits.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(TotalDigits value, Object data) {
		
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.TOTALDIGITS, Empty.STRING,
						Attribute.Types.CDATA, value.getValue());
			
			handler.startElement(mainNamespaceURI, TotalDigits.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, TotalDigits.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

	@Override
	public Object visit(Enumeration value, Object data) {
		
		ContentHandler handler = (ContentHandler) data;
		try {
			attributes.clear();

			attributes.addAttribute(mainNamespaceURI, MXMessageNamespace.Attributes.ENUMERATION, Empty.STRING,
						Attribute.Types.CDATA, value.getValue());
			
			handler.startElement(mainNamespaceURI, Enumeration.ELEMENT, Empty.STRING, attributes);

			handler.endElement(mainNamespaceURI, Enumeration.ELEMENT, Empty.STRING);

		} catch (SAXException se) {
			throw new XMLVisitorException(se);
		}
		return data;
	}

}