package com.misys.tiplus2.catalog.swift.message.map.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice.Choice;
import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.MessageMapVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Message Map
 * 
 * 
 * @author DaiD1
 * 
 */
public class MessageMap extends SAXBaseElement {

    public static final String ELEMENT = "message-map";

    private String name;
    private String message;
    private String include;
    private String description;
    private String sourceName;

    private List<HeaderField> headerTagFields = new ArrayList<HeaderField>();
    private List<DataTypeChoice> dataTypeChoices = new ArrayList<DataTypeChoice>();

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof HeaderField) {
            addHeaderField((HeaderField) element);
        } else if (element instanceof DataField) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((DataField) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof MarkerField) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((MarkerField) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof DataBlock) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((DataBlock) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof FieldOptions) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((FieldOptions) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof SequenceMap) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((SequenceMap) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof Embedded) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((Embedded) element);
            addDataTypeChoice(dataTypeChoice);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("name".equals(name)) {
            setName(value);
        } else if ("message".equals(name)) {
            setMessage(value);
        } else if ("include".equals(name)) {
            setInclude(value);
        } else if ("description".equals(name)) {
            setDescription(value);
        } else if ("source-name".equals(name)) {
            setSourceName(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageMapVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    private void setMessage(String message) {
        this.message = message;
    }

    public String getInclude() {
        if (include == null && !name.startsWith("swift_envelope")) {
            include = "swift_envelope";
        }
        return include;
    }

    private void setInclude(String include) {
        this.include = include;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSourceName() {
        return sourceName;
    }

    private void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public List<DataBlock> getDataBlocks() {
        List<DataBlock> result = new ArrayList<DataBlock>();
       
        for (DataTypeChoice choice : dataTypeChoices) {
            if (choice.getChosen() == Choice.DATABLOCK) {
                result.add(choice.getDataBlock());
            }
            
            if (choice.getChosen() == Choice.SEQUENCEMAP) {
                for (DataTypeChoice c:choice.getSequenceMap().getDataTypeChoices()) {
                    if (c.getChosen() == Choice.DATABLOCK) {
                        result.add(c.getDataBlock());
                    }
                }
            }
        }
        return result;
    }

    public List<DataField> getDataFields() {

        List<DataField> result = new ArrayList<DataField>();
        for (DataTypeChoice choice : dataTypeChoices) {
            if (choice.getChosen() == Choice.DATAFIELD) {
                result.add(choice.getDataField());
            }
            
            if (choice.getChosen() == Choice.SEQUENCEMAP) {
                for (DataTypeChoice c:choice.getSequenceMap().getDataTypeChoices()) {
                    if (c.getChosen() == Choice.DATAFIELD) {
                        result.add(c.getDataField());
                    }
                }
            }
        }
        return result;
    }

    public List<MarkerField> getMarkerFields() {

        List<MarkerField> result = new ArrayList<MarkerField>();
        for (DataTypeChoice choice : dataTypeChoices) {
            if (choice.getChosen() == Choice.MARKERFIELD) {
                result.add(choice.getMarkerField());
            }
            
            if (choice.getChosen() == Choice.SEQUENCEMAP) {
                for (DataTypeChoice c:choice.getSequenceMap().getDataTypeChoices()) {
                    if (c.getChosen() == Choice.MARKERFIELD) {
                        result.add(c.getMarkerField());
                    }
                }
            }
        }
        return result;
    }

   
    public void addHeaderField(HeaderField headerField) {
        this.headerTagFields.add(headerField);
    }

    public List<HeaderField> getHeaderFields() {
        return headerTagFields;
    }

    public void addDataTypeChoice(DataTypeChoice choice) {
        this.dataTypeChoices.add(choice);
    }

    public void addDataTypeChoice(List<DataTypeChoice> typeChoices) {
        
        List<DataTypeChoice> temp = new ArrayList<DataTypeChoice>();
        
        for (DataTypeChoice tc: typeChoices){
            temp.add(tc);
        }
        
        for (DataTypeChoice tc:dataTypeChoices){
            temp.add(tc);
        }
        
        this.dataTypeChoices = temp;
    }

    public List<DataTypeChoice> getDataTypeChoices() {
        return this.dataTypeChoices;
    }
    
    public DataField getDataField(String tag, String sequence) {
        DataField result = null;
        if (sequence!=null && tag!=null) {
            for (DataTypeChoice choice : dataTypeChoices) {
                if (choice.getChosen() == Choice.SEQUENCEMAP && 
                        sequence.equals(choice.getSequenceMap().getName())) {
                    for (DataTypeChoice c:choice.getSequenceMap().getDataTypeChoices()) {
                        if (c.getChosen() == Choice.DATAFIELD 
                                && tag.equals(c.getDataField().getTag())) {
                            result = c.getDataField();
                        }
                    }
                }
            }
        } else if (tag!=null) {
            for (DataTypeChoice choice : dataTypeChoices) {
                if (choice.getChosen() == Choice.DATAFIELD) {
                    if (tag.equals(choice.getDataField().getTag())) {
                        result = choice.getDataField();
                    }
                }
            }
        }
        return result;
    }
    
    public MarkerField getMarkerField(String tag, String sequence) {
        
        MarkerField result = null;
        if (tag!=null && sequence!=null) {
            for (DataTypeChoice choice : dataTypeChoices) {
                if (choice.getChosen() == Choice.SEQUENCEMAP && 
                        sequence.equals(choice.getSequenceMap().getName())) {
                    for (DataTypeChoice c:choice.getSequenceMap().getDataTypeChoices()) {
                        if (c.getChosen() == Choice.MARKERFIELD 
                                && tag.equals(c.getMarkerField().getTag())) {
                            result = c.getMarkerField();
                        }
                    }
                }
            }
        } else if (tag!=null) {
            for (DataTypeChoice choice : dataTypeChoices) {
                if (choice.getChosen() == Choice.MARKERFIELD) {
                    if (tag.equals(choice.getMarkerField().getTag())) {
                        result = choice.getMarkerField();
                    }
                }
            }
        }
        return result;
    }
    
    public DataBlock getDataBlock(String name, String sequence) {
        DataBlock result = null;
        
        if (sequence!=null && name!=null) {
            for (DataTypeChoice choice : dataTypeChoices) {
                if (choice.getChosen() == Choice.SEQUENCEMAP && 
                        sequence.equals(choice.getSequenceMap().getName())) {
                    for (DataTypeChoice c:choice.getSequenceMap().getDataTypeChoices()) {
                        if (c.getChosen() == Choice.DATABLOCK 
                                && name.equals(c.getDataBlock().getName())) {
                            result = c.getDataBlock();
                        }
                    }
                }
            }
        } else if (name!=null) {
            for (DataTypeChoice choice : dataTypeChoices) {
                if (choice.getChosen() == Choice.DATABLOCK && 
                        name.equals(choice.getDataBlock().getName())){
                    result = choice.getDataBlock();
                }
            }
        }
        
        return result;
    }

    public void addHeaderFields(List<HeaderField> headerFields) {
        this.headerTagFields = headerFields;
    }

    public List<Embedded> getEmbeddedMessages() {

        List<Embedded> result = new ArrayList<Embedded>();
        for (DataTypeChoice choice : dataTypeChoices) {
            if (choice.getChosen() == Choice.EMBEDDED) {
                result.add(choice.getEmbedded());
            }
        }
        return result;
    }    
}
