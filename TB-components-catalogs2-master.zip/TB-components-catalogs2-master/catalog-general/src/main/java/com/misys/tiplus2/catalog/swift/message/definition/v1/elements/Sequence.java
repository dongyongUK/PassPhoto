package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.groups.FieldTypeChoice;
import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Sequence
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class Sequence extends SAXBaseElement {

    public static final String ELEMENT = "sequence";

    private String name;
    private String mandatory = "";

    private List<FieldTypeChoice> fieldTypeChoices = new ArrayList<FieldTypeChoice>();
    

    @Override
    public void setElement(SAXElement element) throws XMLException {

        if (element instanceof Field) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Field) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Marker) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Marker) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Repeat) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Repeat) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Options) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Options) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("name".equals(name)) {
            setName(value);
        } else if ("mandatory".equals(name)) {
            setMandatory(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public void addFieldTypeChoice(FieldTypeChoice choice) {
        this.fieldTypeChoices.add(choice);
    }

    public List<FieldTypeChoice> getFieldTypeChoices() {
        return this.fieldTypeChoices;
    }
    
    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getMandatory() {
        return mandatory;
    }

    private void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }
}
