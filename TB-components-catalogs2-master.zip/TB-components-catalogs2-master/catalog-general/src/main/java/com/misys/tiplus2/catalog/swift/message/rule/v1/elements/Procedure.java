package com.misys.tiplus2.catalog.swift.message.rule.v1.elements;

import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.MessageRuleVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Validation process uses the following 3 types of procedures
 * 
 * 1.  <error:'id'>
 * 2.  <exit>
 * 3.  <continue>
 * 
 * @author DaiD1
 * TSDS-40844
 *
 */
public class Procedure extends SAXBaseElement {

    public static final String ELEMENT = "procedure";

    private String type; 
    // then, else, or null
    
    private String terminate; 
    // error, exit, or continue
    
    private String value; 
    // error id
    
    private String tag; 
    // error for specified tag, or field tag 
    
    private String subValueIndex; 
    // Can be single index "3"; range index e.g:  "5-9",
    // or range lines, such "1:1" for the first line of address, "2:5" for line 2 to 5 

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("value".equals(name)) {
            setValue(value);
        } else if ("type".equals(name)) {
            setType(value);
        } else if ("terminate".equals(name)) {
            setTerminate(value);
        } else if ("tag".equals(name)) {
            setTag(value);
        } else if ("sub-value-index".equals(name)) {
            setSubValueIndex(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    public String getType() {
        return type;
    }

    private void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    private void setValue(String value) {
        this.value = value;
    }

    public String getTerminate() {
        return terminate;
    }

    private void setTerminate(String terminate) {
        this.terminate = terminate;
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }

    
    public String getSubValueIndex() {
		return subValueIndex;
	}

	public void setSubValueIndex(String subValueIndex) {
		this.subValueIndex = subValueIndex;
	}

	@Override
    public Object accept(Visitor visitor, Object data) {

        return ((MessageRuleVisitor) visitor).visit(this, data);
    }
}
