package com.misys.tiplus2.catalog.swift.message.map.v1.elements;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.MessageMapVisitor;
import com.misys.tiplus2.foundations.lang.contract.AssertArgument;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * MessageMaps
 * 
 * 
 * 
 * @author DaiD1
 * 
 */
public class MessageMaps extends SAXBaseElement {

    public static final String ELEMENT = "message-maps";
    private List<MessageMap> messageMaps = new ArrayList<MessageMap>();
    private Map<String, MessageMap> messageMapsByName = new HashMap<String, MessageMap>();
    private Map<String, MessageMap> messageMapsByMessage = new HashMap<String, MessageMap>();
    private Map<String, MessageMap> messageMapsBySourceName = new HashMap<String, MessageMap>();
    private List<MessageMap> blockList = new ArrayList<MessageMap>();

    private String version;

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("version".equals(name)) {
            setVersion(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof MessageMap) {
            addMessageMap((MessageMap) element);
        } else {
            super.setElement(element);
        }
    }

    public List<MessageMap> getMessageMaps() {
        return messageMaps;
    }

    public void addMessageMap(MessageMap messageMap) {
        this.messageMaps.add(messageMap);
        this.messageMapsByName.put(messageMap.getName(), messageMap);
        this.messageMapsByMessage.put(messageMap.getMessage(), messageMap);
        this.messageMapsBySourceName.put(messageMap.getSourceName(), messageMap);
        if (messageMap.getMessage().startsWith("block")) {
            blockList.add(messageMap);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageMapVisitor) visitor).visit(this, data);
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public MessageMap getMessageByName(String name) {
        AssertArgument.notNull(name, "name");
        return messageMapsByName.get(name);
    }

    public MessageMap getMessageByMessage(String message) {
        AssertArgument.notNull(message, "message");
        return messageMapsByMessage.get(message);
    }

    public MessageMap getMessageBySourceName(String sourceName) {
        AssertArgument.notNull(sourceName, "sourceName");
        return messageMapsBySourceName.get(sourceName);
    }

    public List<MessageMap> getBlockList() {
        return blockList;
    }

    public MessageMap getBlock(String message) {
        AssertArgument.notNull(message, "message");
        MessageMap result = null;

        for (MessageMap block : blockList) {
            if (block.getMessage().equals(message)) {
                result = block;
                break;
            }
        }
        return result;
    }
}
