package com.misys.tiplus2.catalog.swift.message.map.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.MessageMapVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * FieldOptions
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class FieldOptions extends SAXBaseElement {

    public static final String ELEMENT = "field-options";

    private String tag;
 
    private List<DataField> dataFields = new ArrayList<DataField>();

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof DataField) {
            addDataField((DataField) element);
        } else {
            super.setElement(element);
        }
    }

    public List<DataField> getDataFields() {
        return dataFields;
    }

    public void addDataField(DataField dataField) {
        this.dataFields.add(dataField);
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("tag".equals(name)) {
            setTag(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageMapVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public void setDataFields(List<DataField> dataFields) {

        this.dataFields.clear();
        this.dataFields.addAll(dataFields);
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }
}
