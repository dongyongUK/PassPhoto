package com.misys.tiplus2.catalog.swift.message.rule.v1.visitor;

import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.MessageRules;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Statement;
import com.misys.tiplus2.foundations.xml.Visitor;

/**
 * 
 * @author DaiD1
 * TSDS-40844
 */
public interface MessageRuleVisitor extends Visitor {

    Object visit(MessageRules value, Object data);
    Object visit(Construct value, Object data);
    Object visit(Statement value, Object data);
    Object visit(Component value, Object data);
    Object visit(Procedure procedure, Object data);
   
}
