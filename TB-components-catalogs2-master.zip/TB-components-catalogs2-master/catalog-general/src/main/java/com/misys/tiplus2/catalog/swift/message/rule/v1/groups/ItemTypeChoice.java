package com.misys.tiplus2.catalog.swift.message.rule.v1.groups;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Statement;
import com.misys.tiplus2.foundations.lang.contract.AssertState;

/**
 * 
 * @author DaiD1
 * TSDS-40844
 */

public class ItemTypeChoice {

    public enum Choice {
        CONSTRUCT, STATEMENT, PROCEDURE
    }

    private Construct construct;

    private Statement statement;
   
    private Procedure procedure;

    private final Choice chosen;

    public ItemTypeChoice(Construct construct) {
        this.construct = construct;
        this.chosen = Choice.CONSTRUCT;
    }

    public ItemTypeChoice(Statement statement) {
        this.statement = statement;
        this.chosen = Choice.STATEMENT;
    }

    public ItemTypeChoice(Procedure procedure) {
        this.procedure = procedure;
        this.chosen = Choice.PROCEDURE;
    }

    public Choice getChosen() {
        Choice result = chosen;
        if (result == null) {
            result = Choice.CONSTRUCT;
        }
        return result;
    }

    public Construct getConstruct() {
        AssertState.isTrue(getChosen() == Choice.CONSTRUCT, "Construct was not chosen");
        return construct;
    }

    public Statement getStatement() {
        AssertState.isTrue(getChosen() == Choice.STATEMENT, "Statement was not chosen");
        return statement;
    }

    public Procedure getProcedure() {
        AssertState.isTrue(getChosen() == Choice.PROCEDURE, "Procedure was not chosen");
        return procedure;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("Construct", construct)
                .append("Statement", statement)
                .append("Procedure", procedure)
                .appendSuper(super.toString()).toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((chosen == null) ? 0 : chosen.hashCode());
        result = prime * result + ((construct== null) ? 0 : construct.hashCode());
        result = prime * result + ((statement == null) ? 0 : statement.hashCode());
        result = prime * result + ((procedure == null) ? 0 : procedure.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ItemTypeChoice other = (ItemTypeChoice) obj;
        if (chosen != other.chosen) {
            return false;
        }
        if (construct == null) {
            if (other.construct != null) {
                return false;
            }
        } else if (!construct.equals(other.construct)) {
            return false;
        }
        
        if (statement == null) {
            if (other.statement != null) {
                return false;
            }
        } else if (!statement.equals(other.statement)) {
            return false;
        }
        
        if (procedure == null) {
            if (other.procedure != null) {
                return false;
            }
        } else if (!procedure.equals(other.procedure)) {
            return false;
        }
        return true;
    }
}
