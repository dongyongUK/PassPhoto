package com.misys.tiplus2.catalog.swift.message.map.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.MessageMapVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Sequence Map
 * 
 * 
 * @author DaiD1
 * 
 */
public class SequenceMap extends SAXBaseElement {

    public static final String ELEMENT = "sequence-map";

    private String name;

    private List<DataTypeChoice> dataTypeChoices = new ArrayList<DataTypeChoice>();

    @Override
    public void setElement(SAXElement element) throws XMLException {

        if (element instanceof DataField) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((DataField) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof MarkerField) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((MarkerField) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof DataBlock) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((DataBlock) element);
            addDataTypeChoice(dataTypeChoice);
        } else if (element instanceof FieldOptions) {
            DataTypeChoice dataTypeChoice = new DataTypeChoice((FieldOptions) element);
            addDataTypeChoice(dataTypeChoice);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("name".equals(name)) {
            setName(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageMapVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public void addDataTypeChoice(DataTypeChoice choice) {
        this.dataTypeChoices.add(choice);
    }
    
    public List<DataTypeChoice> getDataTypeChoices() {
        return this.dataTypeChoices;
    }
    
}
