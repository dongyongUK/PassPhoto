package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.groups.FieldTypeChoice;
import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Variant
 * 
 * 
 * 
 * @author DaiD1
 * 
 */
public class Variant extends SAXBaseElement {

    public static final String ELEMENT = "variant";
    private String value;
    private String description;
    // Default max length for outgoing FIN
    private String maxLength="10000";

    private List<FieldTypeChoice> fieldTypeChoices = new ArrayList<FieldTypeChoice>();

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("value".equals(name)) {
            setValue(value);
        } else if ("description".equals(name)) {
            setDescription(value);
        } else if ("max-length".equals(name)) {
            setMaxLength(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {

        if (element instanceof Field) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Field) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Marker) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Marker) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Repeat) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Repeat) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Options) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Options) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else if (element instanceof Sequence) {
            FieldTypeChoice fieldTypeChoice = new FieldTypeChoice((Sequence) element);
            addFieldTypeChoice(fieldTypeChoice);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public void addFieldTypeChoice(FieldTypeChoice choice) {
        this.fieldTypeChoices.add(choice);
    }

    public List<FieldTypeChoice> getFieldTypeChoices() {
        return this.fieldTypeChoices;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMaxLength() {
        return maxLength;
    }

    public void setMaxLength(String maxLength) {
        this.maxLength = maxLength;
    }

}