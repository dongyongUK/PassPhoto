package com.misys.tiplus2.catalog.swift.message.rule.v1;

import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.MessageRuleDocumentVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.sax.common.DefaultElementBroker;

/**
 * TSDS-40844
 * @author DaiD1
 *
 */
public class ElementBroker extends DefaultElementBroker {

    @Override
    protected String getPackageName() {
        return ElementBroker.class.getPackage().getName() + ".elements";
    }

    @Override
    protected Visitor getContentHandlerVisitor() {        
        return new MessageRuleDocumentVisitor();
    }
}
