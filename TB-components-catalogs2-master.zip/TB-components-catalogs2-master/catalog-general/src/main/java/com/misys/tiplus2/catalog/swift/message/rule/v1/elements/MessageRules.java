package com.misys.tiplus2.catalog.swift.message.rule.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.MessageRuleVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * 
 * @author DaiD1
 * TSDS-40844
 * 
 */
public class MessageRules extends SAXBaseElement {

    public static final String ELEMENT = "message-rules";

    private List<Construct> messageRuleList = new ArrayList<Construct>();
    private String version;

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("version".equals(name)) {
            setVersion(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Construct) {
            addConstruct((Construct) element);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageRuleVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public List<Construct> getMessageRuleList() {
        return this.messageRuleList;
    }

    public void addConstruct(Construct construct) {
        messageRuleList.add(construct);
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Construct findMessageRuleById(String ruleId) {

        Construct result = null;
        for (Construct construct : messageRuleList) {

            if (construct.getRuleId() != null && construct.getRuleId().equals(ruleId)) {
                result = construct;
                break;
            }
        }

        return result;
    }
}