package com.misys.tiplus2.catalog.swift.message.rule;

import com.misys.tiplus2.catalog.swift.message.rule.v1.ElementBroker;
import com.misys.tiplus2.foundations.xml.namespace.Namespace;
import com.misys.tiplus2.foundations.xml.namespace.NamespaceException;
import com.misys.tiplus2.foundations.xml.namespace.Namespaces;
import com.misys.tiplus2.foundations.xml.namespace.StrictNamespaces;

/**
 * Namespace for message rule
 * 
 * TSDS-40844
 * @author DaiD1
 *
 */
public class MessageRuleNamespace {

    public static final String URI = "urn:rule.message.swift.catalog.tiplus2.misys.com";
    public static final String PREFIX = "mr";

    public static final String DOCUMENT_ELEMENT = "swift-message-rule";

    public static final Namespace NAMESPACE;
    static {
        NAMESPACE = new Namespace(URI, PREFIX);
        NAMESPACE.addDefaultElementBroker(DOCUMENT_ELEMENT, "1.0", new ElementBroker());
    }

    public static class Attributes {
        
        public static final String VERSION = "version";
        public static final String NAME = "name";
        public static final String RULE_ID = "rule-id";
        public static final String MESSAGE = "message";
        public static final String OPERATOR = "operator";
        public static final String SEQUENCE = "sequence";
        public static final String TYPE = "type";
        public static final String FIELD = "field";
        public static final String SUB_VALUE_INDEX = "sub-value-index";
        public static final String VALUE = "value";
        public static final String FUNCTION = "value";
        public static final String TERMINATE = "terminate";
        public static final String TAG = "tag";
        public static final String PATTERN = "pattern";
        public static final String PREDICATE = "predicate";
        public static final String ARGUMENTS = "arguments";
    }

    public static Namespaces getNamespaces() {
        Namespaces result = new StrictNamespaces();
        addToNamespaces(result);
        return result;
    }

    public static void addToNamespaces(Namespaces namespaces) {
        try {
            namespaces.addNamespace(NAMESPACE);
        } catch (NamespaceException ne) {
            // TODO throw runtime exception
        }
    }
}
