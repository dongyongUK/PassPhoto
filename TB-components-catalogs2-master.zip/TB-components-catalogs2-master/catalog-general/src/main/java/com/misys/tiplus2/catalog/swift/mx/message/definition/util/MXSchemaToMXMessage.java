package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

/**
 * Convert MX schema into MX message definition. Multiple files from a folder
 * 
  * @author DaiD1
 */
import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;

import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XMLSchemaNode;
import oracle.xml.parser.schema.XSDBuilder;

public class MXSchemaToMXMessage {

    static String INPUT_DIR = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
            + File.separator + "resources" + File.separator + "MXSchema";
    static String OUtPUT_DIR = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
            + File.separator + "resources" + File.separator + "MXMessage";

    static String outFileName = "mx-messages.xml";
    static XMLSchemaNode rootNode;
    final static String XS = "xs:";

    public static void main(String[] args) {

        // Input Schema Dir
        if (args.length > 0) {
            INPUT_DIR = args[0];
        }
        // output file dir
        if (args.length > 1) {
            OUtPUT_DIR = args[1];
        }

        String output_fileName = OUtPUT_DIR + File.separator + outFileName;

        Map<String, Tag> globalTags = new HashMap<String, Tag>();
        File[] listFiles = null;

        try {
            listFiles = getFilesFromDir(INPUT_DIR, "xsd");
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        FileOutputStream foutputstream = null;
        String fileHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "\r\n<mx-messages xmlns=\"urn:definition.message.mx.swift.catalog.tiplus2.misys.com\" version=\"1.0\">";

        try {

            boolean isFirstFile = true;
            for (File xsdFile : listFiles) {
                System.out.println("Schema: " + xsdFile.getName());
                XSDBuilder builder = new XSDBuilder();
                URL url = xsdFile.toURI().toURL();
                // Build XML Schema Object
                XMLSchema schema = (XMLSchema) builder.build(url);

                // write mx-message
                MXSchemaToMXMessageConverter converter = new MXSchemaToMXMessageConverter();
                Map<String, Tag> localTags = new HashMap<String, Tag>();
                String output = converter.convertMXSchema(schema, localTags);

                if (isFirstFile) {
                    // no append to existing file
                    foutputstream = new FileOutputStream(output_fileName);
                    writeToOutputStream(fileHeader, output, foutputstream);
                    isFirstFile = false;
                    globalTags.putAll(localTags);
                } else {
                    // append to existing file
                    foutputstream = new FileOutputStream(output_fileName, true);
                    writeToOutputStream(null, output, foutputstream);
                    SchemaConverterHelper.addTags(localTags, globalTags);
                }
            }

            StringBuilder alltagsBuilder = new StringBuilder();
            SchemaConverterHelper.printTags(globalTags, alltagsBuilder);
            // append tails
            alltagsBuilder.append("\\r\n</mx-messages>");
            foutputstream = new FileOutputStream(output_fileName, true);
            writeToOutputStream(null, alltagsBuilder.toString(), foutputstream);

        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    private static File[] getFilesFromDir(String DirPath, String ext) throws IOException {

        File[] result = null;
        File dir = new File(DirPath);
        if (dir.isDirectory()) {
            FileFilter fileFilter = (file) -> {
                return file.getName().endsWith("." + ext);
            };
            result = dir.listFiles(fileFilter);
        }
        return result;
    }

    private static void writeToOutputStream(String header, String data, FileOutputStream foutstream) throws Exception {

        if (header != null) {
            foutstream.write(header.getBytes(StandardCharsets.UTF_8));
        }
        if (data != null) {
            foutstream.write(data.getBytes(StandardCharsets.UTF_8));
        }
        foutstream.close();
    }
}