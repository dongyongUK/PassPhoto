package com.misys.tiplus2.catalog.swift.message.definition.v1;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageDocumentVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.sax.common.DefaultElementBroker;

public class ElementBroker extends DefaultElementBroker {

    @Override
    protected String getPackageName() {
        return ElementBroker.class.getPackage().getName() + ".elements";
    }

    @Override
    protected Visitor getContentHandlerVisitor() {        
        return new FinMessageDocumentVisitor();
    }
}
