/**
 * 
 */
package com.misys.tiplus2.catalog.swift.message.definition.v1.visitor;

import java.util.List;
import java.util.Map.Entry;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.misys.tiplus2.catalog.swift.message.definition.FinMessageNamespace;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Block;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessage;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessages;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Marker;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Options;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Repeat;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Sequence;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Variant;
import com.misys.tiplus2.catalog.swift.message.definition.v1.groups.FieldTypeChoice;
import com.misys.tiplus2.foundations.lang.constants.Empty;
import com.misys.tiplus2.foundations.xml.XMLVisitorException;
import com.misys.tiplus2.foundations.xml.attribute.Attribute;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributes;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributesHelper;

/**
 * @author DaiD1
 *
 */
public class FinMessageDocumentVisitor implements FinMessageVisitor {

    protected ElementAttributes attributes = new ElementAttributes();
    protected String mainNamespaceURI;

    public FinMessageDocumentVisitor() {
        mainNamespaceURI = FinMessageNamespace.URI;
    }

    @Override
    public Object visit(Field field, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();

            if (field.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, field.getTag());
            }

            if (field.getMandatory() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.MANDATORY, Empty.STRING,
                        Attribute.Types.CDATA, field.getMandatory());
            }
            if (field.getDescription() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.DESCRIPTION, Empty.STRING,
                        Attribute.Types.CDATA, field.getDescription());
            }
            if (field.getDefaultValue() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.DEFAULT_VALUE, Empty.STRING,
                        Attribute.Types.CDATA, field.getDefaultValue());
            }

            if (field.getCodes() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.CODES, Empty.STRING,
                        Attribute.Types.CDATA, field.getCodes());
            }

            handler.startElement(mainNamespaceURI, Field.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, Field.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Marker marker, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();
            if (marker.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, marker.getTag());
            }
            if (marker.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, marker.getName());
            }
            if (marker.getMandatory() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.MANDATORY, Empty.STRING,
                        Attribute.Types.CDATA, marker.getMandatory());
            }

            handler.startElement(mainNamespaceURI, Marker.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, Marker.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Repeat repeatBlock, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();

            if (repeatBlock.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, repeatBlock.getName());
            }

            if (repeatBlock.getRepeat() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.REPEAT, Empty.STRING,
                        Attribute.Types.CDATA, repeatBlock.getRepeat());
            }

            handler.startElement(mainNamespaceURI, Repeat.ELEMENT, Empty.STRING, attributes);

            for (FieldTypeChoice choice : repeatBlock.getFieldTypeChoices()) {
                switch (choice.getChosen()) {
                case FIELD:
                    choice.getField().accept(this, data);
                    break;
                case OPTIONS:
                    choice.getOptions().accept(this, data);
                    break;
                default:
                    break;
                }
            }

            handler.endElement(mainNamespaceURI, Repeat.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(Options options, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();

            if (options.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, options.getTag());
            }

            if (options.getMandatory() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.MANDATORY, Empty.STRING,
                        Attribute.Types.CDATA, options.getMandatory());
            }

            handler.startElement(mainNamespaceURI, Options.ELEMENT, Empty.STRING, attributes);

            List<Field> fieldList = options.getFields();
            for (Field f : fieldList) {
                f.accept(this, data);
            }

            handler.endElement(mainNamespaceURI, Options.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Variant variant, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();
            if (variant.getValue() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.VALUE, Empty.STRING,
                        Attribute.Types.CDATA, variant.getValue());
            }

            if (variant.getDescription() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.DESCRIPTION, Empty.STRING,
                        Attribute.Types.CDATA, variant.getDescription());
            }

            if (variant.getMaxLength() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.MAX_LENGTH, Empty.STRING,
                        Attribute.Types.CDATA, variant.getMaxLength());
            }

            handler.startElement(mainNamespaceURI, Variant.ELEMENT, Empty.STRING, attributes);

            for (FieldTypeChoice choice : variant.getFieldTypeChoices()) {
                switch (choice.getChosen()) {
                case FIELD:
                    choice.getField().accept(this, data);
                    break;
                case MARKER:
                    choice.getMarker().accept(this, data);
                    break;
                case REPEAT:
                    choice.getRepeat().accept(this, data);
                    break;
                case OPTIONS:
                    choice.getOptions().accept(this, data);
                    break;
                case SEQUENCE:
                    choice.getSequence().accept(this, data);
                    break;
                default:
                    break;
                }
            }

            handler.endElement(mainNamespaceURI, Variant.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(Block block, Object data) {
        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();
            if (block.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, block.getName());
            }

            if (block.getNumber() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.NUMBER, Empty.STRING,
                        Attribute.Types.CDATA, block.getNumber());
            }

            if (block.getType() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.TYPE, Empty.STRING,
                        Attribute.Types.CDATA, block.getType());
            }

            if (block.getVariantType() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.VARIANT_TYPE, Empty.STRING,
                        Attribute.Types.CDATA, block.getVariantType());
            }

            handler.startElement(mainNamespaceURI, Block.ELEMENT, Empty.STRING, attributes);

            for (Entry<String, Variant> entry : block.getVariants().entrySet()) {
                entry.getValue().accept(this, data);
            }

            handler.endElement(mainNamespaceURI, Block.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(Tags tags, Object data) {
        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();

            handler.startElement(mainNamespaceURI, Tags.ELEMENT, Empty.STRING, attributes);

            for (Entry<String, Tag> entry : tags.getTagsByName().entrySet()) {
                entry.getValue().accept(this, data);
            }

            handler.endElement(mainNamespaceURI, Tags.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(FinMessages finMessages, Object data) {
        ContentHandler handler = (ContentHandler) data;

        try {

            handler.startDocument();

            ElementAttributesHelper.addDefaultNamespaceAttribute(attributes.clear(), mainNamespaceURI);
            if (finMessages.getVersion() != null) {
                attributes.addAttribute(mainNamespaceURI, "version", Empty.STRING, Attribute.Types.CDATA,
                        finMessages.getVersion());
            }

            handler.startElement(mainNamespaceURI, FinMessages.ELEMENT, Empty.STRING, attributes);

            for (FinMessage finMessage : finMessages.getFinMessageList()) {
                finMessage.accept(this, data);
            }
            finMessages.getTags().accept(this, data);

            handler.endElement(mainNamespaceURI, FinMessages.ELEMENT, Empty.STRING);

            handler.endDocument();

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(Tag tag, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();

            if (tag.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, tag.getName());
            }

            if (tag.getFormat() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.FORMAT, Empty.STRING,
                        Attribute.Types.CDATA, tag.getFormat());
            }

            if (tag.getType() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.TYPE, Empty.STRING,
                        Attribute.Types.CDATA, tag.getType());
            }

            handler.startElement(mainNamespaceURI, Tag.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, Tag.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(FinMessage finMessage, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();
            if (finMessage.getServiceId() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.SERVICE_ID, Empty.STRING,
                        Attribute.Types.CDATA, finMessage.getServiceId());
            }

            handler.startElement(mainNamespaceURI, FinMessage.ELEMENT, Empty.STRING, attributes);

            for (Block block : finMessage.getBlockList()) {
                block.accept(this, data);
            }

            handler.endElement(mainNamespaceURI, FinMessage.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Sequence sequence, Object data) {
        
        ContentHandler handler = (ContentHandler) data;
        
        try {
            attributes.clear();
            if (sequence.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, sequence.getName());
            }

            if (sequence.getMandatory() != null) {
                attributes.addAttribute(mainNamespaceURI, FinMessageNamespace.Attributes.MANDATORY, Empty.STRING,
                        Attribute.Types.CDATA, sequence.getMandatory());
            }

            handler.startElement(mainNamespaceURI, Sequence.ELEMENT, Empty.STRING, attributes);

            for (FieldTypeChoice choice : sequence.getFieldTypeChoices()) {
                switch (choice.getChosen()) {
                case FIELD:
                    choice.getField().accept(this, data);
                    break;
                case MARKER:
                    choice.getMarker().accept(this, data);
                    break;
                case REPEAT:
                    choice.getRepeat().accept(this, data);
                    break;
                case OPTIONS:
                    choice.getOptions().accept(this, data);
                    break;
                default:
                    break;
                }
            }
            handler.endElement(mainNamespaceURI, Sequence.ELEMENT, Empty.STRING);
        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }
}