package com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.visitor.MXMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * MXMessage
 * 
 * 
 * 
 * @author DaiD1
 * 
 */
public class MxMessage extends SAXBaseElement {

    public static final String ELEMENT = "mx-message";

    private String messageId;
    private String description;
    private Map<String, Field> fieldMap = new LinkedHashMap<String, Field>();

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("message-id".equals(name)) {
            setMessageId(value);
        } else if ("description".equals(name)) {
                setMessageId(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {
    	 if (element instanceof Field) {
             putField((Field) element);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MXMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

  
    public Map<String,Field> getFieldMap(){
    	return fieldMap;
    }
    
   
    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public void putField(Field field) {
		String key = field.getPath() + "."+field.getTag();
		// remove optional sign from key
		key= key.replace("|", "");
        fieldMap.put(key,field);
    }
    
	
	public Field getField(String path, String tag) {
		
		Field result = null;
		if (path!=null && tag!=null ) {
			String key = path+"."+tag;
		    result =  fieldMap.get(key);
		}
		
		return result;
	}
}