package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * A generic field, could be a header field, marker field or date field
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class Marker extends SAXBaseElement {

    public static final String ELEMENT = "marker";
    private String tag;
    private String name;
    private String description;
    private String mandatory = "";

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("tag".equals(name)) {
            setTag(value);
        } else if ("name".equals(name)) {
            setName(value);
        } else if ("description".equals(name)) {
            setDescription(value);
        } else if ("mandatory".equals(name)) {
            setMandatory(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getName() {

        if (name == null) {
            name = tag;
        }

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMandatory() {
        return mandatory;
    }

    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
