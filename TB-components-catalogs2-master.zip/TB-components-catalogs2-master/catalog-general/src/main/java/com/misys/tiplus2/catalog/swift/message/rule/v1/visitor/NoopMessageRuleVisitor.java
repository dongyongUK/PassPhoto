/**
 * 
 */
package com.misys.tiplus2.catalog.swift.message.rule.v1.visitor;

import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.MessageRules;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Statement;

/**
 * @author DaiD1
 * TSDS-40844
 */
public class NoopMessageRuleVisitor implements MessageRuleVisitor {

    @Override
    public Object visit(Construct value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Statement value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Procedure value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(MessageRules value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Component value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }
}
