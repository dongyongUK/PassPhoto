package com.misys.tiplus2.catalog.swift.message.rule.v1.elements;

import java.util.ArrayList;
import java.util.List;

import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.MessageRuleVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * There are 3 types: if, for and continue In the case of "continue", there is
 * no component within the statement, it will continue to procedure
 * 
 * Operators: Logical (AND, OR, NOT, XOR) Arithmetic (=, >, <, +(sum))
 * 
 * @author DaiD1
 *
 *         TSDS-40844
 */
public class Statement extends SAXBaseElement {

	public static final String ELEMENT = "statement";

	private String operator;
	private String type; // if or for
	private List<Component> components = new ArrayList<Component>();
	private List<Procedure> procedures = new ArrayList<Procedure>();

	@Override
	public void setElement(SAXElement element) throws XMLException {
		if (element instanceof Component) {
			addComponent((Component) element);
		} else if (element instanceof Procedure) {
			addProcedure((Procedure) element);
		} else {
			super.setElement(element);
		}
	}

	@Override
	public void setAttribute(String name, String value) throws XMLException {
		if ("operator".equals(name)) {
			setOperator(value);
		} else if ("type".equals(name)) {
			setType(value);
		} else {
			super.setAttribute(name, value);
		}
	}

	public String getOperator() {
		return operator;
	}

	private void setOperator(String operator) {
		this.operator = operator;
	}

	public String getType() {
		return type;
	}

	private void setType(String type) {
		this.type = type;
	}

	public void addComponent(Component component) {
		this.components.add(component);
	}

	public List<Component> getComponents() {
		return components;
	}

	public void addProcedure(Procedure procedure) {
		this.procedures.add(procedure);
	}

	public List<Procedure> getProcedures() {
		return procedures;
	}

	@Override
	public Object accept(Visitor visitor, Object data) {

		return ((MessageRuleVisitor) visitor).visit(this, data);
	}
}
