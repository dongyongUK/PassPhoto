package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class XMLTagExtractor {
    public List<String> main(String inputFile, String tagName, String attribute) {
        String xmlContent = "";
        // Initialize a list to store the tag contents
        List<String> tagContents = new ArrayList<>();
		try {
			xmlContent = readXmlFileToString(inputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (!xmlContent.contains("<root>"))
			xmlContent = "<root>".concat(xmlContent).concat("</root>");
		
		//System.out.println(xmlFile);

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(xmlContent)));

            // Find the mx-message tag with message-id="456"
            NodeList messageTags = doc.getElementsByTagName(tagName);
            
            if(messageTags.getLength() == 0 ) {
            	System.out.println("No tag " + tagName+ " found in " + inputFile);
            	System.exit(0);
            }

            for (int i = 0; i < messageTags.getLength(); i++) {
                Element messageTag = (Element) messageTags.item(i);
                String tagContent = getStringFromElement(messageTag);
                tagContents.add(tagContent);
            }
            
            // Print tags
//            for (int i = 0; i < tagContents.size(); i++) {
//                System.out.println("Result " + (i + 1) + ":");
//                System.out.println(tagContents.get(i));
//                System.out.println();
//            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
		return tagContents;
    }

    // Helper method to convert an XML element to a string
    private static String getStringFromElement(Element element) {
        StringWriter writer = new StringWriter();
        try {
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.transform(new DOMSource(element), new StreamResult(writer));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return writer.toString();
    }
    
    private static String readXmlFileToString(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        byte[] bytes = Files.readAllBytes(path);
        return new String(bytes);
    }
}
