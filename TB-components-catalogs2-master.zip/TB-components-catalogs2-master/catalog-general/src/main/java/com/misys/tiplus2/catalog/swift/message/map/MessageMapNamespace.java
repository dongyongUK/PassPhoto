package com.misys.tiplus2.catalog.swift.message.map;

import com.misys.tiplus2.catalog.swift.message.map.v1.ElementBroker;
import com.misys.tiplus2.foundations.xml.namespace.Namespace;
import com.misys.tiplus2.foundations.xml.namespace.NamespaceException;
import com.misys.tiplus2.foundations.xml.namespace.Namespaces;
import com.misys.tiplus2.foundations.xml.namespace.StrictNamespaces;

public class MessageMapNamespace {

    public static final String URI = "urn:map.message.swift.catalog.tiplus2.misys.com";
    public static final String PREFIX = "mmp";

    public static final String DOCUMENT_ELEMENT = "message-maps";

    public static final Namespace NAMESPACE;
    static {
        NAMESPACE = new Namespace(URI, PREFIX);
        NAMESPACE.addDefaultElementBroker(DOCUMENT_ELEMENT, "1.0", new ElementBroker());
    }

    public static class Attributes {
        public static final String VERSION = "version";
        public static final String NAME = "name";
        public static final String MESSAGE = "message";
        public static final String INCLUDE = "include";
        public static final String TAG = "tag";
        public static final String CONSTANT = "constant";
        public static final String RULE = "rule";
        public static final String PATH = "path";
        public static final String TYPE = "type";
        public static final String GROUP = "group";
        public static final String OPTIONS = "options";
        public static final String REPEAT = "repeat";
        public static final String SEQUENCE = "sequence";
        public static final String SOURCE_NAME = "source-name";
    }

    public static Namespaces getNamespaces() {
        Namespaces result = new StrictNamespaces();
        addToNamespaces(result);
        return result;
    }

    public static void addToNamespaces(Namespaces namespaces) {
        try {
            namespaces.addNamespace(NAMESPACE);
        } catch (NamespaceException ne) {
            // TODO throw runtime exception
        }
    }
}
