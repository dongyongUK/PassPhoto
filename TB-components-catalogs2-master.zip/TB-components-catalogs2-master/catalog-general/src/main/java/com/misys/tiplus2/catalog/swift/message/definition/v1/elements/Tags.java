package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 *
 * Tags
 *
 * @author DaiD1
 *
 */
public class Tags extends SAXBaseElement {

    public static final String ELEMENT = "tags";

    private Map<String, Tag> tagsByName = new HashMap<String, Tag>();

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Tag) {
            addTag((Tag) element);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public Map<String, Tag> getTagsByName() {
        return tagsByName;
    }

    public void addTag(Tag tag) {
        tagsByName.put(tag.getName(), tag);
    }

    public String getFormat(String name) {

        String result = null;

        Tag tag = findTagByName(name);
        if (tag != null) {
            result = tag.getFormat();
        }

        return result;
    }

    public Tag findTagByName(String name) {

        return tagsByName.get(name);

    }
}
