package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

public enum ElementAttribute {
	name,
	type,
	use,
	minOccurs,
	maxOccurs;
}
