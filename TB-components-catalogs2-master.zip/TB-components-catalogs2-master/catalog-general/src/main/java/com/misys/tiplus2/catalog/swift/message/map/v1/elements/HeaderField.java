package com.misys.tiplus2.catalog.swift.message.map.v1.elements;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.MessageMapVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * DataField
 * 
 * An element of Swift map
 * 
 * @author DaiD1
 * 
 */
public class HeaderField extends SAXBaseElement {

    public static final String ELEMENT = "header-field";

    private String name;
    private String path;
    private String tag;
    private String constant;
    private String rule;

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("name".equals(name)) {
            setName(value);
        } else if ("path".equals(name)) {
            setPath(value);
        } else if ("tag".equals(name)) {
            setTag(value);
        } else if ("constant".equals(name)) {
            setConstant(value);
        } else if ("rule".equals(name)) {
            setRule(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((MessageMapVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }

    public String getConstant() {
        return constant;
    }

    private void setConstant(String constant) {
        this.constant = constant;
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}
}
