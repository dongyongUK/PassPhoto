/**
 * 
 */
package com.misys.tiplus2.catalog.swift.message.definition.v1.visitor;

import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Block;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Field;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessage;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.FinMessages;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Marker;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Options;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Repeat;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Sequence;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Tags;
import com.misys.tiplus2.catalog.swift.message.definition.v1.elements.Variant;

/**
 * @author DaiD1
 *
 */
public class FinNoopMessageVisitor implements FinMessageVisitor {


    @Override
    public Object visit(Field value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }
    
    @Override
    public Object visit(Marker value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Repeat value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Block value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Tags value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(FinMessage value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Tag value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(FinMessages value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Variant value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Options value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object visit(Sequence value, Object data) {
        // TODO Auto-generated method stub
        return null;
    }
}
