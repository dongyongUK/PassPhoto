package com.misys.tiplus2.catalog.swift.message.map.v1.groups;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.SequenceMap;
import com.misys.tiplus2.foundations.lang.contract.AssertState;

public class DataTypeChoice {

    public enum Choice {
        DATAFIELD, MARKERFIELD, DATABLOCK, FIELDOPTIONS, EMBEDDED,SEQUENCEMAP
    }

    private DataField dataField;

    private MarkerField markerField;

    private DataBlock dataBlock;

    private FieldOptions fieldOptions;
    
    private Embedded embedded;
    
    private SequenceMap sequenceMap;

    private final Choice chosen;

    public DataTypeChoice(DataField dataField) {
        this.dataField = dataField;
        this.chosen = Choice.DATAFIELD;
    }

    public DataTypeChoice(MarkerField markerField) {
        this.markerField = markerField;
        this.chosen = Choice.MARKERFIELD;
    }

    public DataTypeChoice(DataBlock dataBlock) {
        this.dataBlock = dataBlock;
        this.chosen = Choice.DATABLOCK;
    }
    
    public DataTypeChoice(FieldOptions fieldOptions) {
        this.fieldOptions = fieldOptions;
        this.chosen = Choice.FIELDOPTIONS;
    }

    public DataTypeChoice(Embedded embedded) {
        this.embedded = embedded;
        this.chosen = Choice.EMBEDDED;
    }

    public DataTypeChoice(SequenceMap sequenceMap) {
        this.sequenceMap = sequenceMap;
        this.chosen = Choice.SEQUENCEMAP;
    }
    
    public Choice getChosen() {
        Choice result = chosen;
        if (result == null) {
            result = Choice.DATAFIELD;
        }
        return result;
    }

    public DataField getDataField() {
        AssertState.isTrue(getChosen() == Choice.DATAFIELD, "DataField was not chosen");
        return dataField;
    }

    public MarkerField getMarkerField() {
        AssertState.isTrue(getChosen() == Choice.MARKERFIELD, "MarkerField was not chosen");
        return markerField;
    }

    public DataBlock getDataBlock() {
        AssertState.isTrue(getChosen() == Choice.DATABLOCK, "DataBlock was not chosen");
        return dataBlock;
    }
    
    public FieldOptions getFieldOptions() {
        AssertState.isTrue(getChosen() == Choice.FIELDOPTIONS, "FieldOptions was not chosen");
        return fieldOptions;
    }

    public Embedded getEmbedded() {
        AssertState.isTrue(getChosen() == Choice.EMBEDDED, "Embedded was not chosen");
        return embedded;
    }

    public SequenceMap getSequenceMap() {
        AssertState.isTrue(getChosen() == Choice.SEQUENCEMAP, "SequenceMap was not chosen");
        return sequenceMap;
    }
    
    @Override
    public String toString() {
        return new ToStringBuilder(this).append("dataFieldType", dataField).append("DataBlockType", dataBlock)
                .append("FieldOptionsType", fieldOptions)
                .append("SequenceMapType", sequenceMap)
                .append("MarkerFieldType", markerField).append("EmbeddedType", embedded).append("chosen", chosen)
                .appendSuper(super.toString()).toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((chosen == null) ? 0 : chosen.hashCode());
        result = prime * result + ((dataField == null) ? 0 : dataField.hashCode());
        result = prime * result + ((markerField == null) ? 0 : markerField.hashCode());
        result = prime * result + ((dataBlock == null) ? 0 : dataBlock.hashCode());
        result = prime * result + ((fieldOptions == null) ? 0 : fieldOptions.hashCode());
        result = prime * result + ((sequenceMap == null) ? 0 : sequenceMap.hashCode());
        result = prime * result + ((embedded == null) ? 0 : embedded.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DataTypeChoice other = (DataTypeChoice) obj;
        if (chosen != other.chosen) {
            return false;
        }
        if (dataField == null) {
            if (other.dataField != null) {
                return false;
            }
        } else if (!dataField.equals(other.dataField)) {
            return false;
        }
        if (markerField == null) {
            if (other.markerField != null) {
                return false;
            }
        } else if (!markerField.equals(other.markerField)) {
            return false;
        }

        if (dataBlock == null) {
            if (other.dataBlock != null) {
                return false;
            }
        } else if (!dataBlock.equals(other.dataBlock)) {
            return false;
        }
        
        if (fieldOptions == null) {
            if (other.fieldOptions != null) {
                return false;
            }
        } else if (!fieldOptions.equals(other.fieldOptions)) {
            return false;
        }
        
        if (sequenceMap == null) {
            if (other.sequenceMap != null) {
                return false;
            }
        } else if (!sequenceMap.equals(other.sequenceMap)) {
            return false;
        }

        if (embedded == null) {
            if (other.embedded != null) {
                return false;
            }
        } else if (!embedded.equals(other.embedded)) {
            return false;
        }

        return true;
    }
}
