/**
 * 
 */
package com.misys.tiplus2.catalog.swift.message.rule.v1.visitor;

import java.util.List;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.misys.tiplus2.catalog.swift.message.rule.MessageRuleNamespace;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.MessageRules;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Statement;
import com.misys.tiplus2.catalog.swift.message.rule.v1.groups.ItemTypeChoice;
import com.misys.tiplus2.foundations.lang.constants.Empty;
import com.misys.tiplus2.foundations.xml.XMLVisitorException;
import com.misys.tiplus2.foundations.xml.attribute.Attribute;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributes;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributesHelper;

/**
 * @author DaiD1
 * TSDS-40844
 */
public class MessageRuleDocumentVisitor implements MessageRuleVisitor {

    protected ElementAttributes attributes = new ElementAttributes();
    protected String mainNamespaceURI;

    public MessageRuleDocumentVisitor() {
        mainNamespaceURI = MessageRuleNamespace.URI;
    }

    @Override
    public Object visit(Construct construct, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();

            if (construct.getRuleId() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.RULE_ID, Empty.STRING,
                        Attribute.Types.CDATA, construct.getRuleId());
            }
            if (construct.getType() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.TYPE, Empty.STRING,
                        Attribute.Types.CDATA, construct.getType());
            }

            handler.startElement(mainNamespaceURI, Construct.ELEMENT, Empty.STRING, attributes);

            for (ItemTypeChoice choice : construct.getItemTypeChoices()) {
                switch (choice.getChosen()) {
                case STATEMENT:
                    choice.getStatement().accept(this, data);
                    break;
                case PROCEDURE:
                    choice.getProcedure().accept(this, data);
                    break;
                case CONSTRUCT:
                    choice.getConstruct().accept(this, data);
                    break;
                default:
                    break;
                }
            }

            handler.endElement(mainNamespaceURI, Construct.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Statement statement, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();

            if (statement.getOperator() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.OPERATOR, Empty.STRING,
                        Attribute.Types.CDATA, statement.getOperator());
            }

            if (statement.getType() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.TYPE, Empty.STRING,
                        Attribute.Types.CDATA, statement.getType());
            }

            handler.startElement(mainNamespaceURI, Statement.ELEMENT, Empty.STRING, attributes);

            List<Component> components = statement.getComponents();
            for (Component component : components) {
                component.accept(this, data);
            }
            
            List<Procedure> procedures = statement.getProcedures();
            for (Procedure procedure : procedures) {
                procedure.accept(this, data);
            }

            handler.endElement(mainNamespaceURI, Statement.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Component component, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();
            if (component.getMessage() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.MESSAGE, Empty.STRING,
                        Attribute.Types.CDATA, component.getMessage());
            }
            if (component.getSequence() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.SEQUENCE, Empty.STRING,
                        Attribute.Types.CDATA, component.getSequence());
            }
            if (component.getField() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.FIELD, Empty.STRING,
                        Attribute.Types.CDATA, component.getField());
            }

            if (component.getSubValueIndex() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.SUB_VALUE_INDEX, Empty.STRING,
                        Attribute.Types.CDATA, component.getSubValueIndex());
            }

            if (component.getValue() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.VALUE, Empty.STRING,
                        Attribute.Types.CDATA, component.getValue());
            }

            if (component.getPattern() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.PATTERN, Empty.STRING,
                        Attribute.Types.CDATA, component.getPattern());
            }
            
            if (component.getPredicate() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.PREDICATE, Empty.STRING,
                        Attribute.Types.CDATA, component.getPredicate());
            }
            
            if (component.getArguments() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.ARGUMENTS, Empty.STRING,
                        Attribute.Types.CDATA, component.getArguments());
            }

            handler.startElement(mainNamespaceURI, Statement.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, Statement.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Procedure procedure, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();

            if (procedure.getType() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, procedure.getType());
            }

            if (procedure.getValue() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.VALUE, Empty.STRING,
                        Attribute.Types.CDATA, procedure.getValue());
            }

            if (procedure.getTerminate() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.TERMINATE, Empty.STRING,
                        Attribute.Types.CDATA, procedure.getTerminate());
            }

            if (procedure.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, procedure.getTag());
            }
            
            if (procedure.getSubValueIndex() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.SUB_VALUE_INDEX, Empty.STRING,
                        Attribute.Types.CDATA, procedure.getSubValueIndex());
            }
            handler.startElement(mainNamespaceURI, Procedure.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, Procedure.ELEMENT, Empty.STRING);
        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(MessageRules messageRules, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            handler.startDocument();

            ElementAttributesHelper.addDefaultNamespaceAttribute(attributes.clear(), mainNamespaceURI);

            if (messageRules.getVersion() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageRuleNamespace.Attributes.VERSION, Empty.STRING,
                        Attribute.Types.CDATA, messageRules.getVersion());
            }

            handler.startElement(mainNamespaceURI, MessageRules.ELEMENT, Empty.STRING, attributes);

            for (Construct construct : messageRules.getMessageRuleList()) {
                construct.accept(this, data);
            }

            handler.endElement(mainNamespaceURI, MessageRules.ELEMENT, Empty.STRING);

            handler.endDocument();

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

}