/**
 * 
 */
package com.misys.tiplus2.catalog.swift.message.map.v1.visitor;

import java.util.List;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.misys.tiplus2.catalog.swift.message.map.MessageMapNamespace;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMaps;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.SequenceMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.lang.constants.Empty;
import com.misys.tiplus2.foundations.xml.XMLVisitorException;
import com.misys.tiplus2.foundations.xml.attribute.Attribute;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributes;
import com.misys.tiplus2.foundations.xml.attribute.ElementAttributesHelper;

/**
 * @author DaiD1
 *
 */
public class MessageMapDocumentVisitor implements MessageMapVisitor {

    protected ElementAttributes attributes = new ElementAttributes();
    protected String mainNamespaceURI;

    public MessageMapDocumentVisitor() {
        mainNamespaceURI = MessageMapNamespace.URI;
    }

    @Override
    public Object visit(DataField dataField, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();
            if (dataField.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, dataField.getName());
            }
            
            if (dataField.getPath() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.PATH, Empty.STRING,
                        Attribute.Types.CDATA, dataField.getPath());
            }
            if (dataField.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, dataField.getTag());
            }
            
            if (dataField.getConstant() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.CONSTANT, Empty.STRING,
                        Attribute.Types.CDATA, dataField.getConstant());
            }

            if (dataField.getRule() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.RULE, Empty.STRING,
                        Attribute.Types.CDATA, dataField.getRule());
            }
            
            if (dataField.getType() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.TYPE, Empty.STRING,
                        Attribute.Types.CDATA, dataField.getType());
            }
            
            if (dataField.getGroup() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.GROUP, Empty.STRING,
                        Attribute.Types.CDATA, dataField.getGroup());
            }
            
            handler.startElement(mainNamespaceURI, DataField.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, DataField.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(MarkerField markerField, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();
            if (markerField.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, markerField.getName());
            }
            if (markerField.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, markerField.getTag());
            }
           
            handler.startElement(mainNamespaceURI, MarkerField.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, MarkerField.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(DataBlock dataBlock, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();
            if (dataBlock.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, dataBlock.getName());
            }

            if (dataBlock.getRepeat() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.REPEAT, Empty.STRING,
                        Attribute.Types.CDATA, dataBlock.getRepeat());
            }

            handler.startElement(mainNamespaceURI, DataBlock.ELEMENT, Empty.STRING, attributes);

            for (DataTypeChoice choice : dataBlock.getDataTypeChoices()) {
                switch (choice.getChosen()) {
                case DATAFIELD:
                    choice.getDataField().accept(this, data);
                    break;
                case FIELDOPTIONS:
                    choice.getFieldOptions().accept(this, data);
                    break;
                default:
                    break;
                }
            }
              
            handler.endElement(mainNamespaceURI, DataBlock.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(FieldOptions fieldOptions, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();
            if (fieldOptions.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, fieldOptions.getTag());
            }

            handler.startElement(mainNamespaceURI, FieldOptions.ELEMENT, Empty.STRING, attributes);

            List<DataField> dataFields = fieldOptions.getDataFields();
            for (DataField dataField : dataFields) {
                dataField.accept(this, data);
            }

            handler.endElement(mainNamespaceURI, FieldOptions.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(MessageMap messageMap, Object data) {

        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();
            if (messageMap.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, messageMap.getName());
            }

            if (messageMap.getMessage() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.MESSAGE, Empty.STRING,
                        Attribute.Types.CDATA, messageMap.getMessage());
            }

            if (messageMap.getInclude() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.INCLUDE, Empty.STRING,
                        Attribute.Types.CDATA, messageMap.getInclude());
            }

            if (messageMap.getSourceName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.SOURCE_NAME, Empty.STRING,
                        Attribute.Types.CDATA, messageMap.getSourceName());
            }

            handler.startElement(mainNamespaceURI, MessageMap.ELEMENT, Empty.STRING, attributes);

            for (HeaderField headerField : messageMap.getHeaderFields()) {
                headerField.accept(this, data);
            }

            for (DataTypeChoice choice : messageMap.getDataTypeChoices()) {
                switch (choice.getChosen()) {
                case DATAFIELD:
                    choice.getDataField().accept(this, data);
                    break;
                case DATABLOCK:
                    choice.getDataBlock().accept(this, data);
                    break;
                case MARKERFIELD:
                    choice.getDataBlock().accept(this, data);
                    break;
                case FIELDOPTIONS:
                    choice.getFieldOptions().accept(this, data);
                    break;
                case SEQUENCEMAP:
                    choice.getSequenceMap().accept(this, data);
                    break;
                case EMBEDDED:
                    choice.getEmbedded().accept(this, data);
                    break;
                default:
                    break;
                }
            }
            handler.endElement(mainNamespaceURI, MessageMap.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(MessageMaps messageMaps, Object data) {
        ContentHandler handler = (ContentHandler) data;

        try {

            handler.startDocument();

            ElementAttributesHelper.addDefaultNamespaceAttribute(attributes.clear(), mainNamespaceURI);
            if (messageMaps.getVersion() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.VERSION, Empty.STRING,
                        Attribute.Types.CDATA, messageMaps.getVersion());
            }

            handler.startElement(mainNamespaceURI, MessageMaps.ELEMENT, Empty.STRING, attributes);

            for (MessageMap messageMap : messageMaps.getMessageMaps()) {
                messageMap.accept(this, data);
            }

            handler.endElement(mainNamespaceURI, MessageMaps.ELEMENT, Empty.STRING);

            handler.endDocument();

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }

        return data;
    }

    @Override
    public Object visit(HeaderField headerField, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();
            if (headerField.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, headerField.getName());
            }
            if (headerField.getPath() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.PATH, Empty.STRING,
                        Attribute.Types.CDATA, headerField.getPath());
            }
            if (headerField.getTag() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.TAG, Empty.STRING,
                        Attribute.Types.CDATA, headerField.getTag());
            }
            if (headerField.getConstant() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.CONSTANT, Empty.STRING,
                        Attribute.Types.CDATA, headerField.getConstant());
            }
            if (headerField.getRule() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.RULE, Empty.STRING,
                        Attribute.Types.CDATA, headerField.getRule());
            }

            handler.startElement(mainNamespaceURI, HeaderField.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, HeaderField.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(Embedded embedded, Object data) {
        ContentHandler handler = (ContentHandler) data;
        try {
            attributes.clear();
            if (embedded.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, embedded.getName());
            }

            handler.startElement(mainNamespaceURI, Embedded.ELEMENT, Empty.STRING, attributes);

            handler.endElement(mainNamespaceURI, Embedded.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

    @Override
    public Object visit(SequenceMap sequenceMap, Object data) {
        ContentHandler handler = (ContentHandler) data;

        try {
            attributes.clear();
            if (sequenceMap.getName() != null) {
                attributes.addAttribute(mainNamespaceURI, MessageMapNamespace.Attributes.NAME, Empty.STRING,
                        Attribute.Types.CDATA, sequenceMap.getName());
            }
            handler.startElement(mainNamespaceURI, SequenceMap.ELEMENT, Empty.STRING, attributes);

            for (DataTypeChoice choice : sequenceMap.getDataTypeChoices()) {
                switch (choice.getChosen()) {
                case DATAFIELD:
                    choice.getDataField().accept(this, data);
                    break;
                case MARKERFIELD:
                    choice.getDataBlock().accept(this, data);
                    break;
                case DATABLOCK:
                    choice.getDataBlock().accept(this, data);
                    break;
                case FIELDOPTIONS:
                    choice.getFieldOptions().accept(this, data);
                    break;
                default:
                    break;
                }
            }
            handler.endElement(mainNamespaceURI, SequenceMap.ELEMENT, Empty.STRING);

        } catch (SAXException se) {
            throw new XMLVisitorException(se);
        }
        return data;
    }

}
