package com.misys.tiplus2.catalog.swift.mx.message.definition.util;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Enumeration;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.FractionDigits;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MaxLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.MinLength;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Pattern;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Restriction;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Tag;
import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.TotalDigits;
import com.misys.tiplus2.foundations.xml.XMLException;

import oracle.xml.parser.schema.XMLSchema;

/**
 * 
 * @author DaiD1
 *
 */
public class SchemaConverterHelper {

    public static String getMessageId(XMLSchema schema) {

        String key = schema.getSchemaTargetNS();
        int ind = key.indexOf(":xsd:");
        String msgId = key.substring(ind + 5);
        return msgId;
    }

    // get ctype from the last element of ctypes
    public static String getCtype(String ctypes) {
        String result = ctypes;
        if (StringUtils.isNotEmpty(ctypes) && ctypes.contains(".")) {
            int idx = ctypes.lastIndexOf(".");
            result = ctypes.substring(idx+1);
        }
        return result;
    }
    
    public static void printTags(Map<String, Tag> tagMap, StringBuilder strBuilder) throws XMLException {

        if (tagMap != null) {
            strBuilder.append("\r\n\t<tags>");
            for (Entry<String, Tag> entry : tagMap.entrySet()) {
                String key = entry.getKey();
                Tag tagValue = entry.getValue();
                strBuilder.append(printTag(key, tagValue));
            }
            strBuilder.append("\r\n\t</tags>");
        }
    }

    public static String printTag(String key, Tag tag) throws XMLException {

        StringBuilder tagBuilder = new StringBuilder("\r\n\t\t<tag name=");
        String tagName = tag.getName();
        String ctype = tag.getCtype();
        if (tagName.startsWith("?")) {
            tagName = tagName.substring(1);
        }
        String[] keys = key.split(":");
        int keysSize = keys.length;
        tagBuilder.append("\"").append(tagName).append("\" ").append("type =\"").append(tag.getType()).append("\" ");
        if (keysSize==3 && ctype!=null) {
            tagBuilder.append("ctype=\"").append(ctype).append("\"");
        }

        // restrictions
        if (tag.getRestriction() != null) {

            tagBuilder.append(">");
            tagBuilder.append("\r\n\t\t\t<restriction>");

            if (tag.getRestriction().getMinLength().getValue() != null) {
                tagBuilder.append("\r\n\t\t\t\t<minLength>").append(tag.getRestriction().getMinLength().getValue())
                        .append("</minLength>");
            }

            if (tag.getRestriction().getMaxLength().getValue() != null) {
                tagBuilder.append("\r\n\t\t\t\t<maxLength>").append(tag.getRestriction().getMaxLength().getValue())
                        .append("</maxLength>");
            }

            if (tag.getRestriction().getPattern().getValue() != null) {
                tagBuilder.append("\r\n\t\t\t\t<pattern>").append("<![CDATA[")
                        .append(tag.getRestriction().getPattern().getValue()).append("]]>").append("</pattern>");
            }

            if (tag.getRestriction().getFractionDigits().getValue() != null) {
                tagBuilder.append("\r\n\t\t\t\t<fractionDigits>")
                        .append(tag.getRestriction().getFractionDigits().getValue()).append("</fractionDigits>");
            }
            if (tag.getRestriction().getTotalDigits().getValue() != null) {
                tagBuilder.append("\r\n\t\t\t\t<totalDigits>").append(tag.getRestriction().getTotalDigits().getValue())
                        .append("</totalDigits>");
            }

            if (tag.getRestriction().getEnumeration().getValue() != null) {
                tagBuilder.append("\r\n\t\t\t\t<enumeration>").append(tag.getRestriction().getEnumeration().getValue())
                        .append("</enumeration>");
            }

            tagBuilder.append("\r\n\t\t\t</restriction>");
            tagBuilder.append("\r\n\t\t</tag>");

        } else {
            tagBuilder.append("/>");
        }
        return tagBuilder.toString();
    }

    public static boolean containsTag(Tag theTag, Map<String, Tag> tagMap) {

        boolean result = false;
        if (tagMap != null && !tagMap.isEmpty() && theTag != null) {
            for (Entry<String, Tag> entry : tagMap.entrySet()) {
                String key = entry.getKey();
                String[] keys = key.split(":");
                if (keys.length == 2 && keys[0].equals(theTag.getName()) && keys[1].equals(theTag.getType())) {
                    result = true;
                    break;
                }
            }
        }
        return result;
    }

    public static void addTags(Map<String, Tag> localTags, Map<String, Tag> globalTags) {

        for (Entry<String, Tag> entry : localTags.entrySet()) {
            String key = entry.getKey();
            Tag tag = entry.getValue();
            if (!containsTag(tag, globalTags)) {
                globalTags.put(key, tag);
            } else {
                Tag globalTag = globalTags.get(key);
                if (!tagEquals(globalTag, tag)) {
                    // add a tag with key=tag.name+:+tag.type
                    globalTags.put(key, tag);
                } else { // equalsTag
                    if (!restrictionEquals(tag.getRestriction(), globalTag.getRestriction())) {
                        // add tag with key= tag.name+:+tag.type+:+tag.message
                        String newKey = tag.getName()+":"+tag.getType()+":"+tag.getMessage();
                        globalTags.put(newKey, tag);
                    }
                }
            }
        }
    }

    public static boolean tagEquals(Tag tag1, Tag tag2) {
        boolean result = false;
        if (tag1 != null && tag2 != null && tag1.getName().equals(tag2.getName())
                && tag1.getType().equals(tag2.getType())) {
             if (tag1.getCtype()==null && tag2.getCtype()==null) {
                result = true; 
             } else if (tag1.getCtype()!=null && tag1.getCtype().equals(tag2.getCtype())) {
                 result = true;
             }
        } else if (tag1 == null && tag2 == null) {
            result = true;
        }

        return result;
    }

    public static boolean restrictionEquals(Restriction res1, Restriction res2) {

        boolean result = false;
        if (res1 != null && res2 != null) {
            Pattern pat1 = res1.getPattern();
            Pattern pat2 = res1.getPattern();
            Enumeration enum1 = res1.getEnumeration();
            Enumeration enum2 = res2.getEnumeration();
            FractionDigits frac1 = res1.getFractionDigits();
            FractionDigits frac2 = res2.getFractionDigits();
            MaxLength max1 = res1.getMaxLength();
            MaxLength max2 = res2.getMaxLength();
            MinLength min1 = res1.getMinLength();
            MinLength min2 = res2.getMinLength();
            TotalDigits total1 = res1.getTotalDigits();
            TotalDigits total2 = res2.getTotalDigits();

            if (patternEquals(pat1,pat2) && enumEquals(enum1,enum2) && fractionEquals(frac1, frac2)
                   && maxLengthEquals(max1,max2) && minLengthEquals(min1,min2) && totalEquals(total1, total2)) {
                result = true;
            }
        } else if (res1 == null && res2 == null) {
            result = true;
        }
        return result;
    }

    public static  boolean patternEquals(Pattern pat1, Pattern pat2) {

        boolean result = false;
        if (pat1 == null && pat2 == null) {
            result = true;
        } else if (pat1 != null && pat2 != null) {
            if (pat1.getValue() == null && pat2.getValue() == null) {
                result = true;
            } else if (pat1.getValue() != null && pat1.getValue().equals(pat2.getValue())) {
                result = true;
            }
        }
        return result;
    }

    public static boolean enumEquals(Enumeration enum1, Enumeration enum2) {

        boolean result = false;
        if (enum1 == null && enum2 == null) {
            result = true;
        } else if (enum1 != null && enum2 != null) {
            if (enum1.getValue() != null && enum1.getValue().equals(enum2.getValue())) {
                result = true;
            } else if (enum1.getValue()==null && enum2.getValue() ==null) {
                result = true;
            }
        }
        return result;
    }
    
    public static boolean fractionEquals(FractionDigits frac1, FractionDigits frac2) {

        boolean result = false;
        if (frac1 == null && frac2 == null) {
            result = true;
        } else if (frac1 != null && frac2 != null) {
            if (frac1.getValue() != null && frac1.getValue().equals(frac2.getValue())) {
                result = true;
            } else if (frac1.getValue() == null && frac2.getValue() == null) {
                result = true;
            }
        }
        return result;
    }
    
    public static boolean maxLengthEquals(MaxLength max1, MaxLength max2) {

        boolean result = false;
        if (max1 == null && max2 == null) {
            result = true;
        } else if (max1 != null && max2 != null) {
            if (max1.getValue() != null && max1.getValue().equals(max2.getValue())) {
                result = true;
            } else if (max1.getValue() == null && max2.getValue()==null)  {
                result = true;   
            }
        }
        return result;
    }
    
    public static boolean minLengthEquals(MinLength min1, MinLength min2) {

        boolean result = false;
        if (min1 == null && min2 == null) {
            result = true;
        } else if (min1 != null && min2 != null) {
            if (min1.getValue() != null && min1.getValue().equals(min2.getValue())) {
                result = true;
            } else if (min1.getValue() == null && min2.getValue()==null)  {
                result = true;   
            }
        }
        return result;
    }
    
    public static boolean totalEquals(TotalDigits total1, TotalDigits toatl2) {

        boolean result = false;
        if (total1 == null && toatl2 == null) {
            result = true;
        } else if (total1 != null && toatl2 != null) {
            if (total1.getValue() != null && total1.getValue().equals(toatl2.getValue())) {
                result = true;
            } else if (total1.getValue() == null && toatl2.getValue()==null)  {
                result = true;   
            }
        }
        return result;
    }
}
