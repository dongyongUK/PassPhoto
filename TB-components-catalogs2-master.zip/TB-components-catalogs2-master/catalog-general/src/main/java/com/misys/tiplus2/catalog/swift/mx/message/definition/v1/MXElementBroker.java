package com.misys.tiplus2.catalog.swift.mx.message.definition.v1;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageDocumentVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.sax.common.DefaultElementBroker;

public class MXElementBroker extends DefaultElementBroker {

    @Override
    protected String getPackageName() {
        return MXElementBroker.class.getPackage().getName() + ".elements";
    }

    @Override
    protected Visitor getContentHandlerVisitor() {        
        return new FinMessageDocumentVisitor();
    }
}
