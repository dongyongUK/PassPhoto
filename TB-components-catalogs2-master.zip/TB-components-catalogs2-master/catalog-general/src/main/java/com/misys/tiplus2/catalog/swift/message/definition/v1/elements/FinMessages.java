package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * FinMessages
 * 
 * 
 * @author DaiD1
 * 
 */
public class FinMessages extends SAXBaseElement {

    public static final String ELEMENT = "fin-messages";
    private Tags tags;
    private List<FinMessage> finMessageList = new ArrayList<FinMessage>();
    private String version;

    @Override
    public void setAttribute(String name, String value) throws XMLException {
        if ("version".equals(name)) {
            setVersion(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof FinMessage) {
            addFinMessage((FinMessage) element);
        } else if (element instanceof Tags) {
            setTags((Tags) element);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public Tags getTags() {
        return tags;
    }

    public void setTags(Tags tags) {
        this.tags = tags;
    }

    public List<FinMessage> getFinMessageList() {
        return this.finMessageList;
    }

    public void addFinMessage(FinMessage finMessage) {
        finMessageList.add(finMessage);
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public FinMessage findFinMessage(String serviceId){
        
        FinMessage result = null;
        for (FinMessage finMsg: finMessageList){
            
            if (finMsg.getServiceId().equals(serviceId)){
                result = finMsg;
                break;
            }
        }
            
        return result;
    }
}