package com.misys.tiplus2.catalog.swift.mx.message.definition;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.MXElementBroker;
import com.misys.tiplus2.foundations.xml.namespace.Namespace;
import com.misys.tiplus2.foundations.xml.namespace.NamespaceException;
import com.misys.tiplus2.foundations.xml.namespace.Namespaces;
import com.misys.tiplus2.foundations.xml.namespace.StrictNamespaces;

public class MXMessageNamespace {

    public static final String URI = "urn:definition.message.mx.swift.catalog.tiplus2.misys.com";
    public static final String PREFIX = "mm";

    public static final String DOCUMENT_ELEMENT = "mx-message-definition";

    public static final Namespace NAMESPACE;
    static {
        NAMESPACE = new Namespace(URI, PREFIX);
        NAMESPACE.addDefaultElementBroker(DOCUMENT_ELEMENT, "1.0", new MXElementBroker());
    }

    public static class Attributes {
        public static final String VERSION = "version";
        public static final String NAME = "name";
        public static final String KEY = "key";
        public static final String MESSAGE = "message";
        public static final String TAG = "tag";
        public static final String MANDATORY = "mandatory";
        public static final String DESCRIPTION = "description";
        public static final String INCLUDE = "include";
        public static final String FORMAT = "format";
        public static final String NUMBER = "number";
        public static final String REG = "reg";
        public static final String REPEAT = "repeat";
        public static final String TYPE = "type";
        public static final String CTYPE = "ctype";
        public static final String VARIANT = "variant";
        public static final String VARIANT_TYPE = "variant-type";
        public static final String VALUE = "value";
        public static final String DEFAULT_VALUE = "default";
        public static final String PATH = "path";
        public static final String ATTRIBUTE = "attribute";
        public static final String OPTIONS = "options";
        public static final String ENUMERATION  = "enumeration";
        public static final String FRACTIONDIGITS="fractionDigits";
        public static final String TOTALDIGITS="totalDigits";
        public static final String CODES = "Codes";
        public static final String ERROR_CODE="error-code";
        public static final String TAG_TYPE="tag-type";
        public static final String MINLENGTH = "minlength";
        public static final String MAXLENGTH = "maxlength";
        public static final String PATTERN = "pattern";
        public static final String MESSAGE_ID = "message-id";

    }

    public static Namespaces getNamespaces() {
        Namespaces result = new StrictNamespaces();
        addToNamespaces(result);
        return result;
    }

    public static void addToNamespaces(Namespaces namespaces) {
        try {
            namespaces.addNamespace(NAMESPACE);
        } catch (NamespaceException ne) {
            // TODO throw runtime exception
        }
    }
}
