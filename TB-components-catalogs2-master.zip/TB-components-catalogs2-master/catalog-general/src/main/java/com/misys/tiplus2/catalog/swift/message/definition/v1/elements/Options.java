package com.misys.tiplus2.catalog.swift.message.definition.v1.elements;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.misys.tiplus2.catalog.swift.message.definition.v1.visitor.FinMessageVisitor;
import com.misys.tiplus2.foundations.xml.Visitor;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;
import com.misys.tiplus2.foundations.xml.sax.common.SAXBaseElement;

/**
 * Options
 * 
 * an element of fin message
 * 
 * @author DaiD1
 *
 */
public class Options extends SAXBaseElement {

    public static final String ELEMENT = "options";
    private String tag;
    private String mandatory = "";

    private List<Field> fields = new ArrayList<Field>();

    @Override
    public void setElement(SAXElement element) throws XMLException {
        if (element instanceof Field) {
            addField((Field) element);
        } else {
            super.setElement(element);
        }
    }

    @Override
    public void setAttribute(String name, String value) throws XMLException {

        if ("tag".equals(name)) {
            setTag(value);
        } else if ("mandatory".equals(name)) {
            setMandatory(value);
        } else {
            super.setAttribute(name, value);
        }
    }

    @Override
    public Object accept(Visitor visitor, Object data) {
        return ((FinMessageVisitor) visitor).visit(this, data);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }

    public String getMandatory() {
        return mandatory;
    }

    private void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    public List<Field> getFields() {
        return fields;
    }

    public void addField(Field mField) {
        this.fields.add(mField);
    }

}
