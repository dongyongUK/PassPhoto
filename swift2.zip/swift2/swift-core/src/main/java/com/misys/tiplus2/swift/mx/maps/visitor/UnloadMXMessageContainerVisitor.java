package com.misys.tiplus2.swift.mx.maps.visitor;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.visitor.SWIFTMessageTargetResolver;
import com.misys.tiplus2.swift.message.validation.rule.visitor.MTMXMappingRuleValidateVisitor;
import com.misys.tiplus2.swift.mx.message.FieldData;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;
import com.misys.tiplus2.swift.mx.message.MXMessageFieldHelper;

/**
 * Populate date from MXMessageContainer to Enigma MX pane
 * 
 *
 * @author DaiD1
 *
 */
public abstract class UnloadMXMessageContainerVisitor<T> extends MXMessageContainerFieldsVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(UnloadMXMessageContainerVisitor.class);

    protected T target;
    protected Map<String, FieldData> currentHeaderFieldsByKey;
    protected MTMXMappingRuleValidateVisitor ruleVisitor;
    protected String msgId;
    protected MessageMap messageMap;

    /**
     * This is the main processing method, it will populate the target with
     * values from SWIFTMXMessageContainer
     * 
     *
     * @param resolver
     * @param SwiftMXMessage
     * @return
     */
    public T unload(SWIFTMessageTargetResolver resolver, MXMessageContainer swiftMessage) {

        Loggers.method().enter(LOG, swiftMessage);

        String msgType = swiftMessage.getMessageId();
        MessageMap messageMap = getMessageMapsLoader().findByMessage(msgType);

        if (messageMap != null) {
            this.currentSwiftMxMessageContainer = swiftMessage;
            target = (T) resolver.createTarget(messageMap.getName());
            currentHeaderFieldsByKey = swiftMessage.getBusinessAppHeader().getFieldDataByKey();
            currentDataFieldsByKey = swiftMessage.getFieldDataByKey();
            currentListFieldByKey = swiftMessage.getListFieldByKey();
            messageMap.accept(this, target);
        }
        Loggers.method().exit(LOG);
        return target;
    }

    abstract public void setFieldInTarget(T target, String fieldName, String value);

    abstract public void setFieldInTarget(T target, int blockIndex, String fieldname, String value);

    abstract public void setFieldInTarget(T target, String fieldName, String value, int arrayIndx);

    abstract public void setFieldInTarget(T target, String fieldName, String value, int arrayIndx1, int arrayIndx2);
    
    @Override
    public Object visit(HeaderField headerField, Object data) {

        Loggers.method().enter(LOG, headerField, data);

        if (headerField.getConstant() != null && headerField.getName() != null) {
            setFieldInTarget(target, headerField.getName(), headerField.getConstant());
        } else {
            String path = headerField.getPath();
            String tag = headerField.getTag();
            path = MXMessageFieldHelper.removeSigns(path);
            tag = MXMessageFieldHelper.removeSigns(tag);
            FieldData dF = currentHeaderFieldsByKey.get(path + "." + tag);
            if (dF != null) {
                setFieldInTarget(target, headerField.getName(), dF.getTagValue());
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataBlock dataBlock, Object data) {
        // Not implemented
        return data;
    }

    @Override
    public Object visit(DataField dataField, Object data) {
        Loggers.method().enter(LOG, dataField, data);

        if (dataField.getConstant() != null && dataField.getName() != null) {
            setFieldInTarget(target, dataField.getName(), dataField.getConstant());
        } else {
            String tag = dataField.getTag();
            String path = dataField.getPath();
            boolean hasArray = false;
            String arrayKey = null;
            if (MXMessageFieldHelper.hasArray(path) || MXMessageFieldHelper.hasArray(tag)) {
                hasArray = true;
                arrayKey = MXMessageFieldHelper.getArrayKey2(path, tag);
            }
            tag = MXMessageFieldHelper.removeSigns(tag);
            path = MXMessageFieldHelper.removeSigns(path);

            if (!hasArray) {
                FieldData fieldData = currentDataFieldsByKey.get(path + "." + tag);
                if (fieldData != null) {
                    setFieldInTarget(target, dataField.getName(), fieldData.getTagValue());
                }
            } else {
                // Array
                List<Map<String, Object>> listMap = currentListFieldByKey.get(arrayKey);
                if (listMap != null && !listMap.isEmpty()) {
                    int arrayIndx1 = 0;
                    for (Map<String, Object> mapValue : listMap) {
                        arrayIndx1++;
                        for (String key : mapValue.keySet()) {
                            if (!MXMessageFieldHelper.hasArray(key)) {
                                if (tag != null && tag.equals("_Ccy")) {
                                    tag = "Ccy";
                                }
                                String fieldKey = path + "." + tag;
                                if (fieldKey.equals(key)) {
                                    String value = (String) mapValue.get(key);
                                    if (value != null) {
                                        setFieldInTarget(target, dataField.getName(), value, arrayIndx1);
                                        break;
                                    }
                                }
                            } else {
                                // array of array
                                List<Map<String, Object>> arryOfarry = (List<Map<String, Object>>) mapValue.get(key);
                                int arrayIndx2 = 0;
                                for (Map<String, Object> mapValue2 : arryOfarry) {
                                    arrayIndx2++;
                                    for (String key2 : mapValue2.keySet()) {
                                        if (tag != null && tag.equals("_Ccy")) {
                                            tag = "Ccy";
                                        }
                                        String fieldKey = path + "." + tag;
                                        if (fieldKey.equals(key2)) {
                                            String value = (String) mapValue2.get(key2);
                                            if (value != null) {
                                                setFieldInTarget(target, dataField.getName(), value,arrayIndx1, arrayIndx2);
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(MarkerField markerField, Object data) {
        // not implemented
        return data;
    }

}
