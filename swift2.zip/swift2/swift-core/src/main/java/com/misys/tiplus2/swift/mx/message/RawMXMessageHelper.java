package com.misys.tiplus2.swift.mx.message;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.foundations.xml.XMLFeaturesHelper;
import com.misys.tiplus2.swift.message.validation.rule.MessageRuleHelper;
import com.misys.tiplus2.swift.mx.message.MXMessageConstant;
import com.misys.tiplus2.swift.mx.message.processor.MXMessageProcessorException;

/**
 * Helper class for processing incoming MX message
 * 
 * 
 * @author DaiD1
 *
 */
public class RawMXMessageHelper {

    private static final Logger LOG = LoggerFactory.getLogger(RawMXMessageHelper.class);

    public static String getTagValue(String tagName, String rawMessage) {

        String result = null;

        try {
            DocumentBuilderFactory factory = XMLFeaturesHelper.getDocumentBuilderFactory();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            StringReader xmlStreamReader = new StringReader(rawMessage);
            InputSource inputSource = new InputSource(xmlStreamReader);
            org.w3c.dom.Document doc = builder.parse(inputSource);

            XPathFactory xpathfactory = XPathFactory.newInstance();
            XPath xpath = xpathfactory.newXPath();

            // use local-name() to ignore namespace in XML
            String query = "//*[local-name()='" + tagName + "']/text()";
            XPathExpression expr = xpath.compile(query);
            Object obj = expr.evaluate(doc, XPathConstants.NODE);
            result = getNodeValue((Node) obj);

        } catch (ParserConfigurationException | IOException | SAXException e) {
            Loggers.general().error(LOG, e.getMessage());
            throw new MXMessageProcessorException(e);
        } catch (XPathExpressionException e) {
            Loggers.general().error(LOG, e.getMessage());
            throw new MXMessageProcessorException(e);
        }

        return result;
    }

    public static String getBizSvc(String rawMessage) {

        String result = null;
        if (rawMessage!=null) {
            String value = getMesage(MXMessageConstant.BIZ_SVC, rawMessage);
            if (value != null) {
                int indx1 = rawMessage.indexOf("<" + MXMessageConstant.BIZ_SVC);
                if (indx1 > 0) {
                    indx1 = rawMessage.indexOf(">", indx1 + 6);
                    int indx2 = rawMessage.indexOf("</" + MXMessageConstant.BIZ_SVC, indx1);
                    if (indx2 > indx1) {
                        result = rawMessage.substring(indx1 + 1, indx2);
                        if (result != null) {
                            result = result.trim();
                        }
                    }
                }
            }
        }
        return result;
    }
    
    public static String getMsgDefId(String rawMessage) {
        
        String result = null;
       
        if (rawMessage != null ) {
            String value = getMesage(MXMessageConstant.MSG_DEF_IDR, rawMessage);
            if (value != null) {
                int indx1 = rawMessage.indexOf("<" + MXMessageConstant.MSG_DEF_IDR);
                if (indx1 > 0) {
                    indx1 = rawMessage.indexOf(">", indx1 + 6);
                    int indx2 = rawMessage.indexOf("</" + MXMessageConstant.MSG_DEF_IDR, indx1);
                    if (indx2 > indx1) {
                        result = rawMessage.substring(indx1 + 1, indx2);
                        if (result != null) {
                            result = result.trim();
                        }
                    }
                }
            }
        }
        return result;
    }

    public static boolean hasNode(String nodeName, String rawMessage) {

        boolean result = false;

        if (rawMessage != null && !rawMessage.isEmpty()) {

            try {
                DocumentBuilderFactory factory = XMLFeaturesHelper.getDocumentBuilderFactory();
                factory.setNamespaceAware(true);
                DocumentBuilder builder = factory.newDocumentBuilder();
                StringReader xmlStreamReader = new StringReader(rawMessage);
                InputSource inputSource = new InputSource(xmlStreamReader);
                org.w3c.dom.Document doc = builder.parse(inputSource);

                XPathFactory xpathfactory = XPathFactory.newInstance();
                XPath xpath = xpathfactory.newXPath();

                // use local-name() to ignore namespace in XML
                String query = "//*[local-name()='" + nodeName + "']/text()";
                XPathExpression expr = xpath.compile(query);
                Object obj = expr.evaluate(doc, XPathConstants.NODESET);
                NodeList nodes = (NodeList) obj;
                if (nodes != null && nodes.getLength() > 0) {
                    result = true;
                }

            } catch (ParserConfigurationException | IOException | SAXException e) {
                Loggers.general().error(LOG, e.getMessage());
                throw new MXMessageProcessorException(e);
            } catch (XPathExpressionException e) {
                Loggers.general().error(LOG, e.getMessage());
                throw new MXMessageProcessorException(e);
            }
        }
        return result;
    }

    public static String getAppHdr(String rawMessage) {

        String appHdr = null;

        if (isEmbedded(rawMessage)) {
            if (hasNode(MXMessageConstant.APP_HEADER, rawMessage)) {
                appHdr = getMesage(MXMessageConstant.APP_HEADER, rawMessage);
            }
        } else {
            appHdr = getMesage(MXMessageConstant.APP_HEADER, rawMessage);
        }
        return appHdr;
    }

    public static String getAppHdrVersion(String msgHdr) {

        String appHdrVrsion = null;

        if (hasNode(MXMessageConstant.APP_HEADER, msgHdr)) {

            appHdrVrsion = extractAppHgrVersion(msgHdr);
        }
        return appHdrVrsion;
    }

    public static String extractAppHgrVersion(String msgHdr) {

        String appHdrVrsion = null;

        int indx1 = msgHdr.indexOf(MXMessageConstant.APP_HEADER001_PREFIX);

        int indx2 = msgHdr.lastIndexOf("\"", indx1);
        int indx3 = msgHdr.indexOf("\"", indx1);

        int indx4 = msgHdr.lastIndexOf("\'", indx1);
        int indx5 = msgHdr.indexOf("\'", indx1);

        if (indx1 > indx2 && indx1 < indx3 && indx2 > 0) {
            appHdrVrsion = msgHdr.substring(indx1, indx3);
        } else if (indx1 > indx4 && indx1 < indx5 && indx4 > 0) {
            appHdrVrsion = msgHdr.substring(indx1, indx5);
        }

        return appHdrVrsion;
    }

    public static String getDocument(String rawMessage) {

        String document = null;

        if (isEmbedded(rawMessage)) {
            if (hasNode(MXMessageConstant.DOCUMENT, rawMessage)) {
                document = getMesage(MXMessageConstant.DOCUMENT, rawMessage);
            }
        } else {
            document = getMesage(MXMessageConstant.DOCUMENT, rawMessage);
        }
        return document;
    }

    public static String getMesage(String msgName, String rawMessage) {

        String message = null;
        int length = msgName.length();

        try {
            int indx1 = rawMessage.indexOf(msgName);
            int indx2 = rawMessage.substring(0, indx1).lastIndexOf("<");
            int indx3 = rawMessage.indexOf(msgName, indx1 + length);
            int indx4 = rawMessage.indexOf(">", indx3 + length);
            message = rawMessage.substring(indx2, indx4 + 1);
        } catch (Exception e) {
            Loggers.general().error(LOG, e.getMessage());
            throw new MXMessageProcessorException(e);
        }
        return message;
    }

    private static String getNodeValue(Node node) {
        String result = null;
        if (node != null) {
            result = node.getTextContent();
        }
        return result;
    }

    /**
     * Is AppHdr and Document are children node in the message
     * 
     * @return
     */
    public static boolean isEmbedded(String xmlMessage) {

        boolean result = true;

        if (xmlMessage != null && !xmlMessage.isEmpty()) {
            xmlMessage = xmlMessage.trim();
            int indx1 = xmlMessage.indexOf("<");
            int indx2 = xmlMessage.indexOf(">");
            int indx3 = xmlMessage.indexOf(MXMessageConstant.APP_HEADER);

            if (indx1 < indx3 && indx3 < indx2) {
                result = false;
            }
        }
        return result;

    }

    public static String prettyPrinMX(String message) {

        String result = null;

        try {

            message = deformat(message);
            // convert String XML message into Document
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            InputStream is = new ByteArrayInputStream(message.getBytes("UTF-8"));
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(is);

            // transform
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            StreamResult os = new StreamResult(new StringWriter());
            DOMSource source = new DOMSource(doc);
            transformer.transform(source, os);
            result = os.getWriter().toString();

        } catch (IOException | ParserConfigurationException | SAXException | TransformerException e) {
            Loggers.general().error(LOG, e.getMessage());
            throw new MXMessageProcessorException(e);
        }
        return result;
    }

    public static String deformat(String text) {

        String result = null;
        if (text != null) {
            String[] lines = MessageRuleHelper.splitLine(text);

            if (lines != null) {
                StringBuilder txtBld = new StringBuilder();
                for (int i = 0; i < lines.length; i++) {
                    String line = lines[i];
                    line = line.trim();
                    txtBld.append(line);
                }
                result = txtBld.toString();
            }
        }
        return result;
    }

    public static String formatXml(String xmlmessage) {

        String result = xmlmessage;
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

            StreamSource source = new StreamSource(new StringReader(xmlmessage));
            StringWriter writer = new StringWriter();
            StreamResult sResult = new StreamResult(writer);

            transformer.transform(source, sResult);
            result = writer.toString();
        } catch (TransformerException e) {
            Loggers.general().error(LOG, e.getMessage());
            throw new MXMessageProcessorException(e);
        }

        return result;
    }

}
