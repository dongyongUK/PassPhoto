package com.misys.tiplus2.swift.message.processor;

import com.misys.tiplus2.swift.exception.SWIFTMessageException;

/**
 * MessageProcessorException
 *
 * @author DaiD1
 *
 */
public class MessageProcessorException extends SWIFTMessageException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public MessageProcessorException() {
        super();
    }

    public MessageProcessorException(String message) {
        super(message);
    }

    public MessageProcessorException(Throwable cause) {
        super(cause);
    }

    public MessageProcessorException(String message, Throwable cause) {
        super(message, cause);
    }

    public MessageProcessorException(String code, String message) {
        super(code, message);
    }

    public MessageProcessorException(String code, String message, Throwable cause) {
        super(code, message, cause);

    }
    
//    public String getRootCauseError(){
//        
//        String error = "";
//        Throwable thr = this;
//        while (thr.getCause()!=null){
//            thr = thr.getCause();
//        }
//        error = thr.getMessage();
//        return error ;
//    }
}
