package com.misys.tiplus2.swift.message.validation.error.interpretation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Field Descriptions
 * 
 * @author daid1
 *
 */
public class FieldDesc {
    String matched;
    int begin;
    Map<String, String> descriptions;
    List<String> groups;

    public String getMatched() {
        return matched;
    }

    public void setMatched(String matched) {
        this.matched = matched;
    }

    public int getBegin() {
        return begin;
    }

    public void setBegin(int begin) {
        this.begin = begin;
    }

    public Map<String, String> getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(Map<String, String> descriptions) {
        this.descriptions = descriptions;
    }

    public void addGroup(String item) {

        if (groups == null || groups.isEmpty()) {
            groups = new ArrayList<String>();
        }
        groups.add(item);
    }

    public List<String> getGroups() {
        return groups;
    }
}
