package com.misys.tiplus2.swift.mx.message;

/**
 * 
 * @author DaiD1
 *
 */
public interface MXMessageConstant {

    // MX schema constants 
    final String PREFIX = "com.finastra.fti.swift.mx.";
    final String DOCUMENT_SUFFIX = ".document.type";
    final String HEAD_SUFFIX = ".apphdr.type";
    final String DOT_OBJECT_FACTORY =".ObjectFactory";
    final String DOT_DOCUMENT=".Document";
    final String DOT_APPHDR=".BusinessApplicationHeaderV02";
    final String CREATE_DOCUMENT="createDocument";
    final String CREATE_APPHDR="createAppHdr";
    final String CREATE_BIZAPPHDR="createBusinessApplicationHeaderV02";
    final String DOT_MESSAGE_ID=".MsgId";
    final String DOT_ID=".Id";
    final String APP_HEADER_ID="head.001.001.02";
    final String APP_HEADER001_PREFIX="head.001.";
    final String BUSINESS_SERVICE="swift.cbprplus.02";
    final String GROUP_HEADER="GrpHdr";
    final String ASSIGNMENT ="Assgnmt";
    final String APP_HEADER ="AppHdr";
    final String BIZ_SVC ="BizSvc";
    final String DOCUMENT ="Document";
    final String MSG_DEF_IDR ="MsgDefIdr";
    
    final String WINDOWS_CRLF = "\r\n";
    final String UNIX_LF = "\n";
    final String IOS_CR = "\r";

}