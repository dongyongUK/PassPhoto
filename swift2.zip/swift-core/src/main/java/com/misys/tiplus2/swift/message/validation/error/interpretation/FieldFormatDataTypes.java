package com.misys.tiplus2.swift.message.validation.error.interpretation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Swift Message field format data types
 * 
 * @author daid1
 * 
 */
public class FieldFormatDataTypes {

    public static final Map<Character, String> l_types = new HashMap<Character, String>();
    static {
        l_types.put('n', "swift_type_n_des");
        l_types.put('d', "swift_type_d_des");
        l_types.put('h', "swift_type_h_des");
        l_types.put('a', "swift_type_a_des");
        l_types.put('c', "swift_type_c_des");
        l_types.put('e', "swift_type_e_des");
        l_types.put('x', "swift_type_x_des");
        l_types.put('y', "swift_type_y_des");
        l_types.put('z', "swift_type_z_des");
        l_types.put('L', "swift_type_L_des");
    }

    public static final Map<Character, String> d_types = new HashMap<Character, String>();
    static {
        d_types.put('n', DescriptionPhrases.swift_type_n_des);
        d_types.put('d', DescriptionPhrases.swift_type_d_des);
        d_types.put('h', DescriptionPhrases.swift_type_h_des);
        d_types.put('a', DescriptionPhrases.swift_type_a_des);
        d_types.put('c', DescriptionPhrases.swift_type_c_des);
        d_types.put('e', DescriptionPhrases.swift_type_e_des);
        d_types.put('x', DescriptionPhrases.swift_type_x_des);
        d_types.put('y', DescriptionPhrases.swift_type_y_des);
        d_types.put('z', DescriptionPhrases.swift_type_z_des);
        d_types.put('L', DescriptionPhrases.swift_type_L_des);
    }

    public static final Map<String, String> desc_map = new HashMap<String, String>();
    static {
        desc_map.put("maximum lines", "swift_MAXIMUM_LINES");
        desc_map.put("maximum line length", "swift_MAXIMUM_LINE_LENGTH");
        desc_map.put("maximum", "swift_MAXIMUM");
        desc_map.put("minimum", "swift_MINIMUM");
        desc_map.put("fixed-length", "swift_FIXED_LENGTH");
        desc_map.put("/maximum", "swift_SLASH_MAXIMUM");
        desc_map.put("/minimum", "swift_SLASH_MINIMUM");
        desc_map.put("/fixed-length", "swift_SLASH_FIXED_LENGTH");

    }

    public static final Map<String, String> desc_map_2 = new HashMap<String, String>();
    static {
        desc_map_2.put("maximum lines", DescriptionPhrases.swift_MAXIMUM_LINES);
        desc_map_2.put("maximum line length", DescriptionPhrases.swift_MAXIMUM_LINE_LENGTH);
        desc_map_2.put("maximum", DescriptionPhrases.swift_MAXIMUM);
        desc_map_2.put("minimum", DescriptionPhrases.swift_MINIMUM);
        desc_map_2.put("fixed-length", DescriptionPhrases.swift_FIXED_LENGTH);
        desc_map_2.put("/maximum", DescriptionPhrases.swift_SLASH_MAXIMUM);
        desc_map_2.put("/minimum", DescriptionPhrases.swift_SLASH_MINIMUM);
        desc_map_2.put("/fixed-length", DescriptionPhrases.swift_SLASH_FIXED_LENGTH);
        desc_map_2.put("new line", DescriptionPhrases.swift_NEW_LINE);

    }

    public static final Set<String> sp_symbols = new HashSet<String>();
    static {
        sp_symbols.add("N");
        sp_symbols.add("ISIN1");
        sp_symbols.add(":");
        sp_symbols.add("-");
    }
    static public final String LEFT_SQ_BRACKET = "[";
    static public final String RIGHT_SQ_BRACKET = "]";
    static public final String FORWARD_SLASH = "/";
    static public final String FIX_LENGTH_MARK = "!";

}
