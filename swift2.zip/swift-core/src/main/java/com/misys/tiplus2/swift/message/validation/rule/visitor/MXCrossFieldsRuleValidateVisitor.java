package com.misys.tiplus2.swift.message.validation.rule.visitor;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.FieldError;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;
import com.misys.tiplus2.swift.mx.message.FieldData;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;
import com.misys.tiplus2.swift.mx.message.MXMessageFieldHelper;

/**
 * TSDS-47627
 * 
 * @author DaiD1
 *
 */
public class MXCrossFieldsRuleValidateVisitor extends MXRuleValidateVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(MXCrossFieldsRuleValidateVisitor.class);
    public void validate(MXMessageContainer messageContainer) {

        Loggers.method().enter(LOG, messageContainer);

        String msgId = messageContainer.getMessageId();
        List<String> listRules = messageRulesLoader.getRuleList(msgId);
        if (listRules != null) {
            this.messageContainer = messageContainer;
            for (String ruleId : listRules) {
                Construct construct = messageRulesLoader.findMessageRule(msgId, ruleId);
                if (construct != null) {
                    process(construct);
                }
            }
        }
        
        Loggers.method().exit(LOG);
    }

    public RuleResult process(Construct construct) {

        Loggers.method().enter(LOG, construct);
        
        RuleResult data = new RuleResult();
        data.setLogicalValue(true);
        Object obj = construct.accept(this, data);
        RuleResult result = (RuleResult) obj;
        
        Loggers.method().exit(LOG);
        return result;
    }

    @Override
    public Object visit(Procedure procedure, Object data) {

        Loggers.method().enter(LOG, procedure);

        if (procedure != null) {
            String terminate = procedure.getTerminate();
            String value = procedure.getValue();
            String tags = procedure.getTag();
            if ("error".equals(terminate)) {
                FieldError fieldError = new FieldError(null, null);
                fieldError.setCode(value);
                String desc= errorCodeResources.getErrorDescriptionByCode(value+".error");
                if (desc!=null) {
                    fieldError.setErrorDetails(desc);
                }
                String severity = errorCodeResources.getErrorDescriptionByCode(value+".severity");
                if (severity!=null) {
                    fieldError.setSeverity(severity);
                }
                if (tags != null && !tags.isEmpty()) {
                    String[] tagsa = tags.split("\\|");
                    FieldData tagField = null;
                    for (String tag : tagsa) {
                        tagField = messageContainer.getField(tag);
                        if (tagField != null) {
                            break;
                        }
                    }

                    if (tagField != null) {
                        tagField.setErrorCode(value);
                        /*
                         * if (interpreter.getErrorCodeResources() != null) {
                         * String errDesc = interpreter.getErrorCodeResources().
                         * getErrorDescriptionByCode(value); if (errDesc !=
                         * null) { tagField.setErrorDetails(errDesc); } }
                         */
                    }
                } else {
                    /*
                     * if (interpreter.getErrorCodeResources() != null) { String
                     * errDesc = interpreter.getErrorCodeResources().
                     * getErrorDescriptionByCode(value); if (errDesc != null) {
                     * fieldError.setErrorDetails(errDesc); } }
                     */
                    messageContainer.addNonFieldError(fieldError);
                }
            } else if ("exit".equals(terminate)) {

                RuleResult ruleResult = (RuleResult) data;
                String v1 = ruleResult.getTextValue();
                if (v1 != null) {
                    v1 = value + " value=\"" + value + "\"";
                }
                ruleResult.setTextValue(v1);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(Component component, Object data) {

        Loggers.method().enter(LOG, component);
        
        RuleResult ruleResult = (RuleResult) data;
        if (data == null) {
            ruleResult = new RuleResult();
        }
        if (component != null) {
            String messages = component.getMessage();
            String fieldName = component.getField();
            String subValueIndex = component.getSubValueIndex();
            String value = component.getValue();
            String predicate = component.getPredicate();
            String arguments = component.getArguments();

            if (messages != null && fieldName == null) {
                String[] msgs = messages.split("\\|");
                for (String msg : msgs) {
                    if (messageContainer.getMessageId().equals(msg)) {
                        ruleResult.setLogicalValue(true);
                        break;
                    }
                }
            } else if (fieldName != null && value == null && predicate==null) {
                if (!MXMessageFieldHelper.hasArray(fieldName)) {
                    if (messageContainer.isNotNull(fieldName)) {
                        ruleResult.setLogicalValue(true);
                        FieldData fd = null;
                        if (fieldName.startsWith("AppHdr.")) {
                            if (messageContainer.getBusinessAppHeader()!=null) {
                                fd = messageContainer.getBusinessAppHeader().getField(fieldName);
                            } else { // unit test only
                                fd = messageContainer.getField(fieldName); 
                            }
                        } else {
                            fd = messageContainer.getField(fieldName);
                        }
                        if (fd!=null) {
                            String fvalue = fd.getTagValue();
                            // if fvalue is decimal
                            if (!StringUtils.isEmpty(fd.getTag()) && "Value".equals(fd.getTag().trim())
                                  && MXMessageFieldHelper.matchRegExp(fvalue, "^\\d+?\\.\\d+?$"))  {
                               
                                Float floatV = Float.parseFloat(fvalue);
                                ruleResult.setNumericalValue((double)floatV);
                            } else {
                                ruleResult.setTextValue(fvalue); 
                            }
                        }
                    } else {
                            ruleResult.setLogicalValue(false);
                    }
               } else {   // has array
                   Float totalValue=null;
                   String currency = null;
                   String rtnVal=null;
                   String key = MXMessageFieldHelper.getArrayKey1(fieldName);
                   String size = MXMessageFieldHelper.getArraySizeAsString(fieldName);
                   Map<String, List<Map<String, Object>>> mapV = messageContainer.getListFieldByKey();
                   List<Map<String, Object>> itemList = mapV.get(key);
                 
                   if (itemList!=null && !itemList.isEmpty()) { 
                	 if (subValueIndex==null) { // no array index from component   
                       if(MappingRuleHelper.listContainsPath(fieldName, itemList)){
                            ruleResult.setLogicalValue(true);
                       }
                       for (Map<String, Object> item:itemList) {
                    	   for (Entry<String, Object> entry:item.entrySet()) {
                    		   String entryKey =entry.getKey();
                               String entryValue = null;           
                               if (entry.getValue() instanceof String) {
                            	   entryValue = (String) entry.getValue();
                               } else if (entry.getValue() instanceof List) {
                            	   List list = (List) entry.getValue();
                                    Set itemSet = (Set) list.stream().collect(Collectors.toSet());
                                    entryValue = MappingRuleHelper.getValueFromSet(itemSet );
                               }
                                   
                               if (entryValue.contains(",")){
                            	   entryValue = entryValue.replace(",","");
                               }
                               if (entryKey.endsWith(".Value")) {
                            	   if (totalValue!=null) {
                            		   totalValue=Float.parseFloat(entryValue)+totalValue;
                                   } else {
                                	   totalValue=Float.parseFloat(entryValue);
                                   }
                               } else if (entryKey.endsWith("._Ccy")) {
                            	   if (currency==null) {
                            		   currency=entryValue;
                                   } else {
                                	   if (!currency.equals(entryValue)) {
                                		   currency=currency+"|"+entryValue;
                                       }
                                   }
                               } else {
                            	   rtnVal = entryValue;
                               }
                           }
                       }
                       
                       if(totalValue!=null) {
                    	   ruleResult.setNumericalValue((double) totalValue);
                       }
                       
                       if(currency!=null) {
                    	   if(fieldName.endsWith("._Ccy")) {
                    		   TagDataField tiField = new TagDataField("Amount.Currency", currency);
                    		   ruleResult.setTiField(tiField);
                    		   ruleResult.setSubValue(currency);
                    	   }
                       }
                       
                       if (rtnVal!=null && totalValue==null && currency==null ) {
                    	   ruleResult.setTextValue(rtnVal);
                       }
                     } else {
                	 // end of subIndex ==null.  check the occurrence of at index (subIndexvalue) from array
                	   if (MappingRuleHelper.isDigit(subValueIndex)) {
                		   int idx = Integer.parseInt(subValueIndex);
                		   if(MappingRuleHelper.existInIndexOfArray(fieldName, idx-1, itemList)) {
                			 ruleResult.setLogicalValue(true);
                		   }
                	   } else if("ArraySize".equals(subValueIndex)) {
                		   ruleResult.setLogicalValue(true);
                		   int listSize = itemList.size();
                		   ruleResult.setTextValue(Integer.toString(listSize));
                	   }
                     }
                   }   // end of itemList!=null
               } // end of hasArray      
            } else if (fieldName != null && value != null && predicate==null) {
            	if (!MXMessageFieldHelper.hasArray(fieldName)) {
            		FieldData fieldData = messageContainer.getField(fieldName);
            		String[] values = value.split("\\|");
            		boolean matched = false;
            		for (String v : values) {
            			if (fieldData != null && v.equals(fieldData.getTagValue())) {
            				matched = true;
            				break;
            			}
            		}
            		ruleResult.setLogicalValue(matched);
            	} else {
            		// check value present in the array
            		 String key = MXMessageFieldHelper.getArrayKey1(fieldName);
                     String size = MXMessageFieldHelper.getArraySizeAsString(fieldName);
                     Map<String, List<Map<String, Object>>> mapV = messageContainer.getListFieldByKey();
                     List<Map<String, Object>> itemList = mapV.get(key);
                     if (itemList!=null && !itemList.isEmpty()) { 
                         if(MappingRuleHelper.listContainsPath(fieldName, itemList)){
                        	 for (Map<String, Object> item:itemList) {
                        		 for (Entry<String, Object> entry:item.entrySet()) {
                        			 String entryKey =entry.getKey();
                                     String entryValue=null;
                        			 if (entry.getValue() instanceof String) {
                                         entryValue = (String) entry.getValue();
                                         String[] values = value.split("\\|");
                                 		 for (String v : values) {
                                 			if (v.equals(entryValue)) {
                                             	ruleResult.setLogicalValue(true);
                                             	ruleResult.setTextValue(entryValue);
                                             	return data;
                                             }	
                                 		 }
                                     } else if (entry.getValue() instanceof List) {
                                         List list = (List) entry.getValue();
                                         Set itemSet = (Set) list.stream().collect(Collectors.toSet());
                                         entryValue = MappingRuleHelper.getValueFromSet(itemSet );
                                         if (value.equals(entryValue)) {
                                         	ruleResult.setLogicalValue(true);
                                         	ruleResult.setTextValue(entryValue);
                                         	return data;
                                         }
                                     }
                                  }
                        	  }
                         }
                     }
            	}
            } else if (predicate!=null) {
            	ruleResult.setTextValue(fieldName);
            	ruleResult.setResource(messageContainer);
            	if (arguments != null) {
            		ruleResult.setSubValue(arguments);
                }
            	predicateComponent(ruleResult, predicate);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }
    
    protected void predicateComponent(RuleResult ruleResult, String predicate) {
    	  
        Predicate<RuleResult> pred = messageRulesLoader.getPredicate(predicate);
        if (pred.test(ruleResult)) {
            ruleResult.setLogicalValue(true);
            ruleResult.setResource(null);
        }
  }
}
