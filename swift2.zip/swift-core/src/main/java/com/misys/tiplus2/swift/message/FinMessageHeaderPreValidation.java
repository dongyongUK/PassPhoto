package com.misys.tiplus2.swift.message;

public class FinMessageHeaderPreValidation {

    public static String validateHeader(String finMessage) {

        String errorMessage = null;

        if (finMessage == null || finMessage.isEmpty()) {
            errorMessage = "Message is empty";
            return errorMessage;
        }

        String direction = null;
        FinMessageHandler finHandler = new FinMessageHandler(finMessage);

        String bk1 = finHandler.findBlockByNumber(1);
        if (bk1 == null || bk1.isEmpty()) {
            errorMessage = "Block1 missing";
            return errorMessage;
        } else if (bk1.length() != MTMessageConstant.BLOCK1_LENGTH - 4) {
            errorMessage = "Block1 length has to be " + MTMessageConstant.BLOCK1_LENGTH;
            return errorMessage;
        }

        String bk2 = finHandler.findBlockByNumber(2);
        if (bk2 == null || bk2.isEmpty()) {
            errorMessage = "Block2 missing";
            return errorMessage;
        } else {
            direction = finHandler.getDirection();
            if (!"I".equals(direction) && !"O".equals(direction)) {
                errorMessage = "Message direction in Block2 can only be I or O";
                return errorMessage;
            }
            if ("I".equals(direction)) {
                if (bk2.length() < MTMessageConstant.BLOCK2_IN_MIN_LENGTH - 4) {
                    errorMessage = "Block2 (incoming) length cannot be less than "
                            + MTMessageConstant.BLOCK2_IN_MIN_LENGTH;
                    return errorMessage;
                }
                if (bk2.length() > MTMessageConstant.BLOCK2_IN_MAX_LENGTH - 4) {
                    errorMessage = "Block2 (incoming) length cannot be large than "
                            + MTMessageConstant.BLOCK2_IN_MAX_LENGTH;
                    return errorMessage;
                }
            }

            if ("O".equals(direction)) {
                if (bk2.length() < MTMessageConstant.BLOCK2_OUT_MIN_LENGTH - 4) {
                    errorMessage = "Block2 (outgoing) llength cannot be less than "
                            + MTMessageConstant.BLOCK2_OUT_MIN_LENGTH;
                    return errorMessage;
                }
                if (bk2.length() > MTMessageConstant.BLOCK2_OUT_MAX_LENGTH - 4) {
                    errorMessage = "Block2 (outgoing) llength cannot be large than "
                            + MTMessageConstant.BLOCK2_OUT_MAX_LENGTH;
                    return errorMessage;
                }
            }
        }

        String bk4 = finHandler.findBlockByNumber(4);
        if (bk4 == null || bk4.isEmpty()) {
            errorMessage = "Block4 missing";
        }

        return errorMessage;
    }
}
