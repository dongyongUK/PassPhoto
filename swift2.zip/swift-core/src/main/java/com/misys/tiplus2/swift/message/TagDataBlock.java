package com.misys.tiplus2.swift.message;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class TagDataBlock implements Serializable {

    private static final long serialVersionUID = -6160911793434320647L;

    // the size of the map is the number of fields within the block
    Map<String, TagDataField> dataFields;
    private String name;
    private String sequence;

    public TagDataBlock(String name) {
        this.name = name;
        dataFields = new HashMap<String, TagDataField>();
    }

    public TagDataBlock(String name, Map<String, TagDataField> dataFields) {
        this.name = name;
        this.dataFields = dataFields;
    }

    public TagDataBlock(String name, String sequence, Map<String, TagDataField> dataFields) {
        this.name = name;
        this.sequence = sequence;
        this.dataFields = dataFields;
    }
    public void addDataField(TagDataField dataField) {
        dataFields.put(dataField.getTag(), dataField);
    }

    public Map<String, TagDataField> getDataFields() {
        return dataFields;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public TagDataBlock copy() {

        TagDataBlock result = new TagDataBlock(this.name);
        for (Entry<String, TagDataField> entry : dataFields.entrySet()) {
            result.addDataField(entry.getValue().copy());
        }
        return result;
    }
}
