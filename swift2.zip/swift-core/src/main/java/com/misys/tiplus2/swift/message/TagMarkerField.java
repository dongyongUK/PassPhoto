package com.misys.tiplus2.swift.message;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.contract.AssertArgument;

/**
 *
 * @author DaiD1
 *
 */

public class TagMarkerField implements Serializable {

    private static final long serialVersionUID = 2949604856891652108L;
    private static final Logger LOG = LoggerFactory.getLogger(TagMarkerField.class);

    private String tag;
    private String sequence;
    private String description;
    private String errorCode;
    private String errorDetails;
    private boolean isMarked = false;

    public boolean isMarked() {
        return isMarked;
    }

    public void setMarked(boolean isMarked) {
        this.isMarked = isMarked;
    }

    public TagMarkerField(String tag) {

        AssertArgument.notBlank(tag, "tag");
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    
    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    
    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public TagMarkerField copy() {
        TagMarkerField result = new TagMarkerField(this.tag);
        result.setDescription(description);
        result.setErrorDetails(errorDetails);
        result.setMarked(isMarked);
        return result;
    }
}
