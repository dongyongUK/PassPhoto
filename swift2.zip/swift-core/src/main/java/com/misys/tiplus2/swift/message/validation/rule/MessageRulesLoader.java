package com.misys.tiplus2.swift.message.validation.rule;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;

import javax.management.modelmbean.XMLParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.rule.MessageRuleNamespace;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.MessageRules;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

/**
 * MessageRulesLoader
 * TSDS-40884
 * @author DaiD1
 *
 * @since TSDS-47627
 */
public class MessageRulesLoader {

    private static final Logger LOG = LoggerFactory.getLogger(MessageRulesLoader.class);

    private MessageRules messageRules;
    private String version;
    private Map<String, List<String>> message2RulesMap;
    private Map<String, Predicate<RuleResult>> messagePredicateMap;
    
    private Map<String, String> bizSrvMap;

    public MessageRulesLoader(String fileName, String version) throws XMLParseException {

        Loggers.method().enter(LOG, fileName, version);

        try {
            ClassLoader loader = MessageRulesLoader.class.getClassLoader();
            Reader defFile = new InputStreamReader(loader.getResourceAsStream(fileName));
            XMLParser parser = new XMLParser(MessageRuleNamespace.getNamespaces());
            SAXElement saxElement = parser.getSAXElement(defFile);
            messageRules = (MessageRules) saxElement;
            this.version = version;
        } catch (Exception e) {
            LOG.error("Fail to load file:", fileName);
            throw new XMLParseException(e, "Fail to load message-rules file");
        }
        Loggers.method().exit(LOG);
    }

    public Construct findMessageRule(String msgType, String ruleId) {

        Loggers.method().enter(LOG, msgType, ruleId);
        Construct result = null;
        if (ruleId != null) {
            for (Construct construct : messageRules.getMessageRuleList()) {
            	String id = construct.getRuleId();
                if (ruleId.equals(id.trim())) {
                    if (construct.getStatement() != null) {
                        List<Component> comps = construct.getStatement().getComponents();
                        if (comps != null && comps.get(0) != null && comps.get(0).getMessage() != null) {
                            if (msgType.startsWith("798Score.") && comps.get(0).getMessage().startsWith("798") ){
                                result = construct.getConstruct();
                                break;
                            } else if (comps.get(0).getMessage().contains(msgType)) {
                                result = construct.getConstruct();
                                break;
                            } 
                        }
                    }
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public Construct getConstructFromRuleId(String ruleId) {

        Loggers.method().enter(LOG,ruleId);
        
        Construct result = messageRules.findMessageRuleById(ruleId);
        
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public List<String> getRuleList(String msgType) {

        Loggers.method().enter(LOG, msgType);
        List<String> result = null;

        if (msgType != null) {
            for (Entry<String, List<String>> entry : message2RulesMap.entrySet()) {
                if (msgType.equals(entry.getKey())) {
                    result = entry.getValue();
                    break;
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public MessageRules getMessageRules() {
        return messageRules;
    }

    public void setMessage2RulesMap(Map<String, List<String>> message2RulesMap) {
        this.message2RulesMap = message2RulesMap;
    }
    
    public Map<String, Predicate<RuleResult>> getMessagePredicateMap() {
        return messagePredicateMap;
    }

    public void setMessagePredicateMap(Map<String, Predicate<RuleResult>> messagePredicateMap) {
        this.messagePredicateMap = messagePredicateMap;
    }
    
    public Predicate<RuleResult> getPredicate(String key){
        
        return messagePredicateMap.get(key);
    }


	public void setBizSrvMap(Map<String, String> bizSrvMap) {
		this.bizSrvMap = bizSrvMap;
	}
	

	public Map<String, String> getBizSrvMap() {
		return this.bizSrvMap;
	}
	
	public String getBizSrv(String msgId) {
	 return this.bizSrvMap.get(msgId);	
	}
}
