package com.misys.tiplus2.swift.message.validation.rule.visitor;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;
import com.misys.tiplus2.swift.mx.message.FieldData;

/**
 * TSDS-47627
 * 
 * @author DaiD1
 *
 */
public class MTMXMappingRuleValidateVisitor extends MXRuleValidateVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(MTMXMappingRuleValidateVisitor.class);

    private DataField mapField;
    private TagDataField tiField;
    private FieldData mxFieldData;

    public RuleResult process(Construct construct, DataField mapField, TagDataField tiField) {

        Loggers.method().enter(LOG, construct);
        this.mapField = mapField;
        this.tiField = tiField;
        RuleResult data = new RuleResult();
        data.setLogicalValue(true);

        Object obj = construct.accept(this, data);
        RuleResult result = (RuleResult) obj;
        Loggers.method().exit(LOG);
        return result;
    }

    @Override
    public Object visit(Procedure procedure, Object data) {

        Loggers.method().enter(LOG, procedure);

        if (procedure != null) {

            String terminate = procedure.getTerminate();
            String value = procedure.getValue();
            String tag = procedure.getTag();
            String subValueIndex = procedure.getSubValueIndex();

            RuleResult ruleResult = null;
            if (data != null && data instanceof RuleResult) {
                ruleResult = (RuleResult) data;
            }

            if ("exit".equals(terminate) && ruleResult != null) {

                String path = mapField.getPath();
                String srcValue = tiField.getValue();

                if (subValueIndex != null && value == null) {
                    String key = path + "." + tag;
                    if (MappingRuleHelper.isInterval(subValueIndex)) {
                        String[] inter = subValueIndex.split(MappingRuleHelper.INTERVAL_SIGN);
                        MappingRuleHelper.setIntervalValue(ruleResult, key, srcValue, inter);
                    } else if (MappingRuleHelper.isDigit(subValueIndex)) {
                        MappingRuleHelper.setIndexValue(ruleResult, subValueIndex, key, srcValue);
                    } else if (MappingRuleHelper.isLineRange(subValueIndex)) {
                        String[] inter = subValueIndex.split(MappingRuleHelper.LINE_RANGE_SIGN);
                        MappingRuleHelper.setLineRangeValue(ruleResult, key, srcValue, inter);
                    }
                } else if (subValueIndex == null && tag != null) {
                    String key = path + "." + tag;
                    if (value == null) {
                        ruleResult.addToMapValue(key, srcValue);
                    } else {
                        ruleResult.addToMapValue(key, value);
                    }
                }
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(Component component, Object data) {

        Loggers.method().enter(LOG, component);
        RuleResult ruleResult = (RuleResult) data;
        if (data == null) {
            ruleResult = new RuleResult();
        }

        if (component != null) {
            String messages = component.getMessage();
            String fields = component.getField();
            String subValueIndex = component.getSubValueIndex();
            String value = component.getValue();
            String sequence = component.getSequence();
            String pattern = component.getPattern();
            String predicate = component.getPredicate();
            String arguments = component.getArguments();

            String srcValue = tiField.getValue();

            if (value != null && subValueIndex == null) {
                MappingRuleHelper.equalCheck(ruleResult, value, srcValue);
            } else if (value != null && subValueIndex != null) {
                if (MappingRuleHelper.isInterval(subValueIndex)) {
                    String[] inter = subValueIndex.split(MappingRuleHelper.INTERVAL_SIGN);
                    MappingRuleHelper.checkIntervalValue(ruleResult, value, srcValue, inter);
                } else {
                    MappingRuleHelper.checkIndexValue(ruleResult, subValueIndex, value, srcValue);
                }
            } else if (value == null && subValueIndex != null) {
                if (MappingRuleHelper.isInterval(subValueIndex)) {
                    String[] inter = subValueIndex.split(MappingRuleHelper.INTERVAL_SIGN);
                    MappingRuleHelper.existIntervalValue(ruleResult, srcValue, inter);
                } else {
                    MappingRuleHelper.existIndexValue(ruleResult, subValueIndex, srcValue);
                }
            } else if (value == null && pattern != null && srcValue != null) {
                MappingRuleHelper.matchRegExp(ruleResult, srcValue, pattern);
            } else if (predicate != null) {
                // case of Predicate
                if (arguments != null) {
                    mapField.setTag(arguments);
                }
                ruleResult.setMapField(mapField);
                ruleResult.setTiField(tiField);

                predicateComponent(ruleResult, predicate);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    public RuleResult applyRule(DataField mapField, TagDataField tiField, String rule) {

        Loggers.method().enter(LOG, mapField);
        RuleResult result = null;

        if (messageRulesLoader!=null) {
            Construct construct = messageRulesLoader.getConstructFromRuleId(rule);
            if (construct != null) {
                result = process(construct, mapField, tiField);
            }
        } else if ("pred.gen.creDtTm".equals(rule.trim())) {
            result= createDateandTime(); 
        }

        Loggers.method().exit(LOG);
        return result;
    }

    public RuleResult applyRule(HeaderField headerField, TagDataField tiField, String rule) throws XMLException  {

        Loggers.method().enter(LOG, mapField);
        RuleResult result = null;

        DataField mapField = new  DataField();
        mapField.setPath(headerField.getPath());
        mapField.setTag(headerField.getTag());
        mapField.setAttribute("name", headerField.getName());
        mapField.setRule(headerField.getRule());
       
        if (messageRulesLoader!=null) {
            Construct construct = messageRulesLoader.getConstructFromRuleId(rule);
            if (construct != null) {
                result = process(construct, mapField, tiField);
            }
        } else if ("pred.gen.creDtTm".equals(rule.trim())) {
            result= createDateandTime();
        }
        Loggers.method().exit(LOG);
        return result;
    }
    
    public FieldData getMxFieldData() {
        return mxFieldData;
    }

    public void setMxFieldData(FieldData mxFieldData) {
        this.mxFieldData = mxFieldData;
    }

    private RuleResult createDateandTime() {
        RuleResult ruleResult = new RuleResult();
        DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
                .append(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssxxxxx"))
                .toFormatter();
        String tgtValue = ZonedDateTime.now().truncatedTo(ChronoUnit.MINUTES).format(formatter);
        ruleResult.setTextValue(tgtValue);
        ruleResult.setLogicalValue(true);        
        return ruleResult;
    }
}
