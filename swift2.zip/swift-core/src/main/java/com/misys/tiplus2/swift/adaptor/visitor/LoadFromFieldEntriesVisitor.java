package com.misys.tiplus2.swift.adaptor.visitor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.MessageMapException;
import com.misys.tiplus2.swift.maps.MessageMapsLoader;
import com.misys.tiplus2.swift.maps.visitor.LoadMTMessageContainerVisitor;
import com.misys.tiplus2.swift.message.MTMessageContainer;

/**
 * Load data value from EnigmaSwiftPane for a given TI field name or repeated
 * field name with index
 *
 * @author DaiD1
 *
 */
public class LoadFromFieldEntriesVisitor extends LoadMTMessageContainerVisitor<FieldEntryCollection> {

    protected static final Logger LOG = LoggerFactory.getLogger(LoadFromFieldEntriesVisitor.class);

    @Override
    public String getFieldFromSource(FieldEntryCollection source, String fieldName) {
        Loggers.method().enter(LOG, fieldName);

        String result = getPropertiesFieldValue(source, fieldName);

        Loggers.method().exit(LOG, result);
        return result;
    }

    @Override
    public String getFieldFromSource(FieldEntryCollection source, int blockIndex, String fieldName) {
        Loggers.method().enter(LOG, blockIndex, fieldName);

        String result = getPropertiesFieldValue(source,
                FieldPropertiesHelper.convertRepeatedFieldName(fieldName, blockIndex));

        Loggers.method().exit(LOG, result);
        return result;
    }

    private String getPropertiesFieldValue(FieldEntryCollection properties, String fieldPath)
            throws MessageMapException {
        Loggers.method().enter(LOG, fieldPath);
        String result = null;
        FieldEntry entry = properties.findByName(fieldPath);
        if (entry != null) {
            result = entry.getValue();
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    private boolean getMarkerFieldFromPaneMethod(FieldEntryCollection properties, String fieldPath)
            throws MessageMapException {

        Loggers.method().enter(LOG, fieldPath);
        boolean result = false;
        String value = "False";

        FieldEntry entry = properties.findByName(fieldPath);
        if (entry != null) {
            value = entry.getValue();
        }
        if (value.equals("true")) {
            result = true;
        }

        Loggers.method().exit(LOG, result);
        return result;
    }

    @Override
    public boolean isMarkerInSource(FieldEntryCollection arg0, String arg1) {

        return getMarkerFieldFromPaneMethod(arg0, arg1);
    }

    @Override
    public MTMessageContainer getEmbeddedFromSource(MessageMapsLoader arg0, FieldEntryCollection arg1, String arg2) {
        // TODO Auto-generated method stub
        return null;
    }

}
