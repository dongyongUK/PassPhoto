package com.misys.tiplus2.swift.message.validation.error.interpretation;

import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.validation.exception.FieldValidationException;

/**
 * Class for translating a SWIFT field format into description. This class will
 * be injected as a spring singleton bean.
 * 
 * 
 * @author DaiD1
 * 
 */

public class FieldFormatInterpreter {

    static private final String SEMICOLON = ";";

    private Map<String, String> patterns;
    private Map<String, Map<String, String>> descriptions;

    /**
     * Logger
     */
    private static final Logger LOG = LoggerFactory.getLogger(FieldFormatInterpreter.class);

    /**
     * Get a list of descriptions from a field format The descriptions are
     * defined in the pattern_list.properties
     * 
     * @param fieldFormat
     * @return
     * @throws SwiftDriverException
     */
    public FieldDesc getDescriptions(String fieldFormat) throws FieldValidationException {
        Loggers.method().enter(LOG, fieldFormat);

        FieldDesc result = null;

        try {
            Iterator<String> it = patterns.keySet().iterator();
            boolean found = false;
            while (it.hasNext() && !found) {
                String key = it.next();
                String item = patterns.get(key);

                int id = item.indexOf(SEMICOLON);
                Pattern pattern = (id == -1) ? Pattern.compile(item) : Pattern.compile(item.substring(0, id));
                Matcher matcher = pattern.matcher(fieldFormat);

                while (matcher.find()) {
                    result = new FieldDesc();

                    String str = matcher.group();
                    int start = matcher.start();

                    int gc = matcher.groupCount();
                    if (gc == 1) {
                        result.addGroup(matcher.group());
                    } else if (gc > 1) {
                        String first = matcher.group(0);
                        int gStart = 0;
                        String g = "";
                        for (int i = 1; i < gc; i++) {
                            g = matcher.group(i);
                            gStart = matcher.start(i);
                            result.addGroup(g);
                        }
                        String last = first.substring(gStart + g.length());
                        result.addGroup(last);
                    }

                    result.setMatched(str);
                    result.setBegin(start);
                    result.setDescriptions(descriptions.get(key));
                    found = true;
                    break;
                }
            }
        } catch (Exception e) {
            Loggers.general().error(LOG, "Failed to get getDescriptions for " + fieldFormat);
            Loggers.general().error(LOG, e.getMessage());
            throw new FieldValidationException("Failed to get getDescriptions for " + fieldFormat, e);
        }

        Loggers.method().exit(LOG, result);
        return result;
    }

    public void setPatterns(Map<String, String> patterns) {
        this.patterns = patterns;
    }

    public void setDescriptions(Map<String, Map<String, String>> descriptions) {
        this.descriptions = descriptions;
    }

    public String getPattern(String fieldFormat) throws FieldValidationException {
        Loggers.method().enter(LOG, fieldFormat);

        String result = null;

        try {
            Iterator<String> it = patterns.keySet().iterator();
            boolean found = false;
            while (it.hasNext() && !found) {
                String key = it.next();
                String item = patterns.get(key);

                int id = item.indexOf(SEMICOLON);
                Pattern pattern = (id == -1) ? Pattern.compile(item) : Pattern.compile(item.substring(0, id));
                Matcher matcher = pattern.matcher(fieldFormat);

                while (matcher.find()) {
                    found = true;
                    result = key;
                    System.out.println(result);
                    break;
                }
            }
        } catch (Exception e) {
            Loggers.general().error(LOG, e.getMessage());
        }

        Loggers.method().exit(LOG, result);
        return result;
    }
}
