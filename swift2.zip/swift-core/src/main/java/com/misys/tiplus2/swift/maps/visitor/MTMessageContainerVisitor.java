package com.misys.tiplus2.swift.maps.visitor;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.MessageMapException;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.TagDataBlock;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.TagMarkerField;

/**
 * A simple helper visitor that allows for subclasses to just concentrate on
 * processing of a TagDataField, rather than anything else
 *
 * @author DaiD1
 *
 */
public abstract class MTMessageContainerVisitor extends SWIFTMessageMapsVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(MTMessageContainerVisitor.class);

    private DataBlock currentDataBlock;
    protected Map<String, TagDataField> currentDataFieldsByKey;
    protected int currentDataBlockIndex;
    protected MTMessageContainer currentSwiftMessageContainer;

    public void process(List<MTMessageContainer> messages) {
        Loggers.method().enter(LOG);

        for (MTMessageContainer message : messages) {
            process(message);
        }
        Loggers.method().exit(LOG);
    }

    public void process(MTMessageContainer message) {

        Loggers.method().enter(LOG, message);

        currentSwiftMessageContainer = message;
        currentDataFieldsByKey = message.getDataFields();

        MessageMap messageMap = getMessageMapsLoader().findByMessage(message.getType());

        if (messageMap == null) {
            Loggers.general().error(LOG, "Error in process.");
            String error = "Error details: No message map for : " + message.getType() + ". ";
            Loggers.general().error(LOG, error);
            throw new MessageMapException(error);
        }
        messageMap.accept(this, null);

        Loggers.method().exit(LOG);
    }

    @Override
    public Object visit(HeaderField headerField, Object data) {

        Loggers.method().enter(LOG, headerField, data);

        if (headerField.getTag() != null && !headerField.getTag().isEmpty()) {
            TagDataField tagHeaderField = currentSwiftMessageContainer.getHeaderField(headerField.getTag());
            if (tagHeaderField != null) {
                performVisit(headerField, tagHeaderField);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataBlock dataBlock, Object data) {

        Loggers.method().enter(LOG, dataBlock, data);
        currentDataBlock = dataBlock;

        List<TagDataBlock> listOfDataBlock = currentSwiftMessageContainer.getDataBlockList(dataBlock.getName());
        currentDataBlockIndex = 0;
        if (listOfDataBlock != null && listOfDataBlock.size() > 0) {
            for (TagDataBlock tagDataBlock : listOfDataBlock) {
                currentDataFieldsByKey = tagDataBlock.getDataFields();

                for (DataTypeChoice choice : dataBlock.getDataTypeChoices()) {
                    switch (choice.getChosen()) {
                    case DATAFIELD:
                        choice.getDataField().accept(this, data);
                        break;
                    case FIELDOPTIONS:
                        FieldOptions fieldOptions = choice.getFieldOptions();
                        currentFieldOptionsTag = fieldOptions.getTag();
                        fieldOptions.accept(this,data);
                        currentFieldOptionsTag = null;
                        break;
                    default:
                        break;
                    }
                }
                currentDataBlockIndex++;
            }
            currentDataBlockIndex = 0;
            currentDataFieldsByKey = currentSwiftMessageContainer.getDataFields();
        }

        currentDataBlock = null;

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataField dataField, Object data) {

        Loggers.method().enter(LOG, dataField, data);

        TagDataField tagDataField = null;
        String key = dataField.getTag();
        if (currentSequenceMapName!=null) {
            key = key+"_"+currentSequenceMapName;
        }
        tagDataField = currentDataFieldsByKey.get(key);
        
        if (currentDataBlock != null && currentDataBlock.getName() != null && tagDataField != null) {
            performVisit(currentDataBlock, currentDataBlockIndex, dataField, tagDataField);
        } else { 
            performVisit(dataField, tagDataField);
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(MarkerField markerField, Object data) {

        Loggers.method().enter(LOG, markerField, data);

        TagMarkerField tagMarkerField = currentSwiftMessageContainer.getMarkerField(markerField.getTag());
        if (tagMarkerField != null) {
            performVisit(markerField, tagMarkerField);
        }

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(Embedded embedded, Object data) {

        Loggers.method().enter(LOG, embedded, data);

        MTMessageContainer localSwiftMessage = currentSwiftMessageContainer;
        Map<String, TagDataField> localCurrentDataFieldsByKey = currentDataFieldsByKey;

        MTMessageContainer embeddedMessage = currentSwiftMessageContainer.findEmbeddedMessage(embedded.getName());

        if (embeddedMessage != null) {
            currentSwiftMessageContainer = null;
            currentDataFieldsByKey = null;
        }

        performVisit(embedded.getName(), embeddedMessage);

        if (embeddedMessage != null) {
            currentSwiftMessageContainer = localSwiftMessage;

            currentDataFieldsByKey = localCurrentDataFieldsByKey;
            currentDataFieldsByKey = localCurrentDataFieldsByKey;
        }

        Loggers.method().exit(LOG, data);
        return data;
    }

    abstract public void performVisit(String name, MTMessageContainer embeddedMessage);

    abstract public void performVisit(HeaderField headerField, TagDataField headerFieldValue);

    abstract public void performVisit(DataField dataField, TagDataField dataFieldValue);

    abstract public void performVisit(MarkerField markerField, TagMarkerField markerFieldValue);

    abstract public void performVisit(DataBlock dataBlock, int instance, DataField dataField,
            TagDataField dataFieldValue);

}
