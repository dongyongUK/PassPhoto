package com.misys.tiplus2.swift.mx.message.mapping.rule;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoUnit;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class UTCDateTimeOffset {

    public static void main(String[] args) {
        
        TimeZone tz = TimeZone.getDefault();
        System.out.println(tz.getID());
        
        DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
              //  .append(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"))
                .append(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssxxxxx"))
               // .appendOffset("+HH:MM", "+00:00")
                .toFormatter();
        String utc = ZonedDateTime.now().truncatedTo(ChronoUnit.MINUTES).format(formatter);
              
        System.out.println(utc);
        
        DateTimeFormatter f = DateTimeFormatter.ofPattern( "uuuu-MM-dd'T'HH:mm:ss.SSSxxx" ) ;
        String utc2 = OffsetDateTime.parse(utc).format(formatter);
        System.out.println(utc2);
        
      
        
        try {
            XMLGregorianCalendar xmlGregorianCalendar1 =  DatatypeFactory.newInstance().newXMLGregorianCalendar(utc2);
            int timeZone = xmlGregorianCalendar1.getTimezone();
            System.out.println("Time zone off set: "+timeZone);
            xmlGregorianCalendar1.setFractionalSecond(new BigDecimal(0.0));
            xmlGregorianCalendar1.setTimezone(01);
            System.out.println(xmlGregorianCalendar1);
            
            
            XMLGregorianCalendar xmlGregorianCalendar2 = DatatypeFactory.newInstance()
                    .newXMLGregorianCalendar(OffsetDateTime.parse(utc2).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
            System.out.println(xmlGregorianCalendar2);
            
        } catch (DatatypeConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
