package com.misys.tiplus2.swift.maps;

/**
 * Constants for message map
 *
 * @author DaiD1
 *
 */
public interface MessageMapConstant {

    final String SWIFT_MAPPING_NAME = "swift.mapping.xml";
    final String TI_SWIFTMESSAGE_2018 = "fbti-generic-2018.xml";
    final String TI_SWIFTMESSAGE_2021 = "fbti-generic-2021.xml";
    final String TI_SWIFTMESSAGE_MX = "fbti-mx-generic.xml";
    final String SWIFT_MESSAGE_DEFINITION_2021 = "swift-message-definition-2021.xml";
    final String TI_SWIFTMESSAGE_2023 = "fbti-generic-2023.xml";
    final String SWIFT_MESSAGE_DEFINITION_2023 = "swift-message-definition-2023.xml";
    final String SWIFTMESSAGE_MERIDIAN_2018 = "meridian-generic-2018.xml";
    final String TI_SWIFTMESSAGE_2016 = "EnigmaPane_to_SwiftMessage_2016.xml";
    final String SWIFTMESSAGE_MERIDIAN_2016 = "SwiftMessage_to_Meridian_2016.xml";
    final String SWIFT_ENVELOPE_NAME = "swift_envelope";

}
