package com.misys.tiplus2.swift.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.FieldError;
import com.misys.tiplus2.swift.message.MTMessageConstant;

public class MultilineHelper {

    private static final Logger LOG = LoggerFactory.getLogger(MultilineHelper.class);

    private static final String TEMP_NEW_LINE = "\\n";
    private static final String TEMP_NEW_LINE_MARK = "\\\\n";
    private static final String DOUBLE_FORWARD_SLASH = "//";
    private static final String FIELD_FORMAT_ERROR = "Field format error: ";
    private static final String SWIFT_CONSTRAIN_MSG = "SWIFT message constrain: Second and subsequent lines must never start with a colon or hyphen";

    public static String formatField(String tag, String value, int maxLineWidth, int maxLines, int offset, boolean largeOverride,
            String characterSet, StringBuilder rtErrors) {

        Loggers.method().enter(LOG, tag, value, maxLineWidth, maxLines);

        StringBuilder error = new StringBuilder();
        String returnVal = value;
        String firstLine=null;
        String lastLine=null;
       
        if (value != null && value.length() > 0 && maxLines > 0 && maxLineWidth > 0) {
            
            if (offset==1 && maxLines>1){
                int beginIndex = value.indexOf(MTMessageConstant.WINDOWS_CRLF);
                firstLine = value.substring(0, beginIndex+2);
                value = value.substring(beginIndex+2);
            } else if(offset==-1 && maxLines>1){
                if (value.endsWith(MTMessageConstant.WINDOWS_CRLF)){
                    value = value.substring(0, value.length()-2);
                }
                int endIndex = value.lastIndexOf(MTMessageConstant.WINDOWS_CRLF);
                if (endIndex!=-1) {
                	lastLine = value.substring(endIndex);
                	if (endIndex>0) {
                		value = value.substring(0, endIndex);
                	} else {
                		value = null;
                	}
                }
            }
            
            if (value!=null) {
            	value = value.replace(MTMessageConstant.WINDOWS_CRLF, TEMP_NEW_LINE);
            }
            returnVal = value;

            int lineCount = 0;
            int mLines = maxLines;
            int mLineWidth = maxLineWidth;
            String str = value;
            StringBuilder result = new StringBuilder();

            if (str!=null) {
            String[] lineBlock = str.split(TEMP_NEW_LINE_MARK);
            boolean isCodeFormat = false;
            int delta = 0;

            for (int i = 0; i < lineBlock.length; i++) {
                String line = lineBlock[i];
                // if first line is empty line
                if (i == 0 && line.trim().length() == 0) {
                    // SWIFT format error but will pass to Validation to handle
                    result.append(" " + TEMP_NEW_LINE);
                    lineCount++;
                    // strip any empty line after the first line, do the same as
                    // old TI
                } else if (line.trim().length() > 0) {
                    // SWIFT manual requirement: Second and subsequent lines
                    // within the data content must never start with a colon or
                    // a hyphen
                    if (i == 0 && ("72".equals(tag)||"77B".equals(tag)) && checkField72Or77B(line)) {
                        // check if it is code format of tag72 or tag 77B
                        isCodeFormat = true;
                        delta = 2;
                    }
                    // if (i > 0 && (line.startsWith(":") ||
// line.startsWith("-"))) {
                    // error.append(FIELD_FORMAT_ERROR).append(SWIFT_CONSTRAIN_MSG);
                    // }
                    // do nothing apart from adding the line
                    if ((i == 0 && line.length() <= mLineWidth)
                            || (i > 0 && isCodeFormat && line.startsWith(DOUBLE_FORWARD_SLASH) && line.length() <= mLineWidth)
                            || (i > 0 && isCodeFormat && !line.startsWith(DOUBLE_FORWARD_SLASH) && line.length()
                                    + delta <= mLineWidth)) {
                        if (i == 0 || line.startsWith(DOUBLE_FORWARD_SLASH)) {
                            result.append(line).append(TEMP_NEW_LINE);
                        } else if (i > 0 && line.startsWith("/") && line.substring(1).contains("/")) {
                            result.append(line).append(TEMP_NEW_LINE);
                        } else if (i > 0 && isCodeFormat) {
                            result.append(DOUBLE_FORWARD_SLASH);
                            result.append(line).append(TEMP_NEW_LINE);
                        }
                        lineCount++;
                    } else { // need to wrap the line
                        // empty character(s) at the end of line will not be
                        // counted
                        String[] words = line.split(" ");
                        StringBuilder newLine = new StringBuilder();
                        for (int j = 0; j < words.length; j++) {
                            String word = words[j];
                            // visible word only
                            if (word.length() > 0) {
                                // the length of word is less than line-width
                                if (word.length() < mLineWidth) {
                                    if (newLine.length() + word.length() + 1 <= mLineWidth) {
                                        if (newLine.length() > 0 || j > 0) {
                                            newLine.append(" ");
                                        } else if (isCodeFormat && i > 0 && !word.startsWith(DOUBLE_FORWARD_SLASH)) {
                                            if (!word.startsWith("/") || !word.substring(1).contains("/")) {
                                                newLine.append(DOUBLE_FORWARD_SLASH);
                                            }
                                        }
                                        newLine.append(word);
                                        // ending the new line with NEW_LINE
                                    } else {
                                        result.append(newLine).append(TEMP_NEW_LINE);
                                        // starting new line
                                        newLine = new StringBuilder();
                                        // the first word the the new line
                                        // tag72 new line starting with //
                                        if (isCodeFormat && !word.startsWith(DOUBLE_FORWARD_SLASH)) {
                                            newLine.append(DOUBLE_FORWARD_SLASH);
                                        }
                                        newLine.append(word);
                                        lineCount++;
                                    }
                                } else {
                                    if (newLine.length() > 0
                                            && (result.length() < 1 || result.toString().endsWith(TEMP_NEW_LINE))) {
                                        result.append(newLine).append(TEMP_NEW_LINE);
                                        lineCount++;
                                        // starting new line
                                        newLine = new StringBuilder();
                                        // the first word the the new line
                                        // tag72 new line starting with //
                                        if (isCodeFormat) {
                                            newLine.append(DOUBLE_FORWARD_SLASH);
                                        }
                                    }
                                    // the length of word is equal to line-width
                                    if (word.length() == mLineWidth) {
                                        result.append(word).append(TEMP_NEW_LINE);
                                        lineCount++;
                                        // the length of word is large than
                                        // line-width
                                    } else {
                                        int beginIndex = 0;
                                        int endIndex = mLineWidth;
                                        
                                        do {
                                        	if (lineCount>0 && delta==2) {
                                        		result.append(DOUBLE_FORWARD_SLASH);
                                        	}
                                            result.append(word.subSequence(beginIndex, endIndex)).append(TEMP_NEW_LINE);
                                            lineCount++;
                                            beginIndex = endIndex;
                                            int maxLwDelta = mLineWidth - delta;
                                            endIndex = (word.length() - maxLwDelta > endIndex) ? endIndex += maxLwDelta
                                                    : word.length();
                                        } while (endIndex < word.length());
                                        if (lineCount>0 && delta==2) {
                                    		result.append(DOUBLE_FORWARD_SLASH);
                                    	}
                                        result.append(word.subSequence(beginIndex, endIndex)).append(TEMP_NEW_LINE);
                                        lineCount++;
                                    }
                                }
                            } else { // if the word is a space
                                if (newLine.length() + 1 < mLineWidth) {
                                    if (j > 0) {
                                        newLine.append(" ");
                                    }
                                } else {
                                    result.append(newLine).append(TEMP_NEW_LINE);
                                    newLine = new StringBuilder();
                                    // the first word the the new line
                                    // tag72 new line starting with //
                                    if (isCodeFormat && !word.startsWith(DOUBLE_FORWARD_SLASH)) {
                                        newLine.append(DOUBLE_FORWARD_SLASH);
                                    }
                                    newLine = newLine.append(word);
                                    lineCount++;
                                }
                            }
                        }
                        if (newLine.length() > 0 && (result.length() < 1 || result.toString().endsWith(TEMP_NEW_LINE))) {
                            result.append(newLine).append(TEMP_NEW_LINE);
                            lineCount++;
                        }
                    }
                }
              }
            }
            
            // Only those SWIFT message which allow large narrative
            // need to produce, because this error will be missed by
            // Swift message validation (after message splitting)
            if (mLines - lineCount < 0 && largeOverride) {
                if (!error.toString().contains(SWIFT_CONSTRAIN_MSG)) {
                    error.append(FIELD_FORMAT_ERROR).append("'").append(mLines).append("*").append(maxLineWidth)
                            .append(characterSet).append("'");
                }

            }

            returnVal = result.toString();
            
            // replace temp new line mark with new_line
            returnVal = returnVal.replace(TEMP_NEW_LINE, MTMessageConstant.WINDOWS_CRLF);
            
            while (returnVal.endsWith(MTMessageConstant.WINDOWS_CRLF)) {
                returnVal = returnVal.substring(0, returnVal.length() - MTMessageConstant.WINDOWS_CRLF.length());
            }
            
            if (offset==1){
                returnVal = firstLine+returnVal;
            } else if(offset==-1 && lastLine!=null){
            	returnVal = (returnVal!=null)?returnVal+lastLine:lastLine;
            }
            
            // the first line cannot starting with \r\n
            if (returnVal.startsWith(MTMessageConstant.WINDOWS_CRLF)) {
            	 if (!error.toString().contains(SWIFT_CONSTRAIN_MSG)) {
                     error.append(FIELD_FORMAT_ERROR).append("'").append(mLines).append("*").append(maxLineWidth)
                             .append(characterSet).append("'");
                 }
            }
            // set error code
            if (!error.toString().isEmpty()) {
                rtErrors.append(error.toString());
            }
        }
        Loggers.method().exit(LOG, returnVal);
        return returnVal;
    }

    private static boolean checkField72Or77B(String line) {
        Loggers.method().enter(LOG, line);
        boolean result = false;

        if (line != null) {
            result = line.matches("^\\/[A-Z]{1,8}\\/.*");
        }

        Loggers.method().exit(LOG, result);
        return result;
    }
}
