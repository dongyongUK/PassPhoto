package com.misys.tiplus2.swift.message;

import com.misys.tiplus2.swift.maps.MessageMapsLoader;
import com.misys.tiplus2.swift.maps.visitor.SWIFTMessageTargetResolver;
import com.misys.tiplus2.swift.message.validation.rule.MessageRulesLoader;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;

/**
 * This is a convenience interface that accepts an untyped source/target for the
 * loader/unloader to them be able to use specific typed versions.
 *
 * @author DaiD1
 *
 */
public interface MessageContainerLoaderUnloader {

    Object unloadSWIFTMessageContainer(MessageMapsLoader messageMapsLoader, SWIFTMessageTargetResolver resolver,
            MTMessageContainer message);

    MTMessageContainer loadSWIFTMessageContainer(MessageMapsLoader messageMapsLoader, Object source, String type);
    
    Object unloadSWIFTMXMessageContainer(MessageMapsLoader messageMapsLoader,  MessageRulesLoader rulesLoader, SWIFTMessageTargetResolver resolver,
            MXMessageContainer message);
    
    MXMessageContainer loadSWIFTMXMessageContainer(MessageMapsLoader messageMapsLoader, MessageRulesLoader rulesLoader, Object source, String type);
}
