package com.misys.tiplus2.swift.message.validation.exception;

import com.misys.tiplus2.swift.exception.SWIFTMessageException;

/**
 * FieldValidationException
 *
 * @author DaiD1
 *
 */
public class FieldValidationException extends SWIFTMessageException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public FieldValidationException() {
        super();
    }

    public FieldValidationException(String message) {
        super(message);
    }

    public FieldValidationException(Throwable cause) {
        super(cause);
    }

    public FieldValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public FieldValidationException(String code, String message) {
        super(code, message);
    }

    public FieldValidationException(String code, String message, Throwable cause) {
        super(code, message, cause);

    }

}
