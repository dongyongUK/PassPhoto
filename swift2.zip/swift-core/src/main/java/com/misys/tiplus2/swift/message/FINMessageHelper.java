package com.misys.tiplus2.swift.message;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.contract.AssertArgument;
import com.misys.tiplus2.foundations.lang.logging.Loggers;

public class FINMessageHelper {

    private static final Logger LOG = LoggerFactory.getLogger(FINMessageHelper.class);

    public static void extractFINMessages(String finMessages, List<String> finMessageList) {

        AssertArgument.notBlank(finMessages, "finMessages");
        Loggers.method().enter(LOG, finMessages);

        if (finMessages.contains(MTMessageConstant.BLOCK1_START)) {
            int i1 = finMessages.indexOf(MTMessageConstant.BLOCK1_START);
            if (!finMessages.substring(i1 + 3).contains(MTMessageConstant.BLOCK1_START)) {
                finMessageList.add(finMessages);
            } else {
                int i2 = finMessages.indexOf(MTMessageConstant.BLOCK1_START, i1 + 3);
                finMessageList.add(finMessages.substring(0, i2));
                extractFINMessages(finMessages.substring(i2), finMessageList);
            }
        }

        Loggers.method().exit(LOG);
    }

    // get block 4 only
    public static String extractFINMessageBody(String finMessage) {

        Loggers.method().enter(LOG, finMessage);

        String result = null;

        finMessage = normalize(finMessage);
        if (finMessage != null && finMessage.contains(MTMessageConstant.BLOCK1_START)
                && finMessage.contains(MTMessageConstant.BLOCK2_START)
                && finMessage.contains(MTMessageConstant.BLOCK4_START)) {
            int begin = finMessage.indexOf(MTMessageConstant.BLOCK4_START);
            int end = finMessage.indexOf(MTMessageConstant.BLOCK4_END);
            result = finMessage.substring(begin + 5, end);
        }

        Loggers.method().exit(LOG, result);
        return result;

    }

    public static String getMessageType(String finMessage) {

        AssertArgument.notBlank(finMessage, "finMessage");
        Loggers.method().enter(LOG, finMessage);

        String result = null;

        int begin = finMessage.indexOf(MTMessageConstant.BLOCK2_START);
        begin = begin + MTMessageConstant.BLOCK2_START.length() + 1;
        int end = begin + 3;
        result = finMessage.substring(begin, end);

        Loggers.method().exit(LOG, result);
        return result;
    }

    public static boolean isnForwardSlashmFormat(String text) {

        AssertArgument.notBlank(text, "text");
        Loggers.method().enter(LOG, text);

        boolean result = false;
        Pattern pattern = Pattern.compile("^\\d{1,1}\\x2F\\d{1,1}$");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            result = true;
        }

        Loggers.method().exit(LOG, result);
        return result;
    }

    public static String extractFirstLine(String text) {

        text = normalize(text);
        String result = text;
        if (text != null && !text.isEmpty()) {
            int i = text.indexOf(MTMessageConstant.WINDOWS_CRLF);

            if (i != -1) {
                result = text.substring(0, i);
            } else {
                result = text;   
            }
        }

        return result;
    }
    
    public static String excludeFirstLine(String text) {

        text = normalize(text);
        String result = text;
        if (text != null && !text.isEmpty()) {
            int i = text.indexOf(MTMessageConstant.WINDOWS_CRLF);

            if (i != -1 && text.length()>i+2) {
                result = text.substring(i+2);
            } else {
                result = null;
            }
        }
        return result;
    }

    public static String[] extractLines(String text) {

        text = normalize(text);
        if (text.endsWith("\r\n")) {
            text = text.substring(0, text.length() - 2);
        }
        return text.split("\\r\\n");
    }

    public static String getHeaderBlock(String finMessage) {
        Loggers.method().enter(LOG, finMessage);
        String result = null;

        int index = finMessage.indexOf(MTMessageConstant.BLOCK4_START);

        result = finMessage.substring(0, index);
        Loggers.method().exit(LOG, result);

        return result;

    }

    public static String normalize(String text) {
        String result = null;

        if (text != null) {
            char[] marker = { 0x8a }; // non-swift charters
            CharSequence cseq = java.nio.CharBuffer.wrap(marker);

            if (text.contains(MTMessageConstant.WINDOWS_CRLF)) {

                text = text.replace((CharSequence) MTMessageConstant.WINDOWS_CRLF, cseq);
            }
            if (text.contains(MTMessageConstant.UNIX_LF)) {
                text = text.replace(MTMessageConstant.UNIX_LF, MTMessageConstant.WINDOWS_CRLF);
            }
            result = text.replace(cseq, MTMessageConstant.WINDOWS_CRLF);
        }
        return result;

    }

}
