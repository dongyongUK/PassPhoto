package com.misys.tiplus2.swift.mx.maps.visitor;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.MessageMapException;
import com.misys.tiplus2.swift.maps.visitor.SWIFTMessageMapsVisitor;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.TagMarkerField;
import com.misys.tiplus2.swift.mx.message.FieldData;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;
/**
 * 
 * @author DaiD1
 *
 */
public abstract class MXMessageContainerVisitor extends SWIFTMessageMapsVisitor {

	 private static final Logger LOG = LoggerFactory.getLogger(MXMessageContainerVisitor.class);

	    private DataBlock currentDataBlock;
	    protected Map<String, FieldData> currentDataFieldsByKey;
	    protected int currentDataBlockIndex;
	    protected MXMessageContainer currentSwiftMessageContainer;
	    protected MXMessageContainer bah;

	    public void process(List<MXMessageContainer> messages) {
	        Loggers.method().enter(LOG);

	        for (MXMessageContainer message : messages) {
	            process(message);
	        }
	        Loggers.method().exit(LOG);
	    }

	    public void process(MXMessageContainer message) {

	        Loggers.method().enter(LOG, message);

	        currentSwiftMessageContainer = message;
	        currentDataFieldsByKey = message.getFieldDataByKey();
	        MessageMap messageMap = getMessageMapsLoader().findByMessage(message.getMessageId());

	        if (messageMap == null) {
	            Loggers.general().error(LOG, "Error in process.");
	            String error = "Error details: No message map for : " + message.getMessageId() + ". ";
	            Loggers.general().error(LOG, error);
	            throw new MessageMapException(error);
	        }
	        messageMap.accept(this, null);

	        Loggers.method().exit(LOG);
	    }

	    @Override
	    public Object visit(HeaderField headerField, Object data) {

	        Loggers.method().enter(LOG, headerField, data);

	        if (headerField.getTag() != null && !headerField.getTag().isEmpty()) {
	            FieldData tagHeaderField = currentSwiftMessageContainer.getField(headerField.getTag());
	            if (tagHeaderField != null) {
	                performVisit(headerField, tagHeaderField);
	            }
	        }
	        Loggers.method().exit(LOG, data);
	        return data;
	    }

	    @Override
	    public Object visit(DataBlock dataBlock, Object data) {

	        Loggers.method().enter(LOG, dataBlock, data);
	        currentDataBlock = dataBlock;
            /*
	        List<BlockData> listOfDataBlock = currentSwiftMessageContainer.getDataBlockList(dataBlock.getName());
	        currentDataBlockIndex = 0;
	        if (listOfDataBlock != null && listOfDataBlock.size() > 0) {
	            for (DataBlock tagDataBlock : listOfDataBlock) {
	                currentDataFieldsByKey = tagDataBlock.getDataFields();

	                for (DataTypeChoice choice : dataBlock.getDataTypeChoices()) {
	                    switch (choice.getChosen()) {
	                    case DATAFIELD:
	                        choice.getDataField().accept(this, data);
	                        break;
	                    case FIELDOPTIONS:
	                        FieldOptions fieldOptions = choice.getFieldOptions();
	                        currentFieldOptionsTag = fieldOptions.getTag();
	                        fieldOptions.accept(this,data);
	                        currentFieldOptionsTag = null;
	                        break;
	                    default:
	                        break;
	                    }
	                }
	                currentDataBlockIndex++;
	            }
	            currentDataBlockIndex = 0;
	            currentDataFieldsByKey = currentSwiftMessageContainer.getFieldDataByKey();
	        }
            */
	        currentDataBlock = null;

	        Loggers.method().exit(LOG, data);
	        return data;
	    }

	    @Override
	    public Object visit(DataField dataField, Object data) {

	        Loggers.method().enter(LOG, dataField, data);

	        FieldData fieldDataValue = null;
	        String path = dataField.getPath();;
	        String tag = dataField.getTag();
	        
	        fieldDataValue = currentDataFieldsByKey.get(path+"."+tag);
	        
	        if (currentDataBlock != null && currentDataBlock.getName() != null && fieldDataValue != null) {
	            performVisit(currentDataBlock, currentDataBlockIndex, dataField, fieldDataValue);
	        } else { 
	            performVisit(dataField, fieldDataValue);
	        }
	        Loggers.method().exit(LOG, data);
	        return data;
	    }

	    @Override
	    public Object visit(MarkerField markerField, Object data) {

	        Loggers.method().enter(LOG, markerField, data);

	        Loggers.method().exit(LOG, data);
	        return data;
	    }

	    @Override
	    public Object visit(Embedded embedded, Object data) {

	        Loggers.method().enter(LOG, embedded, data);

	        Loggers.method().exit(LOG, data);
	        return data;
	    }

	    abstract public void performVisit(String name, MTMessageContainer embeddedMessage);

	    abstract public void performVisit(HeaderField mapDataField, FieldData fieldData);

	    abstract public void performVisit(DataField mapDataField, FieldData fieldData);

	    abstract public void performVisit(MarkerField markerField, TagMarkerField markerFieldValue);

	    abstract public void performVisit(DataBlock dataBlock, int instance, DataField dataField,
	            FieldData dataFieldValue);
}
