package com.misys.tiplus2.swift.mx.maps.visitor;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.foundations.xml.XMLException;
import com.misys.tiplus2.swift.exception.SWIFTMessageException;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;
import com.misys.tiplus2.swift.message.validation.rule.visitor.MTMXMappingRuleValidateVisitor;
import com.misys.tiplus2.swift.mx.message.BlockData;
import com.misys.tiplus2.swift.mx.message.FieldData;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;
import com.misys.tiplus2.swift.mx.message.MXMessageFieldHelper;

/**
 * This is geared towards a visitor that will get data from another construct
 * and populate a SWIFTMXMessageContainer.
 *
 * @author DaiD1
 *
 */
public abstract class LoadMXMessageContainerVisitor<T> extends MXMessageContainerFieldsVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(LoadMXMessageContainerVisitor.class);

    protected T source;
    protected Map<String, FieldData> currentHeaderFieldsByKey;
    protected MTMXMappingRuleValidateVisitor ruleVisitor;
    protected String msgId;
    protected MessageMap messageMap;

    /**
     * This is the main processing method, that given a foreign container, and
     * the message type known to that container, it will populate a
     * SWIFTMessageContainer and return it.
     *
     * @param source
     * @param type
     * @return
     */
    public MXMessageContainer load(T source, String type) {

        Loggers.method().enter(LOG, source, type);
        MXMessageContainer result = null;

        messageMap = getMessageMapsLoader().findByName(type);
        this.source = source;

        if (messageMap != null) {
            msgId = type;
            ruleVisitor = new MTMXMappingRuleValidateVisitor();
            ruleVisitor.initialise(getRulesLoader());

            currentSwiftMxMessageContainer = new MXMessageContainer(messageMap.getMessage());
            String header = messageMap.getInclude();
            if (header != null && !header.isEmpty()) {
                currentHeaderContainer = new MXMessageContainer(header);
            }
            currentDataFieldsByKey = currentSwiftMxMessageContainer.getFieldDataByKey();
            currentHeaderFieldsByKey = currentHeaderContainer.getFieldDataByKey();
            currentListFieldByKey = currentSwiftMxMessageContainer.getListFieldByKey();

            messageMap.accept(this, result);

            // Add fields to Business Application Head
            FieldData msgIDField = currentSwiftMxMessageContainer.findBizMsgId();
            if (msgId != null) {
                FieldData bizMsgIdr = new FieldData("AppHdr", "BizMsgIdr", msgIDField.getTagValue());
                currentHeaderContainer.addFieldData(bizMsgIdr);
                currentHeaderContainer.setBizMsgId(bizMsgIdr);
            }

            String typeValue =type;
            if (typeValue.length()>15) {
                typeValue = typeValue.substring(0,15);
            }
            
            FieldData msgDefIdr = new FieldData("AppHdr", "MsgDefIdr", typeValue);
            
            currentHeaderContainer.addFieldData(msgDefIdr);

            String bizSrvVal = null;
            if (getMessageMapsLoader()!=null) { // load from EAR deployment
            	bizSrvVal= getMessageMapsLoader().getBizSrv(type);
            	if (isHVPS()) {
            		bizSrvVal= getMessageMapsLoader().getBizSrv(type+".hvps");
            	}
            } else if ( getRulesLoader()!=null) { // load Embed deployment
            	bizSrvVal= getRulesLoader().getBizSrv(type);
            	if (isHVPS()) {
            		bizSrvVal= getRulesLoader().getBizSrv(type+".hvps");
            	}
            }
           
            FieldData bizSvc= new FieldData("AppHdr", "BizSvc", bizSrvVal);
            currentHeaderContainer.addFieldData(bizSvc);
            currentSwiftMxMessageContainer.setBusinessAppHeader(currentHeaderContainer);
        }
        result = currentSwiftMxMessageContainer;
        
        Loggers.method().exit(LOG, result);
        return result;
    }

    abstract public String getFieldFromSource(T source, String fieldName);

    abstract public List<Map<String, Object>> getListFieldFromSource(T source, String fieldName);
 
    abstract public String getFieldFromSource(T source, int blockIndex, String fieldname);

    @Override
    public Object visit(HeaderField headerField, Object data) {
        Loggers.method().enter(LOG, headerField, data);

        // if both path and tag is empty, then do not map this field
        if (!StringUtils.isEmpty(headerField.getPath()) || !StringUtils.isEmpty(headerField.getTag())) {
            FieldData fieldValue = new FieldData(headerField.getPath(), headerField.getTag());
            String key = headerField.getPath();
            if (StringUtils.isEmpty(headerField.getPath())) {
                key = headerField.getTag();
            } else if (!StringUtils.isEmpty(headerField.getTag())) {
                key = key + "." + headerField.getTag();
            }
            if (headerField.getConstant() != null) {
                fieldValue.setTagValue(headerField.getConstant());
                currentHeaderFieldsByKey.put(key, fieldValue);
            } else {
                String rule = headerField.getRule();
                if (rule == null) {
                    String value = getFieldFromSource(source, headerField.getName());
                    if (value != null && !value.isEmpty()) {
                        fieldValue = new FieldData(headerField.getPath(), headerField.getTag(), value);
                        currentHeaderFieldsByKey.put(key, fieldValue);
                    }
                } else {
                    RuleResult ruleResult = null;
                    try {
                        String value = getFieldFromSource(source, headerField.getName());
                        
                        ruleResult = ruleVisitor.applyRule(headerField,
                                new TagDataField(headerField.getName(), value), rule);
                    } catch (XMLException e) {
                        LOG.error("Failed to visit HeaderField:", headerField.getName());
                        throw new SWIFTMessageException("Failed to visit HeaderField: ", e);
                    }
                    if (ruleResult != null) {
                        if (rule.startsWith("pred.gen.")) {
                            String value = ruleResult.getTextValue();
                            fieldValue.setTagValue(value);
                            currentHeaderFieldsByKey.put(key, fieldValue);
                        } else {
                            Map<String, String> fieldMap = ruleResult.getMapValue();
                            if (fieldMap != null) {
                                for (Entry<String, String> item : fieldMap.entrySet()) {
                                    String theKey = item.getKey();
                                    fieldValue = new FieldData(getPathFromKey(theKey), getTagFromKey(theKey),
                                            item.getValue());
                                    currentHeaderFieldsByKey.put(item.getKey(), fieldValue);
                                }
                            } 
                        }
                    } else {
                        String value = getFieldFromSource(source, headerField.getName());
                        if (value != null && !value.isEmpty()) {
                            fieldValue = new FieldData(headerField.getPath(), headerField.getTag(), value);
                            currentHeaderFieldsByKey.put(key, fieldValue);
                        }
                    }
                }
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataBlock dataBlock, Object data) {
        Loggers.method().enter(LOG, dataBlock, data);

        Map<String, FieldData> tempDataFields = currentDataFieldsByKey;
        currentDataBlockName = dataBlock.getName();

        int repeat = Integer.parseInt(dataBlock.getRepeat());
        String sn = this.getClass().getSimpleName();

        for (int i = 0; i < repeat; i++) {
            currentDataBlockIndex = i;
            BlockData tagDataBlock = new BlockData(currentDataBlockName);
            currentDataFieldsByKey = tagDataBlock.getDataFields();
            if (currentSequenceMapName != null) {
                tagDataBlock.setSequence(currentSequenceMapName);
            }

            for (DataTypeChoice choice : dataBlock.getDataTypeChoices()) {
                switch (choice.getChosen()) {
                case DATAFIELD:
                    choice.getDataField().accept(this, data);
                    break;
                case FIELDOPTIONS:
                    FieldOptions fieldOptions = choice.getFieldOptions();
                    currentFieldOptionsTag = fieldOptions.getTag();
                    fieldOptions.accept(this, data);
                    currentFieldOptionsTag = null;
                    break;
                default:
                    break;
                }
            }

            if (currentDataFieldsByKey != null && currentDataFieldsByKey.size() > 0) {
                // TODO will update to block
                // currentSwiftMxMessageContainer.addDataBlock(currentDataBlockName,
                // tagDataBlock);
                tempDataFields.putAll(currentDataFieldsByKey);
            } else {
                // stop loop if currentDataFieldsByKey is empty
                break;
            }

        }
        currentDataBlockName = null;
        currentDataBlockIndex = 0;
        currentDataFieldsByKey = tempDataFields;

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataField dataField, Object data) {
        Loggers.method().enter(LOG, dataField, data);

        // if both path and tag is empty, then do not map this field
        if (!StringUtils.isEmpty(dataField.getPath()) || !StringUtils.isEmpty(dataField.getTag())) {

            String path = dataField.getPath();
            String tag = dataField.getTag();
            String ftiFieldName = dataField.getName();
            String rule = dataField.getRule();

            FieldData fieldValue = new FieldData(path, tag);

            String key = path;
            if (StringUtils.isEmpty(path)) {
                key = tag;
            } else if (!StringUtils.isEmpty(tag)) {
                key = key + "." + tag;
            }

            if (dataField.getConstant() != null && dataField.getTag() != null) {
                fieldValue.setTagValue(dataField.getConstant());
                currentDataFieldsByKey.put(key, fieldValue);
            } else {
                if (!MXMessageFieldHelper.hasArray(key)) { // no array
                    String value = null;
                    
                    if ( rule==null || (rule!=null && !rule.startsWith("pred.gen."))) {
                        
                        if (currentDataBlockName == null) {
                            value = getFieldFromSource(source, ftiFieldName);
                        } else {
                            value = getFieldFromSource(source, currentDataBlockIndex, ftiFieldName);
                        }
                        
                        if (value != null && !value.isEmpty()) {
                            if (rule == null) {
                                fieldValue = new FieldData(path, tag, value);
                                currentDataFieldsByKey.put(key, fieldValue);
                            } else {
                                RuleResult ruleResult = ruleVisitor.applyRule(dataField,
                                        new TagDataField(dataField.getName(), value), rule);
                                if (ruleResult != null && !rule.startsWith("pred.gen.")) {
                                    Map<String, String> fieldMap = ruleResult.getMapValue();
                                    if (fieldMap != null) {
                                        for (Entry<String, String> item : fieldMap.entrySet()) {
                                            String theKey = item.getKey();
                                            fieldValue = new FieldData(getPathFromKey(theKey), getTagFromKey(theKey),
                                                    item.getValue());
                                            currentDataFieldsByKey.put(item.getKey(), fieldValue);
                                        }
                                    }
                                } else if (ruleResult != null ) {
                                    value = ruleResult.getTextValue();
                                    fieldValue = new FieldData(path, tag, value);
                                    currentDataFieldsByKey.put(key, fieldValue);
                                }
                            }
                        }
                        
                    } else if (rule!=null) {
                        RuleResult ruleResult = ruleVisitor.applyRule(dataField,
                                new TagDataField(dataField.getName(), ""), rule);
                        
                        if (ruleResult!=null) {
                            value = ruleResult.getTextValue();
                            fieldValue.setTagValue(value);
                            currentDataFieldsByKey.put(key, fieldValue);
                        }
                    }
                } else { // List value
                    // array key for the first array in path and tag
                    String mxListKey = MXMessageFieldHelper.getArrayKey1(path,tag);
                    String ftiArrayKey = MXMessageFieldHelper.getArrayKey1(ftiFieldName);
                    List<Map<String, Object>> objList = currentListFieldByKey.get(mxListKey);
                    // the first ftiFieldName will trigger all values in the list field 
                    if (objList == null) {
                        objList = getListFieldFromSource(source, ftiArrayKey);
                        if (objList!=null && objList.size()>0) {
                            currentListFieldByKey.put(mxListKey,objList);
                        }
                    }
                }
            }
        }

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(MarkerField markerField, Object data) {
        Loggers.method().enter(LOG, markerField, data);

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public void performVisit(String name, MXMessageContainer embeddedMessage) {

        Loggers.method().enter(LOG, name, embeddedMessage);

        Loggers.method().exit(LOG);
    }

    protected String getPathFromKey(String key) {

        String result = null;
        if (key != null && !key.isEmpty() && key.contains(".")) {
            int idx = key.lastIndexOf(".");
            result = key.substring(0, idx);
        }
        return result;
    }

    protected String getTagFromKey(String key) {

        String result = null;
        if (key != null && !key.isEmpty() && key.contains(".")) {
            int idx = key.lastIndexOf(".");
            result = key.substring(idx + 1);
        }
        return result;
    }

    /**
     * remove the first array sings [n] from path
     * 
     * @param path
     * @return
     */
    protected String removeArraySigns(String path) {

        String result = path;
        if (!StringUtils.isEmpty(path) && path.contains("[") && path.contains("]")) {
            int indx = path.indexOf("[");
            int indx2 = path.indexOf("]", indx + 1);
            String tmp = path.substring(0, indx);
            if (indx2 + 1 < path.length()) {
                result = tmp + path.substring(indx2 + 1);
            } else {
                result = tmp;
            }
        }
        return result;
    }

    
    private boolean isHVPS() {
    	
    	boolean result = false;
    	
    	for (Entry<String, FieldData> entry:currentDataFieldsByKey.entrySet()) {
    		String key =  entry.getKey();
    		FieldData eValue =  entry.getValue();
    		
    		if (key.endsWith(".SttlmMtd")&& eValue!=null && "CLRG".equals(eValue.getTagValue())) {
    		   result = true;	
    		}
    	}
    	
    	return result;
    }
}
