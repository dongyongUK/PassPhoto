package com.misys.tiplus2.swift.maps;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.modelmbean.XMLParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.MessageMapNamespace;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMaps;
import com.misys.tiplus2.foundations.lang.contract.AssertArgument;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.foundations.xml.XMLParser;
import com.misys.tiplus2.foundations.xml.sax.SAXElement;

/**
 * MessageMapLoader load swift mapping file
 *
 * @author DaiD1
 *
 */
public class MessageMapsLoader {

    private static final Logger LOG = LoggerFactory.getLogger(MessageMapsLoader.class);

    private MessageMaps messageMaps;
    
    private Map<String, String> bizSrvMap;

    public MessageMapsLoader(String fileName) throws XMLParseException {
        Loggers.method().enter(LOG);

        try {
            ClassLoader loader = MessageMapsLoader.class.getClassLoader();
            Reader mappingFile = new InputStreamReader(loader.getResourceAsStream(fileName));

            XMLParser parser = new XMLParser(MessageMapNamespace.getNamespaces());

            SAXElement saxElement = parser.getSAXElement(mappingFile);
            messageMaps = (MessageMaps) saxElement;

        } catch (Exception e) {
            LOG.error("Fail to load file:", fileName);
            throw new XMLParseException(e, "Fail to load map file");
        }
        Loggers.method().exit(LOG);
    }

    /**
     * Get Message map from a messageMap name, such as MT201
     *
     * @param name
     * @return
     */
    public MessageMap findByName(String name) {
        AssertArgument.notBlank(name, "name");
        Loggers.method().enter(LOG, name);
        MessageMap result = messageMaps.getMessageByName(name);

        Loggers.method().exit(LOG, result);
        return result;
    }

    public MessageMap findByMessage(String message) {
        AssertArgument.notBlank(message, "message");
        Loggers.method().enter(LOG, message);
        MessageMap result = messageMaps.getMessageByMessage(message);
        Loggers.method().exit(LOG, result);
        return result;
    }

    public MessageMap findBySourceName(String sourceName) {
        AssertArgument.notBlank(sourceName, "sourceName");
        Loggers.method().enter(LOG, sourceName);
        MessageMap result = messageMaps.getMessageBySourceName(sourceName);

        Loggers.method().exit(LOG, result);
        return result;
    }

    public List<String> getMessageTypes() {
        List<String> result = new ArrayList<String>();
        for (MessageMap item : messageMaps.getMessageMaps()) {
            result.add(item.getName());
        }

        return result;
    }

    public String getVersion() {

        Loggers.method().enter(LOG);
        String result = messageMaps.getVersion();
        Loggers.method().exit(LOG, result);
        return result;
    }

    public void setBizSrvMap(Map<String, String> bizSrvMap) {
		this.bizSrvMap = bizSrvMap;
	}
	

	public Map<String, String> getBizSrvMap() {
		return this.bizSrvMap;
	}
	
	public String getBizSrv(String msgId) {
	 return this.bizSrvMap.get(msgId);	
	}
}
