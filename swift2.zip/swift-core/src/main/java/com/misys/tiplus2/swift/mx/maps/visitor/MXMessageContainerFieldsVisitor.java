package com.misys.tiplus2.swift.mx.maps.visitor;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.visitor.SWIFTMessageMapsVisitor;
import com.misys.tiplus2.swift.mx.message.FieldData;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;

/**
 *
 * @author DaiD1
 *
 */
public abstract class MXMessageContainerFieldsVisitor extends SWIFTMessageMapsVisitor {

	private static final Logger LOG = LoggerFactory.getLogger(MXMessageContainerFieldsVisitor.class);

	protected Map<String, FieldData> currentDataFieldsByKey;
	protected Map<String, List<Map<String, Object>>> currentListFieldByKey;
	protected String currentDataBlockName;
	protected int currentDataBlockIndex;

	protected MXMessageContainer currentSwiftMxMessageContainer;
	protected MXMessageContainer currentHeaderContainer;

	@Override
	public Object visit(Embedded embedded, Object data) {

		Loggers.method().enter(LOG, embedded, data);

		Loggers.method().exit(LOG, data);
		return data;
	}

	abstract public void performVisit(String name, MXMessageContainer embeddedMessage);
}
