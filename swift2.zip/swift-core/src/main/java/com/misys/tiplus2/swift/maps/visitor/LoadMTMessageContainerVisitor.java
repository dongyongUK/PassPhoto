package com.misys.tiplus2.swift.maps.visitor;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.MessageMapsLoader;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.TagDataBlock;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.TagMarkerField;

/**
 * This is geared towards a visitor that will get data from another construct
 * and populate a SWIFTMessageContainer.
 *
 * @author DaiD1
 *
 */
public abstract class LoadMTMessageContainerVisitor<T> extends MTMessageContainerFieldsVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(LoadMTMessageContainerVisitor.class);

    protected T source;

    public abstract boolean isMarkerInSource(T source, String fieldName);

    /**
     * This is the main processing method, that given a foreign container, and
     * the message type known to that container, it will populate a
     * SWIFTMessageContainer and return it.
     *
     * @param source
     * @param type
     * @return
     */
    public MTMessageContainer load(T source, String type) {

        Loggers.method().enter(LOG, source, type);
        MTMessageContainer result = null;

        MessageMap messageMap = getMessageMapsLoader().findByName(type);
        this.source = source;

        if (messageMap != null) {

            currentSwiftMessageContainer = new MTMessageContainer(messageMap.getMessage());
            currentHeaderFieldsByKey = currentSwiftMessageContainer.getHeaderFields();
            currentDataFieldsByKey = currentSwiftMessageContainer.getDataFields();
            currentMarkerFieldsByKey = currentSwiftMessageContainer.getMarkerFields();

            messageMap.accept(this, result);
        }
        result = currentSwiftMessageContainer;
        Loggers.method().exit(LOG, result);
        return result;
    }

    abstract public String getFieldFromSource(T source, String fieldName);

    abstract public String getFieldFromSource(T source, int blockIndex, String fieldname);

    public abstract MTMessageContainer getEmbeddedFromSource(MessageMapsLoader messageMapsLoader, T source,
            String name);

    @Override
    public Object visit(HeaderField headerField, Object data) {
        Loggers.method().enter(LOG, headerField, data);

        TagDataField fieldValue = new TagDataField(headerField.getTag());
        if (headerField.getConstant() != null && headerField.getTag() != null) {
            fieldValue.setValue(headerField.getConstant());
            currentHeaderFieldsByKey.put(headerField.getTag(), fieldValue);
        } else {
            String value = getFieldFromSource(source, headerField.getName());
            if (value != null && !value.isEmpty()) {
                fieldValue = new TagDataField(headerField.getTag(),null, value);
                currentHeaderFieldsByKey.put(headerField.getTag(), fieldValue);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataBlock dataBlock, Object data) {
        Loggers.method().enter(LOG, dataBlock, data);

        Map<String, TagDataField> tempDataFields = currentDataFieldsByKey;
        currentDataBlockName = dataBlock.getName();

        int repeat = Integer.parseInt(dataBlock.getRepeat());
        String sn=this.getClass().getSimpleName();
        
        if ("LoadFromMeridianMessageVisitor".equals(sn) && ("799".equals(currentSwiftMessageContainer.getType())
        		||"499".equals(currentSwiftMessageContainer.getType()))) {
        	repeat = 2000;
        }
        
        for (int i = 0; i < repeat; i++) {
            currentDataBlockIndex = i;
            TagDataBlock tagDataBlock = new TagDataBlock(currentDataBlockName);
            currentDataFieldsByKey = tagDataBlock.getDataFields();
            if (currentSequenceMapName!=null) {
                tagDataBlock.setSequence(currentSequenceMapName);
            }
            
            for (DataTypeChoice choice : dataBlock.getDataTypeChoices()) {
                switch (choice.getChosen()) {
                case DATAFIELD:
                    choice.getDataField().accept(this, data);
                    break;
                case FIELDOPTIONS:
                    FieldOptions fieldOptions =choice.getFieldOptions();
                    currentFieldOptionsTag=fieldOptions.getTag();
                    fieldOptions.accept(this, data);
                    currentFieldOptionsTag=null;
                    break;
                default:
                    break;
                }
            }
            
            if (currentDataFieldsByKey != null && currentDataFieldsByKey.size() > 0) {
                currentSwiftMessageContainer.addDataBlock(currentDataBlockName, tagDataBlock);
            } else {
            	// stop loop if currentDataFieldsByKey is empty
            	break;
            }
            	
        }
        currentDataBlockName = null;
        currentDataBlockIndex = 0;
        currentDataFieldsByKey = tempDataFields;

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataField dataField, Object data) {
        Loggers.method().enter(LOG, dataField, data);

        TagDataField fieldValue = new TagDataField(dataField.getTag(),currentSequenceMapName, null);
        if (isEmbedded && ("21A".equals(dataField.getTag()) || "21P".equals(dataField.getTag()))) {
            // do nothing for 21A and 21P which already been processed in
            // MT798Score
            return data;
        }
        if (dataField.getConstant() != null && dataField.getTag() != null) {
            fieldValue.setValue(dataField.getConstant());
            currentDataFieldsByKey.put(dataField.getName(), fieldValue);
        } else {
            String value = null;
            if (currentDataBlockName == null) {
                value = getFieldFromSource(source, dataField.getName());
            } else {
                value = getFieldFromSource(source, currentDataBlockIndex, dataField.getName());
                // workaround for TSDS-42345
                // following can be removed after Meridian fix the bug
                if (value!=null && value.startsWith(":"+dataField.getTag()+":")) {
                    value = value.substring(2+dataField.getTag().length());
                }
            }
            if (value != null && !value.isEmpty()) {
                fieldValue = new TagDataField(dataField.getTag(), currentSequenceMapName, value);
                String key = dataField.getTag();
                if (currentSequenceMapName!=null) {
                    key = key+"_"+currentSequenceMapName;
                }
                currentDataFieldsByKey.put(key, fieldValue);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(MarkerField markerField, Object data) {
        Loggers.method().enter(LOG, markerField, data);
        
        if (isMarkerInSource(source, markerField.getName())) {
            TagMarkerField fieldValue = new TagMarkerField(markerField.getTag());
            fieldValue.setSequence(currentSequenceMapName);
            currentMarkerFieldsByKey.put(markerField.getTag(), fieldValue);
        }

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public void performVisit(String name, MTMessageContainer embeddedMessage) {

        Loggers.method().enter(LOG, name, embeddedMessage);

        MTMessageContainer embMsg = getEmbeddedFromSource(getMessageMapsLoader(), source, name);
        if (embMsg != null) {
            String type = embMsg.getType();
            embMsg.setHeaderFields(currentHeaderFieldsByKey);
            embMsg.setMessageType(type);
            currentSwiftMessageContainer.addEmbeddedMessage(name, embMsg);
        }
        Loggers.method().exit(LOG);
    }

}
