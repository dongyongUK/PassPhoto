package com.misys.tiplus2.swift.mx.message.mapping.rule;

import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * MT to MX customer party translation rules
 * 
 * @author DaiD1
 *
 */
public class MT2MXCustomerPartyTranslation {

    public static void mt2mxPartyAccount(RuleResult ruleResult, String line) {

        String tgtValue;
        String key;
        String tag;

        if (ruleResult != null && ruleResult.getMapField() != null) {
            String path = ruleResult.getMapField().getPath();
            String subTag = ruleResult.getMapField().getTag();
            if (line.startsWith("//CH")) {
                tag = subTag+".Id.Othr.SchmeNm.Cd";
                key = path + "." + tag;
                tgtValue = "CUID";
                ruleResult.addToMapValue(key, tgtValue);
                
                tag = subTag+".Id.Othr.id";
                key = path + "." + tag;
                tgtValue = line.substring(4);
                ruleResult.addToMapValue(key, tgtValue);

            } else if (line.startsWith("/")) {
                tgtValue = line.substring(1);
                tag = subTag+".Id.IBAN";
                // for TI, account map to IBAN
                key = path + "." + tag;
                ruleResult.addToMapValue(key, tgtValue);
            }
        }
    }

}
