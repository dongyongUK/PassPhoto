package com.misys.tiplus2.swift.maps.visitor;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.Embedded;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.TagMarkerField;

/**
 *
 * @author DaiD1
 *
 */
public abstract class MTMessageContainerFieldsVisitor extends SWIFTMessageMapsVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(MTMessageContainerFieldsVisitor.class);

    protected Map<String, TagDataField> currentHeaderFieldsByKey;
    protected Map<String, TagDataField> currentDataFieldsByKey;
    protected Map<String, TagMarkerField> currentMarkerFieldsByKey;
    protected String currentDataBlockName;
    protected int currentDataBlockIndex;

    protected MTMessageContainer currentSwiftMessageContainer;

    @Override
    public Object visit(Embedded embedded, Object data) {

        Loggers.method().enter(LOG, embedded, data);

        MTMessageContainer localSwiftMessage = currentSwiftMessageContainer;
        Map<String, TagDataField> localCurrentHeaderFieldsByKey = currentHeaderFieldsByKey;
        Map<String, TagDataField> localCurrentDataFieldsByKey = currentDataFieldsByKey;

        MTMessageContainer embeddedMessage = currentSwiftMessageContainer.findEmbeddedMessage(embedded.getName());

        if (embeddedMessage != null) {
            currentSwiftMessageContainer = null;
            currentDataFieldsByKey = null;
            currentMarkerFieldsByKey = null;
        }

        performVisit(embedded.getName(), embeddedMessage);

        if (embeddedMessage != null) {
            currentSwiftMessageContainer = localSwiftMessage;
            currentHeaderFieldsByKey = localCurrentHeaderFieldsByKey;
            currentDataFieldsByKey = localCurrentDataFieldsByKey;
            currentDataFieldsByKey = localCurrentDataFieldsByKey;
        }

        Loggers.method().exit(LOG, data);
        return data;
    }
    
    abstract public void performVisit(String name, MTMessageContainer embeddedMessage);
}
