package com.misys.tiplus2.swift.message.validation.rule.visitor;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Statement;
import com.misys.tiplus2.catalog.swift.message.rule.v1.groups.ItemTypeChoice;
import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.NoopMessageRuleVisitor;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.validation.error.interpretation.SwiftValidationResources;
import com.misys.tiplus2.swift.message.validation.rule.MessageRulesLoader;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;
import com.misys.tiplus2.swift.mx.message.MXMessageFieldHelper;

/**
 * TSDS-47627
 * 
 * @author DaiD1
 *
 */
public abstract class MXRuleValidateVisitor extends NoopMessageRuleVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(MXRuleValidateVisitor.class);

    protected MessageRulesLoader messageRulesLoader;
    protected SwiftValidationResources errorCodeResources;

    protected MXMessageContainer messageContainer;
    
    private static final String OPERATOR_AND = "AND";
    private static final String OPERATOR_OR = "OR";
    private static final String OPERATOR_XOR = "XOR";
    private static final String OPERATOR_NOT = "NOT";
    private static final String OPERATOR_EQ = "=";
    private static final String OPERATOR_BT = ">";
    private static final String OPERATOR_LT = "<";

    public void initialise(MessageRulesLoader loader) {
        Loggers.method().enter(LOG, loader);

        this.messageRulesLoader = loader;

        Loggers.method().exit(LOG);
    }

    public void initialise(MessageRulesLoader loader, SwiftValidationResources errorCodeResources) {
        Loggers.method().enter(LOG, loader);

        this.messageRulesLoader = loader;
        this.errorCodeResources = errorCodeResources;

        Loggers.method().exit(LOG);
    }

    public void setMessageRulesLoader(MessageRulesLoader messageRulesLoader) {
        this.messageRulesLoader = messageRulesLoader;
    }

    public MessageRulesLoader getMessageRulesLoader() {
        return messageRulesLoader;
    }

    public SwiftValidationResources getErrorCodeResources() {
        return errorCodeResources;
    }

    @Override
    public Object visit(Construct construct, Object data) {

        Loggers.method().enter(LOG, construct);

        RuleResult rResult = null;
        if (data != null && data instanceof RuleResult) {
            rResult = (RuleResult) data;
        }

        for (ItemTypeChoice itemType : construct.getItemTypeChoices()) {
            switch (itemType.getChosen()) {
            case STATEMENT:
                itemType.getStatement().accept(this, data);
                rResult = (RuleResult) data;
                break;
            case CONSTRUCT:
                Construct subConstruct = itemType.getConstruct();
                if (rResult != null && rResult.getLogicalValue() && "then".equalsIgnoreCase(subConstruct.getType())) {
                    visit(subConstruct, data);
                }
                if (rResult != null && !rResult.getLogicalValue() && "else".equalsIgnoreCase(subConstruct.getType())) {
                    visit(subConstruct, data);
                }
                break;
            case PROCEDURE:
                Procedure procedure = itemType.getProcedure();
                String pType = procedure.getType();

                if ("then".equalsIgnoreCase(pType)) {
                    if (rResult != null && rResult.getLogicalValue()) {
                        visit(procedure, data);
                    }
                } else if ("else".equalsIgnoreCase(pType)) {
                    if (rResult != null && !rResult.getLogicalValue()) {
                        visit(procedure, data);
                    }
                } else if (pType == null && !"error".equalsIgnoreCase(procedure.getTerminate())) {
                    visit(procedure, data);
                }
                break;
            default:
                break;
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    /**
     * data as a return of visit. data should be a object of RuleResult and
     * RuleResult.getLogicalValue should be true or false
     */
    public Object visit(Statement statement, Object data) {

        Loggers.method().enter(LOG, statement);

        RuleResult ruleResult = null;

        if (statement != null && !"continue".equals(statement.getType())) {
            String operator = statement.getOperator();
            List<Component> components = statement.getComponents();
            List<Procedure> procedures = statement.getProcedures();

            if (data != null) {
                ruleResult = (RuleResult) data;
            } else {
                ruleResult = new RuleResult();
            }

            if (operator == null && !components.isEmpty()) {
                // this case only have one component
                refresh((RuleResult) data);
                visit(components.get(0), data);
            } else if (OPERATOR_AND.equalsIgnoreCase(operator) && !components.isEmpty()) {
                for (Component component : components) {
                    refresh((RuleResult) data);
                    visit(component, data);
                    RuleResult result = (RuleResult) data;
                    if (!result.getLogicalValue()) {
                        break;
                    }
                }
            } else if (OPERATOR_OR.equalsIgnoreCase(operator) && !components.isEmpty()) {
                for (Component component : components) {
                    refresh((RuleResult) data);
                    visit(component, data);
                    RuleResult rr = (RuleResult) data;
                    if (rr.getLogicalValue()) {
                        break;
                    }
                }
            } else if (OPERATOR_XOR.equalsIgnoreCase(operator) && !components.isEmpty()) {
                // This case has 2 components
                boolean firstResult = false;
                boolean secondResult = false;
                refresh((RuleResult) data);
                visit(components.get(0), data);
                if (ruleResult.getLogicalValue()) {
                    firstResult = true;
                }

                refresh((RuleResult) data);
                visit(components.get(1), data);
                if (ruleResult.getLogicalValue()) {
                    secondResult = true;
                }

                if ((firstResult && !secondResult) || (!firstResult && secondResult)) {
                    ruleResult.setLogicalValue(true);
                } else {
                    ruleResult.setLogicalValue(false);
                }

            } else if (OPERATOR_NOT.equalsIgnoreCase(operator) && !components.isEmpty()) {
                // this case has only one component
                refresh((RuleResult) data);
                visit(components.get(0), data);

                if (ruleResult.getLogicalValue()) {
                    ruleResult.setLogicalValue(false);
                } else {
                    ruleResult.setLogicalValue(true);
                }
            } else if (OPERATOR_EQ.equals(operator) && !components.isEmpty()) {
                // This case has 2 components
                if (components.size()==2) {
                    visit(components.get(0), data);
                    RuleResult left = (RuleResult) data;
                    String leftValue = left.getTextValue();
                    Double leftNumValue = left.getNumericalValue();
                    if (left.getTiField()!=null && left.getTiField().getTag()!=null) {
                        if ("Amount.Currency".equals(left.getTiField().getTag())) {
                            leftValue = left.getSubValue();
                        }
                    }
                    visit(components.get(1), data);
                    RuleResult right = (RuleResult) data;
                    String rightValue = right.getTextValue();
                    Double rightNumValue = right.getNumericalValue();
                    
                    if (right.getTiField()!=null && right.getTiField().getTag()!=null) {
                        if ("Amount.Currency".equals(right.getTiField().getTag())) {
                            rightValue = right.getSubValue();
                        }
                    }
                    if (leftValue!=null && rightValue!=null && !leftValue.equals(rightValue)) {
                        ruleResult.setLogicalValue(false);
                    } else if (leftNumValue!=null && rightNumValue!=null && !leftNumValue.equals(rightNumValue)) {
                        ruleResult.setLogicalValue(false);
                    } else {
                        ruleResult.setLogicalValue(true); 
                    }
                } else if (components.size()==1) {
                	// in the case of fieldName is array and operator is =, all the values in array equals 
                    Component comp1 = components.get(0);
                    String fieldName = comp1.getField();
                    if (MXMessageFieldHelper.hasArray(fieldName) && !fieldName.endsWith(".")) {
                    	 String key = MXMessageFieldHelper.getArrayKey1(fieldName);
                         
                         Map<String, List<Map<String, Object>>> mapV = messageContainer.getListFieldByKey();
                         List<Map<String, Object>> itemList = mapV.get(key);
                         if (itemList!=null && !itemList.isEmpty()) { 
                        	  if(MappingRuleHelper.listContainsPath(fieldName, itemList)){
                        		  String preVal=null;
                        		  boolean equal = true;
                        		  int count = 0;
                        		  for (Map<String, Object> item:itemList) {
                                      for (Entry<String, Object> entry:item.entrySet()) {
                                         if (entry.getValue() instanceof String) {
                                                 String  entryValue = (String) entry.getValue();
                                                 if (preVal!=null && !preVal.equals(entryValue)) {
                                                	 equal=false;
                                                	 break;
                                                 } else {
                                                	 preVal= entryValue;
                                                 }
                                         } 
                                      }
                                      if (!equal) {
                                    	  ruleResult.setLogicalValue(false);
                                       	  break;
                                      }
                                      count++;
                                  }
                        		  if (equal && count>1) {
                        			  ruleResult.setLogicalValue(true); 
                        		  }else if (equal && count == 1) {
                        			  ruleResult.setLogicalValue(false);
                        		  }
                        	  }
                         }
                    }
                } else {
                    ruleResult.setLogicalValue(false);
                }
            } else if (OPERATOR_BT.equals(operator) && !components.isEmpty()) {
                // TODO
            } else if (OPERATOR_LT.equals(operator) && !components.isEmpty()) {
                // TODO
            } else if (operator == null && components.isEmpty() && !procedures.isEmpty()) {
                for (Procedure procedure : procedures) {
                    visit(procedure, data);
                }
            }
        } else if ("continue".equals(statement.getType())) {
            if (data != null) {
                ruleResult = (RuleResult) data;
            } else {
                ruleResult = new RuleResult();
            }
            ruleResult.setLogicalValue(true);
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    protected void refresh(RuleResult rr) {

        if (rr != null) {
            rr.setLogicalValue(false);
            rr.setTextValue(null);
            rr.setNumericalValue(null);
        }
    }

    protected void predicateComponent(RuleResult ruleResult, String predicate) {

        Predicate<RuleResult> pred = messageRulesLoader.getPredicate(predicate);
        if (pred.test(ruleResult)) {
            ruleResult.setLogicalValue(true);
        }
    }
    
}
