package com.misys.tiplus2.swift.message.validation.rule.visitor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Component;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Construct;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Procedure;
import com.misys.tiplus2.catalog.swift.message.rule.v1.elements.Statement;
import com.misys.tiplus2.catalog.swift.message.rule.v1.groups.ItemTypeChoice;
import com.misys.tiplus2.catalog.swift.message.rule.v1.visitor.NoopMessageRuleVisitor;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.FieldError;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.error.interpretation.DescriptionPhrases;
import com.misys.tiplus2.swift.message.validation.error.interpretation.InterpretationEngine;
import com.misys.tiplus2.swift.message.validation.rule.MessageRulesLoader;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * TSDS-40908
 * 
 * @author DaiD1
 *
 */
public class MessageRuleValidateVisitor extends NoopMessageRuleVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(MessageRuleValidateVisitor.class);

    protected MessageRulesLoader messageRulesLoader;
    protected InterpretationEngine interpreter;
    protected MTMessageContainer messageContainer;
    
    protected String currentMessageType;
    protected TagDataField currentField;
    private boolean fieldRequired;
    private boolean sequenceRequired;

    private static final String OPERATOR_AND = "AND";
    private static final String OPERATOR_OR = "OR";
    private static final String OPERATOR_XOR = "XOR";
    private static final String OPERATOR_NOT = "NOT";
    private static final String OPERATOR_EQ = "=";
    private static final String OPERATOR_BT = ">";
    private static final String OPERATOR_LT = "<";

    public void initialise(MessageRulesLoader loader) {
        Loggers.method().enter(LOG, loader);

        this.messageRulesLoader = loader;

        Loggers.method().exit(LOG);
    }
    
    public void initialise(MessageRulesLoader loader, InterpretationEngine interpreter) {
        Loggers.method().enter(LOG, loader);

        this.messageRulesLoader = loader;
        this.interpreter = interpreter;

        Loggers.method().exit(LOG);
    }

    public void process(Construct construct) {

        Loggers.method().enter(LOG, construct);

        Object obj =  construct.accept(this, new RuleResult());

        RuleResult result = (RuleResult) obj;        
        Loggers.method().exit(LOG);
    }

    public void setMessageRulesLoader(MessageRulesLoader messageRulesLoader) {
        this.messageRulesLoader = messageRulesLoader;
    }

    public MessageRulesLoader getMessageRulesLoader() {
        return messageRulesLoader;
    }

    public InterpretationEngine getInterpreter() {
        return interpreter;
    }

    @Override
    public Object visit(Construct construct, Object data) {

        Loggers.method().enter(LOG, construct);

        RuleResult rResult = null;

        for (ItemTypeChoice itemType : construct.getItemTypeChoices()) {
            switch (itemType.getChosen()) {
            case STATEMENT:
                itemType.getStatement().accept(this, data);
                rResult = (RuleResult) data;
                break;
            case CONSTRUCT:
                Construct subConstruct = itemType.getConstruct();
                if (rResult != null && rResult.getLogicalValue() && "then".equalsIgnoreCase(subConstruct.getType())) {
                    visit(subConstruct, data);
                }
                if (rResult != null && !rResult.getLogicalValue() && "else".equalsIgnoreCase(subConstruct.getType())) {
                    visit(subConstruct, data);
                }
                break;
            case PROCEDURE:
                Procedure procedure = itemType.getProcedure();
                if (rResult != null && rResult.getLogicalValue() && "then".equalsIgnoreCase(procedure.getType())) {
                    visit(procedure, data);
                }
                if (rResult != null && !rResult.getLogicalValue() && "else".equalsIgnoreCase(procedure.getType())) {
                    visit(procedure, data);
                }
                
                // for mt-mx mapping rules 
                if (rResult != null && rResult.getTextValue()!=null && "then".equalsIgnoreCase(procedure.getType())) {
                    visit(procedure, data);
                }
                break;
            default:
                break;
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    /**
     * data as a return of visit. data should be a object of RuleResult and
     * RuleResult.getLogicalValue should be true or false
     */
    public Object visit(Statement statement, Object data) {

        Loggers.method().enter(LOG, statement);
        if (statement != null) {
            String operator = statement.getOperator();
            List<Component> components = statement.getComponents();
            RuleResult ruleResult = null;
            if (data != null) {
                ruleResult = (RuleResult) data;
            } else {
                ruleResult = new RuleResult();
            }

            if (operator == null && components != null) {
                // this case only have one component
                refresh((RuleResult) data);
                visit(components.get(0), data);
            } else if (OPERATOR_AND.equalsIgnoreCase(operator) && components != null) {
                for (Component component : components) {
                    refresh((RuleResult) data);
                    visit(component, data);
                    RuleResult result = (RuleResult) data;
                    if (!result.getLogicalValue()) {
                        break;
                    }
                }
            } else if (OPERATOR_OR.equalsIgnoreCase(operator) && components != null) {
                for (Component component : components) {
                    refresh((RuleResult) data);
                    visit(component, data);
                    RuleResult rr = (RuleResult) data;
                    if (rr.getLogicalValue()) {
                        break;
                    }
                }
            } else if (OPERATOR_XOR.equalsIgnoreCase(operator) && components != null) {
                // This case has 2 components
                boolean firstResult = false;
                boolean secondResult = false;
                refresh((RuleResult) data);
                visit(components.get(0), data);
                if (ruleResult.getLogicalValue()) {
                    firstResult = true;
                }

                refresh((RuleResult) data);
                visit(components.get(1), data);
                if (ruleResult.getLogicalValue()) {
                    secondResult = true;
                }

                if ((firstResult && !secondResult) || (!firstResult && secondResult)) {
                    ruleResult.setLogicalValue(true);
                } else {
                    ruleResult.setLogicalValue(false);
                }

            } else if (OPERATOR_NOT.equalsIgnoreCase(operator) && components != null) {
                // this case has only one component
                refresh((RuleResult) data);
                visit(components.get(0), data);

                if (ruleResult.getLogicalValue()) {
                    ruleResult.setLogicalValue(false);
                } else {
                    ruleResult.setLogicalValue(true);
                }
            } else if (OPERATOR_EQ.equals(operator) && components != null) {
                // This case has 2 components
                refresh((RuleResult) data);
                visit(components.get(0), data);
                if (ruleResult.getLogicalValue()) {

                    TagDataField f1 = getDataFieldFromComponent(components.get(0));
                    refresh((RuleResult) data);
                    visit(components.get(1), data);
                    if (ruleResult.getLogicalValue()) {
                        TagDataField f2 = getDataFieldFromComponent(components.get(1));
                        if (f1.getValue().equals(f2.getValue())) {
                            ruleResult.setLogicalValue(true);
                        } else {
                            ruleResult.setLogicalValue(false);
                        }
                    }
                }
            } else if (OPERATOR_BT.equals(operator) && components != null) {
                // TODO
            } else if (OPERATOR_LT.equals(operator) && components != null) {
                // TODO
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(Procedure procedure, Object data) {

        Loggers.method().enter(LOG, procedure);

        if (procedure != null) {
            String terminate = procedure.getTerminate();
            String value = procedure.getValue();
            String tags = procedure.getTag();
            if ("error".equals(terminate)) {
                FieldError fieldError = new FieldError(null, null);
                fieldError.setCode(value);
                if (tags != null && !tags.isEmpty()) {
                    String[] tagsa = tags.split("\\|");
                    TagDataField tagField = null;
                    for (String tag : tagsa) {
                        tagField = messageContainer.getDataFieldByTag(tag);
                        if (tagField != null) {
                            break;
                        }
                    }

                    if (tagField != null) {
                        tagField.setErrorCode(value);
                        if (interpreter.getErrorCodeResources() != null) {
                            String errDesc = interpreter.getErrorCodeResources().getErrorDescriptionByCode(value);
                            if (errDesc != null) {
                                tagField.setErrorDetails(errDesc);
                            }
                        }
                    }
                } else {
                    if (interpreter.getErrorCodeResources() != null) {
                        String errDesc = interpreter.getErrorCodeResources().getErrorDescriptionByCode(value);
                        if (errDesc != null) {
                            fieldError.setErrorDetails(errDesc);
                        }
                    }
                    messageContainer.addNonFieldError(fieldError);
                }
            } else if ("exit".equals(terminate)) {
                
                RuleResult ruleResult = (RuleResult) data;
                String v1= ruleResult.getTextValue();
                if (v1!=null) {
                	v1 = value+" value=\""+value+"\"";
                }
                ruleResult.setTextValue(v1);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(Component component, Object data) {

        Loggers.method().enter(LOG, component);
        RuleResult ruleResult = (RuleResult) data;
        if (data == null) {
            ruleResult = new RuleResult();
        }

        if (component != null) {
            String messages = component.getMessage();
            String fields = component.getField();
            String subValueIndex = component.getSubValueIndex();
            String value = component.getValue();
            String sequence = component.getSequence();
            String predicate = component.getPredicate();
            String arguments = component.getArguments();

            if (messages != null && fields == null) {
                String[] msgs = messages.split("\\|");
                for (String msg : msgs) {
                    if (messageContainer.getType().equals(msg)) {
                        ruleResult.setLogicalValue(true);
                        break;
                    }
                }
            } else if (fields != null) {
                TagDataField field = getDataFieldFromComponent(component);
                if (field != null && subValueIndex == null && value == null) {
                    ruleResult.setLogicalValue(true);
                } else if (field != null && subValueIndex != null) {
                    String subValue = null;
                    if (subValueIndex.contains("-")) {
                        String[] inter = subValueIndex.split("-");
                        if (inter.length == 2) {
                            int begin = Integer.parseInt(inter[0]);
                            int end = Integer.parseInt(inter[1]);
                            if (field.getValue() != null && field.getValue().length() > begin - 1) {
                                subValue = field.getValue().substring(begin - 1, end - 1);
                            }
                        }
                    } else {
                        int begin = Integer.parseInt(subValueIndex);
                        subValue = field.getValue().substring(begin);
                    }

                    if (value == null) {
                        ruleResult.setTextValue(subValue);
                    } else {
                        if (value.contains("|")) {
                            String[] values = value.split("\\|");
                            for (String v : values) {
                                if (v.equals(subValue)) {
                                    ruleResult.setLogicalValue(true);
                                    break;
                                }
                            }
                        } else if (value.equals(subValue)) {
                            ruleResult.setLogicalValue(true);
                        }
                    }
                } else if (field != null && value != null && subValueIndex == null) {
                    if (!value.contains("|")) {
                        if (value.equals(field.getValue())) {
                            ruleResult.setLogicalValue(true);
                        }
                    } else {
                        String[] vls = value.split("\\|");
                        for (String v : vls) {
                            if (v.equals(field.getValue())) {
                                ruleResult.setLogicalValue(true);
                                break;
                            }
                        }
                    }
                } else if (field != null && predicate != null) {
                    // case of Predicate
                    predicateComponent(ruleResult, predicate, arguments, field);
                }
                
            } else if (sequence != null && fields == null && value == null) {
                if (messageContainer.hasSequence(sequence)) {
                    ruleResult.setLogicalValue(true);
                }
            } 
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    public MTMessageContainer getMessageContainer() {
        return messageContainer;
    }

    public void setMessageContainer(MTMessageContainer messageContainer) {
        this.messageContainer = messageContainer;
    }

    private void refresh(RuleResult rr) {

        if (rr != null) {
            rr.setLogicalValue(false);
            rr.setTextValue(null);
            rr.setNumericalValue(null);
        }
    }

    protected TagDataField getDataFieldFromComponent(Component component) {
        TagDataField result = null;
        String message = component.getMessage();
        String tags = component.getField();
        if (message == null && tags != null) {
            result = getDataFieldFromMessage(tags, messageContainer, component.getSequence());
        }
        return result;
    }

    protected TagDataField getDataFieldFromMessage(String tags, MTMessageContainer message, String sequence) {

        TagDataField result = null;
        String[] flds = tags.split("\\|");
        for (String tag : flds) {
            result = message.getDataField(tag, sequence);
            if (result != null) {
                if (result.getValue() != null
                        || DescriptionPhrases.swift_MANDATORY_FIELD_MISSING.equals(result.getErrorDetails())) {
                    break;
                }
            }
        }
        return result;
    }

    public void validate(MTMessageContainer messageContainer) {

        Loggers.method().enter(LOG, messageContainer.getType());

        String msgType = messageContainer.getType();
        List<String> listRules = messageRulesLoader.getRuleList(msgType);
        
        if (listRules != null) {
            setMessageContainer(messageContainer);
            
            
            for (String ruleId : listRules) {
                Construct construct = messageRulesLoader.findMessageRule(msgType, ruleId);
                if (construct != null) {
                    process(construct);
                }
            }
        }
        Loggers.method().exit(LOG);
    }
    
    private void predicateComponent(RuleResult ruleResult, String predicate, String arguments, TagDataField field) {

        
        //TODO
        ;
    }
}
