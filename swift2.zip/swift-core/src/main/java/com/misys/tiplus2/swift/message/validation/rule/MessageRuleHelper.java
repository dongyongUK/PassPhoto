package com.misys.tiplus2.swift.message.validation.rule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.contract.AssertArgument;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.MTMessageConstant;

/**
 * 
 * @author DaiD1
 *
 */
public class MessageRuleHelper {

    private static final Logger LOG = LoggerFactory.getLogger(MessageRuleHelper.class);

    public static boolean isAField(String value) {

        Loggers.method().enter(LOG,value);
        
        boolean result = false;

        if (value != null && value.length() > 1) {

            if (Character.isDigit(value.charAt(0)) && Character.isDigit(value.charAt(1))) {

                if (value.length() == 2) {
                    result = true;
                } else if (Character.isLetter(value.charAt(2))) {
                    result = true;
                }
            }
        }
        Loggers.method().exit(LOG,result);
        return result;
    }
    
    public static boolean endWithField(String value) {

        Loggers.method().enter(LOG,value);
        boolean result = false;

        if (value != null && value.length() > 1 && value.contains(".")) {
            int lastIndex = value.lastIndexOf(".");
            String lastValue = value.substring(lastIndex + 1);
            result = isAField(lastValue);
        }
        Loggers.method().exit(LOG,result);
        return result;
    }
    
    public static String[]  splitLine(String text) {
        Loggers.method().enter(LOG, text);
        
        text = normalize(text);
        String[] lines = text.split(MTMessageConstant.WINDOWS_CRLF);
        return lines;
    }
    
    public static String normalize(String message) {

        Loggers.method().enter(LOG, message);
        AssertArgument.notBlank(message, "message");
        String result = message;

        if (result.contains("\r\n")) {
            result = result.replace("\r\n", "\r");
        }

        if (result.contains("\n")) {
            result = result.replace("\n", "\r");
        }

        result = result.replace("\r", "\r\n");

        Loggers.method().exit(LOG, result);
        return result;
    }
}
