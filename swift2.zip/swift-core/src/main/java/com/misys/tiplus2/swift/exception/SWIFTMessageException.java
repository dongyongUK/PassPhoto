package com.misys.tiplus2.swift.exception;

import com.misys.tiplus2.foundations.lang.CommonRuntimeException;

/**
 * SWIFTMessageException
 *
 * @author DaiD1
 *
 */
public class SWIFTMessageException extends CommonRuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public SWIFTMessageException() {
        super();
    }

    public SWIFTMessageException(String message) {
        super(message);
    }

    public SWIFTMessageException(Throwable cause) {
        super(cause);
    }

    public SWIFTMessageException(String message, Throwable cause) {
        super(message, cause);
    }

    public SWIFTMessageException(String code, String message) {
        super(code, message);
    }

    public SWIFTMessageException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }
}
