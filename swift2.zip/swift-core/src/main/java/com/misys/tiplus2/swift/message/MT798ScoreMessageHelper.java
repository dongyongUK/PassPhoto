package com.misys.tiplus2.swift.message;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;

public class MT798ScoreMessageHelper {

    private List<String> detailsMessages;
    private List<String> indexMessages;

    private static final Logger LOG = LoggerFactory.getLogger(MT798ScoreMessageHelper.class);

    public void setDetailsMessages(List<String> detailsMessages) {
        this.detailsMessages = detailsMessages;
    }

    public void setIndexMessages(List<String> indexMessages) {
        this.indexMessages = indexMessages;
    }

    private boolean inEmbeddedMessages(String type) {

        return isIndexMessage(type) || isDetailsMessage(type);

    }

    public boolean isMT798ScoreMessage(MTMessageContainer message) throws Exception {

        Loggers.method().enter(LOG, message.getType());
        
        boolean result = false;

        if (message != null && message.getType().startsWith("798")) {
            TagDataField field12 = message.getDataFieldByKey("12");
            TagDataField field77e = message.getDataFieldByKey("77E");
            if (field12 != null && field77e != null) {
                String subType = field12.getValue();
                String field77EValue = field77e.getValue();
                if (subType != null && !subType.isEmpty() && field77EValue != null && !field77EValue.isEmpty()) {
                    if (MT798ScoreFINMessageHelper.getReferenceTag(field77EValue)!=null && inEmbeddedMessages(subType)) {
                        String sequence = MT798ScoreFINMessageHelper.getSequenceFrom77E(field77EValue);
                        result = FINMessageHelper.isnForwardSlashmFormat(sequence);
                    }
                }
            }
        }
        Loggers.method().exit(LOG,result);
        return result;
    }

    public boolean isMT798ScoreMessageOutgoing(MTMessageContainer message) throws Exception {

        boolean result = false;
        Loggers.method().enter(LOG, message.getType());
        if (message != null && message.getType().startsWith("798")) {
            TagDataField field12 = message.getDataFieldByKey("12");
            
            if (field12 != null) {
                String subType = field12.getValue();

                if (subType != null && !subType.isEmpty()) {
                	TagDataField field77e = message.getDataFieldByKey("77E");
                	if (field77e!=null) {
                		 String field77EValue = field77e.getValue();
                		 if (MT798ScoreFINMessageHelper.getReferenceTag(field77EValue)!=null) {
                			 result = true;
                		 }
                	}
                }
            }
        }
        Loggers.method().exit(LOG,result);
        return result;
    }

    public boolean isIndexMessage(String msgType) {
        boolean result = false;

        Loggers.method().enter(LOG, msgType);
        if (msgType!=null && indexMessages != null && indexMessages.size() > 0) {
            for (String value:indexMessages){
                String[] items = value.split("-");
                if(msgType.equals(items[0])){
                    result = true;
                    break;
                }
            }
        }
        Loggers.method().exit(LOG,result);
        return result;
    }

    public boolean isDetailsMessage(String msgType) {
        boolean result = false;

        Loggers.method().enter(LOG, msgType);
        if (detailsMessages != null && detailsMessages.size() > 0) {

            result = detailsMessages.contains(msgType);
        }

        Loggers.method().exit(LOG,result);
        return result;
    }
    
    public String getReferenceForDetailsMessage(String indexMsgType){
        
        String result = null;
        Loggers.method().enter(LOG, indexMsgType);
        if (indexMsgType!=null && indexMessages != null && indexMessages.size() > 0){
            for (String value:indexMessages){
                String[] items = value.split("-");
                if(indexMsgType.equals(items[0])){
                    if (items.length>1){
                        result = items[1];
                    }
                    break;
                }
            }
        }
        Loggers.method().exit(LOG,result);
        return result;
    }
}