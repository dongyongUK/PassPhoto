package com.misys.tiplus2.swift.adaptor.visitor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FieldEntryCollection implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -6914608341125253084L;

    private final List<FieldEntry> fieldEntries = new ArrayList<FieldEntry>();

    private final Map<String, FieldEntry> fieldEntriesByName = new HashMap<String, FieldEntry>();

    public FieldEntry put(FieldEntry item) {
        FieldEntry result = fieldEntriesByName.get(item.getName());
        if (result != null) {
            fieldEntries.remove(result);
        }
        fieldEntriesByName.put(item.getName(), item);
        fieldEntries.add(item);
        return result;
    }

    public void addFieldEntry(FieldEntry fieldEntry) {
        fieldEntries.add(fieldEntry);
    }

    public boolean setFieldEntryValue(String name, String value, boolean create) {
        boolean result = true;
        FieldEntry item = fieldEntriesByName.get(name);
        if (item != null) {
            item.setValue(value);
        } else if (create) {
            item = new FieldEntry(name);
            item.setValue(value);
            put(item);
        } else {
            result = false;
        }
        return result;
    }

    public FieldEntry findByName(String name) {
        FieldEntry result = fieldEntriesByName.get(name);
        return result;
    }

    public List<FieldEntry> getList() {
        return Collections.unmodifiableList(fieldEntries);
    }

    public void clear() {
        fieldEntries.clear();
        fieldEntriesByName.clear();
    }

    public void resetValues() {
        for (FieldEntry item : fieldEntries) {
            item.setValue(null);
        }
    }

    public boolean hasEntries() {
        return fieldEntries.size() > 0;
    }

    public FieldEntryCollection copy() {
        FieldEntryCollection result = new FieldEntryCollection();
        for (FieldEntry item : fieldEntries) {
            result.setFieldEntryValue(item.getName(), item.getValue(), true);
        }
        return result;
    }

    public FieldEntryCollection copyHeader() {
        FieldEntryCollection result = new FieldEntryCollection();
        for (FieldEntry item : fieldEntries) {
            if (item.getName().startsWith("Swift_envelope.")) {
                result.setFieldEntryValue(item.getName(), item.getValue(), true);
            }
        }
        return result;
    }
}
