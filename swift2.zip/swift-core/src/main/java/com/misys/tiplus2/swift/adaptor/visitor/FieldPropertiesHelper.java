package com.misys.tiplus2.swift.adaptor.visitor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.contract.AssertArgument;
import com.misys.tiplus2.foundations.lang.logging.Loggers;

/**
 * SwiftPaneConvertor convert a swift pane into SwiftMessageData
 *
 * @author DaiD1
 *
 */
public class FieldPropertiesHelper {

    protected static final Logger LOG = LoggerFactory.getLogger(FieldPropertiesHelper.class);

    public static String convertRepeatedFieldName(String fieldName, int index) {

        AssertArgument.notNull(fieldName, "fieldName");
        Loggers.method().enter(LOG, fieldName);
        String result = null;
        if (fieldName.contains("[n]")) {
            result = fieldName.replace("[n]", Integer.toString(index + 1));
        } else if (fieldName.contains("[A]")) {
            char start = 65; // 'A'=65;
            result = fieldName.replace("[A]", Character.valueOf((char) (start + index)).toString());
        } else {
            result = fieldName;
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
}
