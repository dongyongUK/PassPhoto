package com.misys.tiplus2.swift.message;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author DaiD1
 *
 */
public class FieldError implements Serializable {

    private static final long serialVersionUID = 6606214782411453334L;

    private String tag;
    private String errorDetails;
    private String code;
    private String severity;

    public FieldError(String tag, String errorDetails) {

        this.tag = tag;
        this.errorDetails = errorDetails;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }
    
    /**
     * @since TSDS-52151
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
