package com.misys.tiplus2.swift.maps.visitor;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.MessageMapsLoader;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.TagDataBlock;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.TagMarkerField;

/**
 *
 * This visitor is to populate a target from a SWIFTMessageContainer.
 *
 * @author DaiD1
 *
 */

public abstract class UnloadMTMessageContainerVisitor<T> extends MTMessageContainerFieldsVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(UnloadMTMessageContainerVisitor.class);

    protected T target;

    public abstract void setMarkerInTarget(T target, String fieldName);

    /**
     * This is the main processing method, that given a foreign container, and a
     * SWIFTMessageContainer, it will populate the target.
     *
     * @param resolver
     * @param swiftMessage
     * @return
     */
    public T unload(SWIFTMessageTargetResolver resolver, MTMessageContainer swiftMessage) {

        Loggers.method().enter(LOG, swiftMessage);

        String msgType = swiftMessage.getType();
        MessageMap messageMap = getMessageMapsLoader().findByMessage(msgType);

        if (messageMap != null) {
            this.currentSwiftMessageContainer = swiftMessage;
            target = (T) resolver.createTarget(messageMap.getName());
            currentHeaderFieldsByKey = swiftMessage.getHeaderFields();
            currentDataFieldsByKey = swiftMessage.getDataFields();
            currentMarkerFieldsByKey = swiftMessage.getMarkerFields();
            messageMap.accept(this, target);
        }

        Loggers.method().exit(LOG);
        return target;
    }

    abstract public void setFieldInTarget(T target, String fieldName, String value);

    abstract public void setFieldInTarget(T target, int blockIndex, String fieldname, String value);

    @Override
    public Object visit(HeaderField headerField, Object data) {

        Loggers.method().enter(LOG, headerField, data);

        if (headerField.getConstant() != null && headerField.getName() != null) {
            setFieldInTarget(target, headerField.getName(), headerField.getConstant());
        } else {
            TagDataField dF = currentHeaderFieldsByKey.get(headerField.getTag());
            if (dF != null) {
                setFieldInTarget(target, headerField.getName(), dF.getValue());
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataBlock dataBlock, Object data) {

        Loggers.method().enter(LOG, dataBlock, data);

        Map<String, TagDataField> tempDataFields = currentDataFieldsByKey;
        currentDataBlockName = dataBlock.getName();
        List<TagDataBlock> listOfDataBlock = currentSwiftMessageContainer.getDataBlockList(currentDataBlockName);
        currentDataBlockIndex = 0;
        if (listOfDataBlock != null && listOfDataBlock.size() > 0) {
            for (TagDataBlock tdBlock : listOfDataBlock) {
                currentDataFieldsByKey = tdBlock.getDataFields();
               
                for (DataTypeChoice choice : dataBlock.getDataTypeChoices()) {
                    switch (choice.getChosen()) {
                    case DATAFIELD:
                        choice.getDataField().accept(this, data);
                        break;
                    case FIELDOPTIONS:
                        FieldOptions fieldOptions =choice.getFieldOptions();
                        currentFieldOptionsTag=fieldOptions.getTag();
                        fieldOptions.accept(this, data);
                        currentFieldOptionsTag=null;
                        break;
                    default:
                        break;
                    }
                }
                
                currentDataBlockIndex++;
            }
        }
        currentDataBlockName = null;
        currentDataBlockIndex = 0;
        currentDataFieldsByKey = tempDataFields;

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataField dataField, Object data) {
        Loggers.method().enter(LOG, dataField, data);

        if (dataField.getConstant() != null && dataField.getName() != null) {
            setFieldInTarget(target, dataField.getName(), dataField.getConstant());
        } else {
            String key = dataField.getTag();
            if (currentSequenceMapName!=null) {
                key = key+"_"+currentSequenceMapName;
            }
            TagDataField dF = currentDataFieldsByKey.get(key);

            if (dF != null) {
                if (currentDataBlockName != null) {
                    setFieldInTarget(target, currentDataBlockIndex, dataField.getName(), dF.getValue());
                } else {
                    setFieldInTarget(target, dataField.getName(), dF.getValue());
                }
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(MarkerField markerField, Object data) {

        Loggers.method().enter(LOG, markerField, data);

        TagMarkerField dF = currentMarkerFieldsByKey.get(markerField.getTag());
        if (dF != null) {
            setMarkerInTarget(target, markerField.getName());
        }

        Loggers.method().exit(LOG, data);
        return data;
    }
    
    @Override
    public void performVisit(String name, MTMessageContainer embeddedMessage) {

        Loggers.method().enter(LOG, name, embeddedMessage);

        if (embeddedMessage != null) {
            setEmbeddedInTarget(target, getMessageMapsLoader(), embeddedMessage, name);
        }
        Loggers.method().exit(LOG);
    }

    public abstract void setEmbeddedInTarget(T target, MessageMapsLoader messageMapsLoader, MTMessageContainer msg,
            String embeddedName);

}
