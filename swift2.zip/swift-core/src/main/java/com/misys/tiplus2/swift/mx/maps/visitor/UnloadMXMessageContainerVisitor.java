package com.misys.tiplus2.swift.mx.maps.visitor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MarkerField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.visitor.SWIFTMessageTargetResolver;
import com.misys.tiplus2.swift.message.validation.rule.visitor.MTMXMappingRuleValidateVisitor;
import com.misys.tiplus2.swift.mx.message.FieldData;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;
import com.misys.tiplus2.swift.mx.message.MXMessageFieldHelper;

/**
 * Populate date from MXMessageContainer to Enigma MX pane
 * 
 *
 * @author DaiD1
 *
 */
public abstract class UnloadMXMessageContainerVisitor<T> extends MXMessageContainerFieldsVisitor {

	private static final Logger LOG = LoggerFactory.getLogger(UnloadMXMessageContainerVisitor.class);

	protected T targetPane;
	protected Map<String, FieldData> currentHeaderFieldsByKey;
	protected MTMXMappingRuleValidateVisitor ruleVisitor;
	protected String msgId;
	protected MessageMap messageMap;

	/**
	 * This is the main processing method, it will populate the target with values
	 * from SWIFTMXMessageContainer
	 * 
	 *
	 * @param resolver
	 * @param SwiftMXMessage
	 * @return
	 */
	public T unload(SWIFTMessageTargetResolver resolver, MXMessageContainer swiftMessage) {

		Loggers.method().enter(LOG, swiftMessage);

		String msgType = swiftMessage.getMessageId();
		MessageMap messageMap = getMessageMapsLoader().findByMessage(msgType);

		if (messageMap != null) {
			this.currentSwiftMxMessageContainer = swiftMessage;
			targetPane = (T) resolver.createTarget(messageMap.getName());
			currentHeaderFieldsByKey = swiftMessage.getBusinessAppHeader().getFieldDataByKey();
			currentDataFieldsByKey = swiftMessage.getFieldDataByKey();
			currentListFieldByKey = swiftMessage.getListFieldByKey();
			messageMap.accept(this, targetPane);
		}
		Loggers.method().exit(LOG);
		return targetPane;
	}

	abstract public void setFieldInTarget(T target, String fieldName, String value);

	abstract public void setFieldInTarget(T target, int blockIndex, String fieldname, String value);

	abstract public void setFieldInTarget(T target, String fieldName, String value, int arrayIndx);

	abstract public void setFieldInTarget(T target, String fieldName, String value, int arrayIndx1, int arrayIndx2);

	abstract public void setFieldInTarget(T target, String fieldName, String value, int arrayIndx1, int arrayIndx2,
			int arrayIndx3);

	@Override
	public Object visit(HeaderField headerField, Object data) {

		Loggers.method().enter(LOG, headerField, data);

		if (headerField.getConstant() != null && headerField.getName() != null) {
			setFieldInTarget(targetPane, headerField.getName(), headerField.getConstant());
		} else {
			String path = headerField.getPath();
			String tag = headerField.getTag();
			path = MXMessageFieldHelper.removeSigns(path);
			tag = MXMessageFieldHelper.removeSigns(tag);
			FieldData dF = currentHeaderFieldsByKey.get(path + "." + tag);
			if (dF != null) {
				setFieldInTarget(targetPane, headerField.getName(), dF.getTagValue());
			}
		}
		Loggers.method().exit(LOG, data);
		return data;
	}

	@Override
	public Object visit(DataBlock dataBlock, Object data) {
		// Not implemented
		return data;
	}

	@Override
	public Object visit(DataField dataField, Object data) {
		Loggers.method().enter(LOG, dataField, data);

		if (dataField.getConstant() != null && dataField.getName() != null) {
			setFieldInTarget(targetPane, dataField.getName(), dataField.getConstant());
		} else {
			String tag = dataField.getTag();
			String path = dataField.getPath();
			boolean hasArray = false;
			String firstArrayKey = null;
			if (MXMessageFieldHelper.hasArray(path) || MXMessageFieldHelper.hasArray(tag)) {
				hasArray = true;
				firstArrayKey = MXMessageFieldHelper.getFirstArrayKey(path, tag, 0);
			}
			tag = MXMessageFieldHelper.removeChoiceSign(tag);
			tag = MXMessageFieldHelper.removeOptionSign(tag);
			path = MXMessageFieldHelper.removeChoiceSign(path);
			path = MXMessageFieldHelper.removeOptionSign(path);

			if (!hasArray) {
				FieldData fieldData = currentDataFieldsByKey.get(path + "." + tag);
				if (fieldData != null) {
					setFieldInTarget(targetPane, dataField.getName(), fieldData.getTagValue());
				}
			} else {
				// Array
				int numOfArray = MXMessageFieldHelper.countNumberOfArray(path, tag);
				List<Map<String, Object>> firstList = currentListFieldByKey.get(firstArrayKey);
				if (firstList != null && !firstList.isEmpty()) {
					if (tag != null && tag.equals("_Ccy")) {
						tag = "Ccy";
					}
					switch (numOfArray) {
					case 1:
						if (!tag.contains("[")) {
							path = MXMessageFieldHelper.removeArraySigns(path);
						}
						setValueFromList(dataField, tag, path, firstList);
						break;
					case 2:
						int indx2 = firstArrayKey.length() + 3;
						String secondArrayKey = MXMessageFieldHelper.getFirstArrayKey(path, tag, indx2);
						if (!tag.contains("[")) {
							List<Map<String, Object>> secondList = (List<Map<String, Object>>) new ArrayList();
							for (int i = 0; i < firstList.size(); i++) {
								Map<String, Object> item = (Map<String, Object>) firstList.get(i);
								List<Map<String, Object>> o = (List<Map<String, Object>>) item.get(secondArrayKey);
								if (o != null) {
									Map<String, Object> mV = new HashMap<String, Object>();
									mV.put(secondArrayKey, o);
									secondList.add(mV);
								}
							}
							setValueFromList2(dataField, tag, path, secondArrayKey, null, secondList);
						} else { // tag is array
							setValueFromList(dataField, tag, path, firstList);
						}
						break;
					case 3:
						indx2 = firstArrayKey.length() + 3;
						secondArrayKey = MXMessageFieldHelper.getFirstArrayKey(path, tag, indx2);
						indx2 = secondArrayKey.length() + 7;
						String thirdArrayKey = MXMessageFieldHelper.getFirstArrayKey(path, tag, indx2);
						if (!tag.contains("[")) {
							List<Map<String, Object>> secondList = (List<Map<String, Object>>) new ArrayList();
							for (int i = 0; i < firstList.size(); i++) {
								Map<String, Object> item = (Map<String, Object>) firstList.get(i);
								List<Map<String, Object>> list2 = (List<Map<String, Object>>) item.get(secondArrayKey);
								if (list2 != null) {
									Map<String, Object> mV = new HashMap<String, Object>();
									mV.put(secondArrayKey, list2);
									secondList.add(mV);
								}
							}
							setValueFromList2(dataField, tag, path, secondArrayKey, thirdArrayKey, secondList);
						} else {
							List<Map<String, Object>> thirdList = (List<Map<String, Object>>) new ArrayList();
							for (int i = 0; i < firstList.size(); i++) {
								Map<String, Object> item = (Map<String, Object>) firstList.get(i);
								List<Map<String, Object>> list2 = (List<Map<String, Object>>) item.get(secondArrayKey);
								List<Map<String, Object>> secondList = (List<Map<String, Object>>) new ArrayList();
								for (int j = 0; j < list2.size(); j++) {
									Map<String, Object> item2 = (Map<String, Object>) list2.get(j);
									List<Map<String, Object>> list3 = (List<Map<String, Object>>) item2
											.get(thirdArrayKey);
									if (list3 != null) {
										Map<String, Object> mV = new HashMap<String, Object>();
										mV.put(thirdArrayKey, list3);
										secondList.add(mV);
									}
								}

								if (!secondList.isEmpty()) {
									Map<String, Object> mV = new HashMap<String, Object>();
									mV.put(secondArrayKey, secondList);
									thirdList.add(mV);
								}
							}
							setValueFromList2(dataField, tag, path, secondArrayKey, thirdArrayKey, thirdList);
						}
						break;
					case 4:
					case 5:
						break;
					default:
						break;
					}
				}
			}
		}
		Loggers.method().exit(LOG, data);
		return data;
	}

	private void setValueFromList(DataField dataField, String tag, String path, List<Map<String, Object>> firstList) {
		path = MXMessageFieldHelper.removeArraySigns(path);
		String fieldKey = path + "." + tag;
		for (int i = 0; i < firstList.size(); i++) {
			Map<String, Object> mValue = firstList.get(i);
			for (String key : mValue.keySet()) {
				if (fieldKey.equals(key)) {
					Object oV = mValue.get(key);
					if (oV instanceof String) {
						String value = (String) oV;
						if (value != null) {
							setFieldInTarget(targetPane, dataField.getName(), value, i);
							break;
						}
					} else if (oV instanceof List) {
						List<Map<String, Object>> secondList = (List<Map<String, Object>>) oV;
						for (int j = 0; j < secondList.size(); j++) {
							Map<String, Object> mValue2 = secondList.get(j);
							if (tag.contains("[")) {
								key = MXMessageFieldHelper.removeArraySigns(key);
							}
							String oV2 = (String) mValue2.get(key);
							setFieldInTarget(targetPane, dataField.getName(), oV2, i, j);
						}
						break;
					}
				}
			}
		}
	}

	private void setValueFromList2(DataField dataField, String tag, String path, String key2, String key3,
			List<Map<String, Object>> secondList) {
		path = MXMessageFieldHelper.removeArraySigns(path);
		String fieldKey = path + "." + tag;
		for (int i = 0; i < secondList.size(); i++) {
			Map<String, Object> mValue = secondList.get(i);
			for (String key : mValue.keySet()) {
				if (key2.equals(key)) {
					Object oV = mValue.get(key);
					if (oV instanceof String) {
						String value = (String) oV;
						if (value != null) {
							setFieldInTarget(targetPane, dataField.getName(), value, i);
							break;
						}
					} else if (oV instanceof List) {
						List<Map<String, Object>> item2ndList = (List<Map<String, Object>>) oV;
						for (int j = 0; j < item2ndList.size(); j++) {
							Map<String, Object> mValue2 = item2ndList.get(j);
							for (Entry<String, Object> entry : mValue2.entrySet()) {
								if (key3 == null) {
									if (fieldKey.equals(entry.getKey())) {
										String oV2 = (String) entry.getValue();
										setFieldInTarget(targetPane, dataField.getName(), oV2, i, j);
									}
								} else {
									if (key3.equals(entry.getKey())) {
										Object oV2 = entry.getValue();
										if (oV2 instanceof String) {
											String v2 = (String) entry.getValue();
											setFieldInTarget(targetPane, dataField.getName(), v2, i, j);
										} else {
											List<Map<String, Object>> item3rdList = (List<Map<String, Object>>) oV2;
											for (int k = 0; k < item3rdList.size(); k++) {
												Map<String, Object> mValue3 = item3rdList.get(k);
												for (Entry<String, Object> entry3 : mValue3.entrySet()) {
													String currentKey = fieldKey;
													if (tag.contains("[")) {
														currentKey =  MXMessageFieldHelper.removeArraySigns(currentKey);
													}
													if (currentKey.equals(entry3.getKey())) {
														Object oV3 = entry3.getValue();
														if (oV3 instanceof String) {
															String v3 = (String) entry3.getValue();
															setFieldInTarget(targetPane, dataField.getName(), v3, i, j, k);	
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	@Override
	public Object visit(MarkerField markerField, Object data) {
		// not implemented
		return data;
	}
}