package com.misys.tiplus2.swift.message.validation.rule;

import java.util.Map;
import java.util.TreeMap;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;

/**
 * TSDS-40908
 * 
 * @author DaiD1
 *
 */
public class RuleResult {

	private String textValue;
	private Double numericalValue;
	private boolean logicalValue;
	private Map<String, String> mapValue;
	private String subValue;
	private int subIndex = -1;
	private int subIdxBegin = -1;
	private int subIdxEnd = -1;
	private String constructType;
	private String statementType;
	private String precedureType;
	private DataField mapField;
	private TagDataField tiField;
	private  Object resource;

	public String getSubValue() {
		return subValue;
	}

	public void setSubValue(String subValue) {
		this.subValue = subValue;
	}

	public int getSubIndex() {
		return subIndex;
	}

	public void setSubIndex(int subIndex) {
		this.subIndex = subIndex;
	}

	public String getTextValue() {
		return textValue;
	}

	public void setTextValue(String textValue) {
		this.textValue = textValue;
	}

	public Double getNumericalValue() {
		return numericalValue;
	}

	public void setNumericalValue(Double numericalValue) {
		this.numericalValue = numericalValue;
	}

	public boolean getLogicalValue() {
		return logicalValue;
	}

	public void setLogicalValue(boolean logicalValue) {
		this.logicalValue = logicalValue;
	}

	public void addToMapValue(String key, String value) {

		if (mapValue == null) {
			mapValue = new TreeMap<String, String>();
		}
		mapValue.put(key, value);
	}

	public Map<String, String> getMapValue() {

		return this.mapValue;
	}

	public int getSubIdxBegin() {
		return subIdxBegin;
	}

	public void setSubIdxBegin(int subIdxBegin) {
		this.subIdxBegin = subIdxBegin;
	}

	public int getSubIdxEnd() {
		return subIdxEnd;
	}

	public void setSubIdxEnd(int subIdxEnd) {
		this.subIdxEnd = subIdxEnd;
	}

	public String getConstructType() {
		return constructType;
	}

	public void setConstructType(String constructType) {
		this.constructType = constructType;
	}

	public String getStatementType() {
		return statementType;
	}

	public void setStatementType(String statementType) {
		this.statementType = statementType;
	}

	public String getPrecedureType() {
		return precedureType;
	}

	public void setPrecedureType(String precedureType) {
		this.precedureType = precedureType;
	}

	public DataField getMapField() {
		return mapField;
	}

	public void setMapField(DataField mapField) {
		this.mapField = mapField;
	}

	public TagDataField getTiField() {
		return tiField;
	}

	public void setTiField(TagDataField tiField) {
		this.tiField = tiField;
	}

	public Object getResource() {
		return resource;
	}

	public void setResource(Object resource) {
		this.resource = resource;
	}

}
