package com.misys.tiplus2.swift.mx.message;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.misys.tiplus2.catalog.swift.mx.message.definition.v1.elements.Field;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.foundations.xml.XMLException;

/**
 * TSDS-47627 MX
 * 
 * @author DaiD1
 *
 */
public class MXMessageFieldHelper {

    
    private static final Logger LOG = LoggerFactory.getLogger(MXMessageFieldHelper.class);

    
    private MXMessageFieldHelper() {
        
    }
    /**
     * remove optional sign (|) and multiple sign ([n]) from field and tag
     * 
     * @param field
     */

    public static String removeSigns(String pathortag) {
        
        Loggers.method().enter(LOG, pathortag);
        
        String result = pathortag;
        if (pathortag != null) {
            if (pathortag.contains("|")) {
                pathortag = pathortag.replace("|", "");
            }

            if (pathortag.contains("?")) {
                pathortag = pathortag.replace("?", "");
            }
            
            if (pathortag.contains("[") && pathortag.contains("]")) {
                pathortag = removeArraySigns(pathortag);
            }
            result = pathortag;
        }
        
        Loggers.method().exit(LOG, result);
        return result;
    }

    /**
     * Remove the optional sign "|" from path or tag
     * @param pathortag
     * @return
     */
    public static String removeOptionSign(String pathortag) {
        
        Loggers.method().enter(LOG, pathortag);
        
        String result = pathortag;
        if (pathortag != null) {
            if (pathortag.contains("|")) {
                pathortag = pathortag.replace("|", "");
            }

            result = pathortag;
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public static String removeChoiceSign(String pathortag) {
        
        Loggers.method().enter(LOG, pathortag);
        
        String result = pathortag;
        if (pathortag != null) {
            if (pathortag.contains("?")) {
                pathortag = pathortag.replace("?", "");
            }

            result = pathortag;
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public static String removeArraySigns(String pathortag) {
        
        Loggers.method().enter(LOG, pathortag);
        
        String result = pathortag;
        
        if (pathortag != null) {
            if (pathortag.contains("[") && pathortag.contains("]")) {
                String[] paths = pathortag.split("\\.");
                StringBuilder resultBd = new StringBuilder();        
                for (String path:paths) {
                    if (path.contains("[") && path.contains("]")) {
                        int idx1 = path.indexOf("[");
                        int idx2 = path.indexOf("]", idx1 + 1);
                        path = path.substring(0, idx1);
                    }
                    if (!resultBd.toString().isEmpty()) {
                        resultBd.append(".");
                    }
                    resultBd.append(path);
                }   
                if (!resultBd.toString().isEmpty()) {
                   result = resultBd.toString();   
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

  public static String removeFirstArraySigns(String pathortag) {
        
        Loggers.method().enter(LOG, pathortag);
        
        String result = pathortag;
        boolean first = false;
        
        if (pathortag != null) {
            if (pathortag.contains("[") && pathortag.contains("]")) {
                String[] paths = pathortag.split("\\.");
                StringBuilder resultBd = new StringBuilder();        
                for (String path:paths) {
                    if (path.contains("[") && path.contains("]") && !first) {
                        int idx1 = path.indexOf("[");
                        int idx2 = path.indexOf("]", idx1 + 1);
                        path = path.substring(0, idx1);
                        first = true;
                    }
                    if (!resultBd.toString().isEmpty()) {
                        resultBd.append(".");
                    }
                    resultBd.append(path);
                }   
                if (!resultBd.toString().isEmpty()) {
                   result = resultBd.toString();   
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    /**
     * check if the path has array
     * 
     * @return
     */
    public static boolean hasArray(String value) {
        
        Loggers.method().enter(LOG, value);
        boolean result = false;
        if (value != null && value.contains("[") && value.contains("]")) {
            result = true;
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    /**
     * Count number of array in the given path and tag
     * @param path
     * @param tag
     * @return
     */
    public static int countNumberOfArray(String path, String tag) {
    	int result = 0;
    	result = countNumberOfArray(path) +  countNumberOfArray(tag);
    	return result;
    }
    
    /**
     * Count number of array in the given field value
     * @param value
     * @return
     */
    public static int countNumberOfArray(String value) {
    	int result = 0;
    	
    	if (value!=null && value.contains("[") && value.contains("]")) {
    		
    		while (value!=null) {
    			int indx = value.indexOf("[");
    			if (indx>0) {
    				value = value.substring(indx+1);
    				result++;
    			} else {
    				value = null;
    			}
    		}
    	}
    	return result;
    }

    /**
     * Get array size
     * 
     * @param value
     * @return
     */
    public static int getArraySize(String value) {
        
        Loggers.method().enter(LOG, value);
        int result = 0;
        if (hasArray(value)) {
            int idx1 = value.indexOf("[");
            int idx2 = value.indexOf("]", idx1 + 1);
            String val = value.substring(idx1 + 1, idx2);
            if ("n".equals(val)) {
                result = Integer.MAX_VALUE;
            } else {
                result = Integer.parseInt(val);
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
 public static String  getArraySizeAsString(String value) {
        
        Loggers.method().enter(LOG, value);
        String result = null;
        if (hasArray(value)) {
            int idx1 = value.indexOf("[");
            int idx2 = value.indexOf("]", idx1 + 1);
           result = value.substring(idx1 + 1, idx2);
            
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

 
     /**
      * Do not remove any sign (optional, choice and array)
      * @param path
      * @param tag
      * @return
      */
    public static String getArrayKey1(String path, String tag) {
        
        Loggers.method().enter(LOG, path,tag);
        String result = null;
        String key = null;
        
        if (path!=null && tag!=null) {
            key=path+"."+tag;
        } else if (path!=null && tag==null) {
            key = path;
        }else if (path==null && tag!=null) {
            key = tag;
        }
        
        result = getArrayKey1(key);
        
        Loggers.method().exit(LOG, result);
        return result;
    }

    public static String getArrayKey1(String path, String tag, int fromIndx) {
        
        Loggers.method().enter(LOG, path,tag, fromIndx);
        String result = null;
        String key = null;
        
        if (path!=null && path.length() <= fromIndx) {
            path = removeArraySigns(path);
            if (tag.contains("[")) {
                result = path+"."+tag;
            }
        } else {
            if (path!=null && tag!=null) {
                key=path+"."+tag;
            } else if (path!=null && tag==null) {
                key = path;
            }else if (path==null && tag!=null) {
                key = tag;
            }
            result = getArrayKey1(key, fromIndx);
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    /**
     * Get the first Array key and remove optional and choice signs
     * 
     * @param path
     * @param tag
     * @return
     */
    public static String getFirstArrayKey(String path, String tag) {
        
        Loggers.method().enter(LOG, path,tag);
        String result = getArrayKey1(path,tag);
        result = removeOptionSign(result);
        result = removeChoiceSign(result);
  
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    
    public static String getFirstArrayKey(String value) {
        
        Loggers.method().enter(LOG, value);
        String result = null;
        if (value!=null && value.contains(".")) {
            int indx = value.lastIndexOf(".");
            String path = value.substring(0, indx);
            String tag = value.substring(indx+1);
            result = getFirstArrayKey(path,tag, 0);
        }
  
        Loggers.method().exit(LOG, result);
        return result;
    }

    /**
     * Get the first Array key start from index and remove optional and choice signs
     * 
     * @param path
     * @param tag
     * @param fromIndx
     * @return
     */
    public static String getFirstArrayKey(String path, String tag, int fromIndx) {
        
        Loggers.method().enter(LOG, path,tag);
        path = removeOptionSign(path);
        path =  removeChoiceSign(path);
        tag = removeOptionSign(tag);
        tag =  removeChoiceSign(tag);
        String result = getArrayKey1(path,tag, fromIndx);
       
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public static String getArrayKeyAtIndex(String path, String tag, int indx) {
        
        Loggers.method().enter(LOG, path,tag, indx);
        String result = null;
        path = removeOptionSign(path);
        tag = removeOptionSign(tag);
        String key = path+"."+tag;
        result = getArrayKeyAtIndex(key,indx);
        Loggers.method().exit(LOG, result);
        return result;
    }

    /**
     * Get the first array group key and not remove any sings
     * 
     * @param path
     * @return
     */
    public static String getArrayKey1(String path) {

        Loggers.method().enter(LOG, path);
        String result = path;
        if (!StringUtils.isEmpty(path) && path.contains("[") && path.contains("]")) {
            int indx = path.indexOf("]");
            result = path.substring(0, indx + 1);
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    
    /**
     * Get the first array key start from fromIndx 
     * @param path
     * @param afterIndx
     * @return
     */
    public static String getArrayKey1(String path, int fromIndx) {

        Loggers.method().enter(LOG, path);
        String result = null;
        if (!StringUtils.isEmpty(path) && path.contains("[") && path.contains("]")) {
            
            path = removeOptionSign(path);
            path =  removeChoiceSign(path);
            
            int indx = path.indexOf("]", fromIndx);
            if (indx>0) {
                result = path.substring(0, indx + 1);
            }
            
            // remove array signs before fromIndx
            String[] paths = result.split("\\.");
                if (paths.length>1) {
                    int length=0;
                    for (int i=0; i<paths.length; i++) {
                        String item = paths[i];
                        length = length+item.length()+1;
                        if (item.contains("[") && length<fromIndx) {
                            item = removeArraySigns(item); 
                            paths[i] = item;
                        }
                    }
            
                    StringBuilder str = new StringBuilder();
                    for (int i=0; i<paths.length; i++) {
                        if (i!=0) {
                            str.append(".");
                        }
                        str.append(paths[i]);
                    }
                    result = str.toString(); 
                }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public static String getArrayKeyAtIndex(String path, int idx) {

        Loggers.method().enter(LOG, path, idx);
        String result = null;
        if (!StringUtils.isEmpty(path) && path.contains("[") && path.contains("]")) {
            
            int count=0;
            int dist = 0;
            String tmp = path;
            while (StringUtils.isNotEmpty(tmp) && tmp.contains("[") && tmp.contains("]") && count < idx && dist < path.length()) {
                int p = tmp.indexOf("]");
                
                if (p+1<tmp.length()) {
                    tmp = tmp.substring(p+1);
                    if (tmp.startsWith(".")) {
                        tmp = tmp.substring(1);
                    }
                }
                count++;
                dist+=p+1;
            }
           
            if (count==idx) {
                result = path.substring(0, dist+1);
                if (result.endsWith(".")) {
                    result = result.substring(0, result.length()-1);
                }
            }
            result = removeArraySigns(result);
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    /**
     * Need a better way to replace this method
     */
    public static String removeNanmespaces(String value) {

        Loggers.method().enter(LOG, value);
        String result = null;
        String pattern = " xmlns:.*\">";
        if (value != null && !value.isEmpty()) {
            result = value.replaceAll(pattern, ">");
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public static String removeLineBreak(String value) {

        Loggers.method().enter(LOG, value);
        String result = null;
      
        if (value != null && !value.isEmpty()) {
            result = value.replace("&#xD;", "");
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public static Field copyFieldWithNewPath(String newPath, String newTag, Field srcField) throws XMLException {
        
        Loggers.method().enter(LOG, newPath, newTag,srcField);
        Field newField = null;
        if (newPath != null) {
            newField = new Field();
            newField.setAttribute("path", newPath);
            newField.setAttribute("tag", newTag);
            newField.setAttribute("attribute", srcField.getAttribute());
            newField.setAttribute("description", srcField.getDescription());
            newField.setAttribute("type", srcField.getType());
            newField.setAttribute("repeat", srcField.getRepeat());
            newField.setAttribute("mandatory", srcField.getMandatory());
            newField.setTagType(srcField.getTagType());
        }
        Loggers.method().exit(LOG, newField);
        return newField;
    }

    public static Field createBisMsgIdField() throws XMLException {

        Field field = new Field();
        field.setAttribute("path", "AppHdr");
        field.setAttribute("tag", "BizMsgIdr");
        field.setAttribute("type", "BusinessApplicationHeaderV02.Max35Text");
        field.setAttribute("description", "BusinessMessageIdentifier");
        field.setAttribute("tag-type", "string");
        field.setAttribute("mandatory", "true");

        return field;
    }
    
    public static FieldData createFieldDataFromField(Field field) {

        Loggers.method().enter(LOG, field);
        FieldData fieldData = null;
        if (field.getPath() != null && field.getTag() != null ) {
           fieldData = new FieldData(field.getPath(), field.getTag());
           fieldData.setDescription(field.getDescription());
           boolean isMandatory = false;
           if ("true".equals(field.getMandatory())) {
               isMandatory=true;
           }
           fieldData.setMandatory(isMandatory);
        }
        Loggers.method().exit(LOG, fieldData);
        return fieldData;
    }

    public static FieldData getAttributeFromList(String attribute, List<FieldData> fieldDataList) {

        Loggers.method().enter(LOG, attribute, fieldDataList);
        FieldData fieldData = null;
        if (attribute != null && fieldDataList != null && !fieldDataList.isEmpty()) {
            for (FieldData fd : fieldDataList) {
                if (fd.getTag().endsWith(attribute)) {
                    fieldData = fd;
                    break;
                }
            }
        }
        Loggers.method().exit(LOG, fieldData);
        return fieldData;
    }
    
    public static String formatMessageId(String msgId) {

        Loggers.method().enter(LOG, msgId);
        String result = null;
        if (msgId != null && msgId.contains(".")) {
            String[] parts = msgId.split("\\.");
            if (parts.length == 4) {
                StringBuilder valB = new StringBuilder();
                valB.append(parts[0]).append(parts[1]).append(parts[2]);
                valB.append(".v").append(parts[3]);
                result = valB.toString();
            } else if (parts.length == 5 ) {
                StringBuilder valB = new StringBuilder();
                valB.append(parts[0]).append(parts[1]).append(parts[2]);
                valB.append(".v").append(parts[3]);
                valB.append(".").append(parts[4]);
                result = valB.toString();
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    
    public static String reversePath(String path) {
        Loggers.method().enter(LOG, path);
        String result = null;
        
        if (!StringUtils.isEmpty(path)) {
            if (path.contains(".")) {
             String[] paths = path.split("\\.");
             StringBuilder pathBd = new StringBuilder();
             
             for (int i=paths.length-1; i>-1; i--) {
                if (i<paths.length-1) {
                    pathBd.append(".");
                }
                pathBd.append(paths[i]);
             }
             result = pathBd.toString();
            }
            else {
                result = path;
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public static String normalize(String text) {
        String result = null;

        if (text != null) {
            char[] marker = { 0x8a }; // non-swift charters
            CharSequence cseq = java.nio.CharBuffer.wrap(marker);

            if (text.contains(MXMessageConstant.WINDOWS_CRLF)) {

                text = text.replace((CharSequence) MXMessageConstant.WINDOWS_CRLF, cseq);
            }
            if (text.contains(MXMessageConstant.UNIX_LF)) {
                text = text.replace(MXMessageConstant.UNIX_LF, MXMessageConstant.WINDOWS_CRLF);
            }
            result = text.replace(cseq, MXMessageConstant.WINDOWS_CRLF);
        }
        return result;

    }
    
    public static String getFieldDescription(String path, Map<String,Field> mapMessageField) {
        
        Loggers.method().enter(LOG, path);
        String result = null;
        
        for (Entry<String, Field> entry:mapMessageField.entrySet()) {
            String key = entry.getKey();
            key = MXMessageFieldHelper.removeSigns(key);
            Field field = entry.getValue();
            String descps = field.getDescription();
            String[] pathArray = path.split("\\.");
            String[] keyArray = key.split("\\.");
            String[] descArray = descps.split("\\.");
            
            if (keyArray.length> pathArray.length && key.startsWith(path)) {
              
                if(!path.contains(".") && !descps.contains(".") ) {
                    result = descps;
                    break;
                } else if (!path.contains(".") && descps.contains(".")) {  
                    result = descArray[0];
                    break;
                } else {
                   int i = pathArray.length;
                   String pathEnd =pathArray[i-1];
                   String keyEnd=keyArray[i-1];
                   if (descArray.length>=i && pathEnd.equals(keyEnd)) {
                       result = descArray[i-1];
                       break;
                   }
                }
            } else if (keyArray.length == pathArray.length && key.equals(path)) {
                int i = pathArray.length;
                if (descArray.length>=i) {
                    result = descArray[i-1];
                    break;
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public static void getElementPath(Element element, StringBuilder path) {
        
        Node parent = element.getParentNode();
        if (parent!=null) {
            if (parent.getNodeType() == Node.ELEMENT_NODE) {
                Element el = (Element) parent;
                if (!path.toString().isEmpty()) {
                    path.append(".");
                }
                path.append(el.getNodeName());
            
                getElementPath(el, path);
            }
        } 
    }
    
    public static String convertDocumentToString(Document doc) throws TransformerException {

        Loggers.method().enter(LOG);
        String result = null;
        DOMSource domSource = new DOMSource(doc);
        StringWriter writer = new StringWriter();
        StreamResult stResult = new StreamResult(writer);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.transform(domSource, stResult);
        writer.flush();
        result =  writer.toString();
        
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public static boolean matchRegExp(String value, String regExp) {

        Loggers.method().enter(LOG, value, regExp);
        boolean result = false;

        try {
            Pattern pattern = Pattern.compile(regExp);
            Matcher matcher = pattern.matcher(value);

            while (matcher.find()) {
                result = true;
            }

        } catch (Exception e) {
            Loggers.general().error(LOG, "Failed to match " + value);
            Loggers.general().error(LOG, e.getMessage());
          
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
  
    // the key must not include  option sign and choice sign
    public static String getLastArrayKey(String key) {
        Loggers.method().enter(LOG, key);
        String result = key;
        if (!StringUtils.isEmpty(key) && key.contains("[") && key.contains("]")) {
            int indx = key.lastIndexOf("[");
            indx = key.lastIndexOf("[", indx+1);
             
            if (indx>0) {
                String preKey = key.substring(0, indx);
                String postKey = key.substring(indx);
                preKey = removeArraySigns(preKey);
                result = preKey+postKey;
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }   
       
}
