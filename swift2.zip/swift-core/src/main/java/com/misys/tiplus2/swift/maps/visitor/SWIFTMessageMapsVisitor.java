package com.misys.tiplus2.swift.maps.visitor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.SequenceMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.catalog.swift.message.map.v1.visitor.NoopMessageMapVisitor;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.exception.SWIFTMessageException;
import com.misys.tiplus2.swift.maps.MessageMapsLoader;
import com.misys.tiplus2.swift.message.validation.rule.MessageRulesLoader;

/**
 * This visitor provides common functionality to handle behaviour based on the
 * message maps definition. While this is not defined as an abstract class, it
 * is expected that it will only be used by subclasses.
 *
 * @author DaiD1
 *
 */
public class SWIFTMessageMapsVisitor extends NoopMessageMapVisitor {

    private static final Logger LOG = LoggerFactory.getLogger(SWIFTMessageMapsVisitor.class);

    private MessageMapsLoader loader;
    private MessageRulesLoader rulesLoader;

    protected boolean isEmbedded;
    protected String currentSequenceMapName;
    protected String currentFieldOptionsTag;

    public void initialise(MessageMapsLoader loader) {
        this.loader = loader;
    }
    
    public void initialise(MessageMapsLoader loader, MessageRulesLoader rulesLoader) {
        this.loader = loader;
        this.rulesLoader = rulesLoader;
    }

    public void initialise(MessageMapsLoader loader, boolean isEmbedded) {
        this.loader = loader;
        this.isEmbedded = isEmbedded;
    }

    protected MessageMapsLoader getMessageMapsLoader() {
        return this.loader;
    }
    
    protected MessageRulesLoader getRulesLoader() {
    	return this.rulesLoader;
    }

    @Override
    public Object visit(MessageMap messageMap, Object data) {
        Loggers.method().enter(LOG, messageMap, data);

        String include = messageMap.getInclude();

        if (include != null && !include.isEmpty()) {
            try {
                MessageMap includeMsg = loader.findByMessage(include);
                if (includeMsg == null) {
                    LOG.error("Cannot load message map:", include);
                    throw new SWIFTMessageException("Can not load message map: " + include);
                }
                if (!"header-fields".equals(include)||!isEmbedded) {
                    // recursion
                    includeMsg.accept(this, data);
                }
            } catch (Exception e) {
                LOG.error("Cannot load message map:", include);
                throw new SWIFTMessageException("Can not load message map: " + include, e);
            }
        }

        if (!isEmbedded) {
            for (HeaderField headerField : messageMap.getHeaderFields()) {
                headerField.accept(this, data);
            }
        }

        for (DataTypeChoice choice : messageMap.getDataTypeChoices()) {
            switch (choice.getChosen()) {
            case DATAFIELD:
                choice.getDataField().accept(this, data);
                break;
            case MARKERFIELD:
                choice.getMarkerField().accept(this, data);
                break;
            case DATABLOCK:
                choice.getDataBlock().accept(this, data);
                break;
            case FIELDOPTIONS:
                FieldOptions fieldOptions =choice.getFieldOptions();
                currentFieldOptionsTag=fieldOptions.getTag();
                fieldOptions.accept(this, data);
                currentFieldOptionsTag=null;
                break;
            case SEQUENCEMAP:
                SequenceMap sequenceMap = choice.getSequenceMap();
                currentSequenceMapName = sequenceMap.getName();
                sequenceMap.accept(this, data);
                currentSequenceMapName=null;
                break;
            case EMBEDDED:
                choice.getEmbedded().accept(this, data);
                break;
            default:
                break;
            }
        }

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(SequenceMap sequenceMap, Object data) {

       Loggers.method().enter(LOG, sequenceMap, data);
       
       for (DataTypeChoice choice:sequenceMap.getDataTypeChoices()) {
           switch (choice.getChosen()) {
           case DATAFIELD:
               choice.getDataField().accept(this, data);
               break;
           case FIELDOPTIONS:
               FieldOptions fieldOptions =choice.getFieldOptions();
               currentFieldOptionsTag=fieldOptions.getTag();
               fieldOptions.accept(this, data);
               currentFieldOptionsTag=null;
               break;
           case DATABLOCK:
               choice.getDataBlock().accept(this, data);
               break;
           case MARKERFIELD:
               choice.getMarkerField().accept(this, data);
               break;
           default:
               break;
           }
       }
        Loggers.method().exit(LOG, data);
        return data;
    }
    
    @Override
    public Object visit(FieldOptions fieldOptions, Object data) {

        Loggers.method().enter(LOG, fieldOptions, data);
        if (fieldOptions!=null){ 
            for (DataField dataField : fieldOptions.getDataFields()) {
                dataField.accept(this, data);
            }
        }
        Loggers.method().exit(LOG, data);
        return data;
    }
}
