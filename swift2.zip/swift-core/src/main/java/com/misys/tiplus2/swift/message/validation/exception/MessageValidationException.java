package com.misys.tiplus2.swift.message.validation.exception;

import com.misys.tiplus2.swift.exception.SWIFTMessageException;

/**
 * MessageValidationException
 *
 * @author DaiD1
 *
 */
public class MessageValidationException extends SWIFTMessageException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public MessageValidationException() {
        super();
    }

    public MessageValidationException(String message) {
        super(message);
    }

    public MessageValidationException(Throwable cause) {
        super(cause);
    }

    public MessageValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public MessageValidationException(String code, String message) {
        super(code, message);
    }

    public MessageValidationException(String code, String message, Throwable cause) {
        super(code, message, cause);

    }

}
