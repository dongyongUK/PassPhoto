package com.misys.tiplus2.swift.message.validation.error.interpretation;

import java.util.Properties;

/**
 * 
 * @author DaiD1
 *
 */
public class SwiftValidationResources {

    Properties errorCodeResources;

    public Properties getErrorCodeResources() {
        return errorCodeResources;
    }

    public void setErrorCodeResources(Properties errorCodeResources) {
        this.errorCodeResources = errorCodeResources;
    }

    public String getErrorDescriptionByCode(String code) {
        String message = errorCodeResources.getProperty(code);
        return message;
    }
}
