package com.misys.tiplus2.swift.message.processor;

import com.misys.tiplus2.swift.message.IntermediateMessage;

public interface MessageProcessor {
    public static final String MT_BEAN_NAME = "mt.message.processor";
    public static final String MX_BEAN_NAME = "mx.message.processor";

    IntermediateMessage transformIncomingMessage(String rawMessage) throws MessageProcessorException;

    IntermediateMessage transformFromRawMessage(String rawMessage) throws MessageProcessorException;

    IntermediateMessage transformFromRawMessage(String rawMessage, boolean validation)
            throws MessageProcessorException;

    IntermediateMessage transformToRawMessage(IntermediateMessage messageContainer, boolean validation)
            throws MessageProcessorException;
    
    IntermediateMessage validateRawMessage(String rulesetId, String rawMessage) throws MessageProcessorException;

    IntermediateMessage annotate(IntermediateMessage messageContainer) throws MessageProcessorException;

    String getVersion();
}
