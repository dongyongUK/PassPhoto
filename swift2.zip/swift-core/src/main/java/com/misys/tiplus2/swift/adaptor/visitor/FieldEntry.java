package com.misys.tiplus2.swift.adaptor.visitor;

public class FieldEntry {

    private String name;
    private String value;
    private String tag;
    private String errorCode;
    private String errorDetails;
    private int blockNumber;

    public FieldEntry(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfLines() {
        int result = 1;
        if (value != null) {
            String[] parts = value.split("\r\n");
            result = parts.length;
            if (result > 30) {
                result = 30;
            }
        }
        return result;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    public int getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(int blockNumber) {
        this.blockNumber = blockNumber;
    }

    public void setName(String name) {
        this.name = name;
    }
}
