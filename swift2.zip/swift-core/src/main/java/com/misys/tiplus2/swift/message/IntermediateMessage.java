package com.misys.tiplus2.swift.message;

import java.io.Serializable;

public abstract class IntermediateMessage implements  Serializable{

}
