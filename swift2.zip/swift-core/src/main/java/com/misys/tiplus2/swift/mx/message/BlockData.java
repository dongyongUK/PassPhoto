package com.misys.tiplus2.swift.mx.message;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 
 * @author DaiD1
 *
 */
public class BlockData implements Serializable {

	private static final long serialVersionUID = -6160911793434320647L;

	// the size of the map is the number of fields within the block
	Map<String, FieldData> fieldDatas;
	private String name;
	private String sequence;

	public BlockData(String name) {
		this.name = name;
		fieldDatas = new HashMap<String, FieldData>();
	}

	public BlockData(String name, Map<String, FieldData> fieldDatas) {
		this.name = name;
		this.fieldDatas = fieldDatas;
	}

	public BlockData(String name, String sequence, Map<String, FieldData> dataFields) {
		this.name = name;
		this.sequence = sequence;
		this.fieldDatas = dataFields;
	}

	public void addDataField(FieldData dataField) {
		fieldDatas.put(dataField.getTag(), dataField);
	}

	public Map<String, FieldData> getDataFields() {
		return fieldDatas;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public BlockData copy() {

		BlockData result = new BlockData(this.name);
		for (Entry<String, FieldData> entry : fieldDatas.entrySet()) {
			result.addDataField(entry.getValue().copy());
			;
		}
		return result;
	}
}
