package com.misys.tiplus2.swift.maps;

import com.misys.tiplus2.swift.exception.SWIFTMessageException;

/**
 * SwftMessageFormatException
 *
 * @author DaiD1
 *
 */
public class MessageMapException extends SWIFTMessageException {

    /**
     *
     */
    private static final long serialVersionUID = 500174645104555251L;

    public MessageMapException() {
        super();
    }

    public MessageMapException(String message) {
        super(message);
    }

    public MessageMapException(Throwable cause) {
        super(cause);
    }

    public MessageMapException(String message, Throwable cause) {
        super(message, cause);
    }

    public MessageMapException(String code, String message) {
        super(code, message);
    }

    public MessageMapException(String code, String message, Throwable cause) {
        super(code, message, cause);

    }
}
