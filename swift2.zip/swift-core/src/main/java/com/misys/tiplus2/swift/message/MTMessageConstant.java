package com.misys.tiplus2.swift.message;

public interface MTMessageConstant {

    final String BLOCK1_START = "{1:";
    final String F21_BLOCK_START = "{1:F21";
    final String BLOCK2_START = "{2:";
    final String BLOCK3_START = "{3:";
    final String BLOCK4_START = "{4:";
    final String BLOCK5_START = "{5:";
    final String BLOCK1_END = "}";
    final String BLOCK2_END = "}";
    final String BLOCK3_END = "}";
    final String BLOCK4_END = "\r\n-}";
    final String BLOCK5_END = "}";
    final String BLOCK_END = "}";

    final String NEW_LINE = "\n";

    final String B1_APPLICATION_ID_TAG = "ApplicationId";
    final String B1_SERVICE_ID_TAG = "ServiceId";
    final String B1_APPLICATION_ID_VALUE = "F";
    final String B1_SERVICE_ID_FIN_VALUE = "01"; // 01=FIN/GPA 21=/ACK/NAK
    final String B1_SERVICE_ID_ACK_VALUE = "21";
    final String B1_SENDER_TAG = "LogicalTerminalAddress";
    final String B1_SESSION_TAG = "Session";
    final String B1_SEQUENCE_TAG = "Sequence";

    final String B1_APPLICATION_ID_DES = "Application ID";
    final String B1_SERVICE_ID_DES = "Service ID";
    final String B1_SENDER_DES = "Logical Terminal Address";
    final String B1_SESSION_DES = "Session";
    final String B1_SEQUENCE_DES = "Sequence";
    
    final String B2_DIRECTION_TAG = "InputOutputIdentifier";
    final String B2_SWIFT_DIRECTION_TAG = "Direction";
    final String B2_MESSAGE_TYPE_TAG = "MessageType";
    final String B2_PRIORITY_TAG = "Priority";
    final String B2I_RECEIVER_TAG = "ReceiverAddress";
    final String B2I_DELIVERY_MONITORING_TAG = "DeliveryMonitoring";
    final String B2I_OBSOLESCENCE_TAG = "ObsolescencePeriod";
    final String B2O_INPUT_TIME_TAG = "InputTime";
    final String B2O_MIR_TAG = "MIR";
    final String B2O_OUTPUT_DATE_TAG = "OutputDate";
    final String B2O_OUTPUT_TIME_TAG = "OutputTime";
    
    final String B2_DIRECTION_DES = "Input Output Identifier";
    final String B2_SWIFT_DIRECTION_DES = "Direction";
    final String B2_MESSAGE_TYPE_DES = "Message Type";
    final String B2_PRIORITY_DES = "Priority";
    final String B2I_RECEIVER_DES = "Receiver Address";
    final String B2I_DELIVERY_MONITORING_DES = "Delivery Monitoring";
    final String B2I_OBSOLESCENCE_DES = "Obsolescence Period";
    final String B2O_INPUT_TIME_DES = "Input Time";
    final String B2O_MIR_DES = "Message Inout Reference";
    final String B2O_OUTPUT_DATE_DES = "Output Date";
    final String B2O_OUTPUT_TIME_DES = "Output Time";
    

    final String B3_SERVICE_ID_TAG = "103";
    final String B3_SERVICE_TYPE_TAG = "111";
    final String B3_BANKING_PRIORITY_TAG = "113";
    final String B3_MUR_TAG = "108";
    final String B3_VALIDATION_TAG = "119";
    final String B3_TRANS_REFERENCE_TAG = "121";

    final String B5_TRIALER_TAG = "Trailer";
    final String B5_MAC_TAG = "MAC";
    final String B5_CHK_TAG = "CHK";
    final String B5_PDE_TAG = "PDE";
    final String B5_DLM_TAG = "DLM";

    final int BLOCK1_LENGTH = 29; 
    final int BLOCK2_IN_MIN_LENGTH = 20;
    final int BLOCK2_IN_MAX_LENGTH = 25;
    final int BLOCK2_OUT_MIN_LENGTH = 50;
    final int BLOCK2_OUT_MAX_LENGTH = 51;

    final String INCOMING = "I";
    final String OUTGOING = "O";
    
    final String TAG_DELIMITER = ":";

    final String WINDOWS_CRLF = "\r\n";
    final String UNIX_LF = "\n";
    final String IOS_CR = "\r";

    final String[] BLOCK1_TAGS = { "ApplicationId", "ServiceId", "LogicalTerminalAddress", "Session", "Sequence" };

    final String[] BLOCK2_IN_TAGS = { "InputOutputIdentifier", "MessageType", "ReceiverAddress", "Priority",
            "DeliveryMonitoring", "ObsolescencePeriod" };

    final String[] BLOCK2__OUT_TAGS = { "InputOutputIdentifier", "MessageType", "InputTime", "MIR", "OutputDate",
            "OutputTime", "Priority" };

    final String[] BLOCK3_TAGS = { "103", "108", "111", "119" };
    final String[] BLOCK5_TAGS = { "Trailer" };

    /**
     * The message string length thresh hold before it is split.
     */
    static final int MAX_MESSAGE_LENGTH = 10000;

    /**
     * The maximum lines of tags 45A 46A nad 47A for messages MT700, MT710 and
     * MT720
     */
    static final int MAX_TAG7X0_LENGTH = 100;

    /**
     * The maximum lines of tags 77U and 77L of Message MT760 and MT767
     */
    static final int MAX_TAG76X_LENGTH = 150;

    /**
     * Maximum number of MT761 or MT775 for MT760 and MT767 can be split into.
     * Not included MT760 or MT767
     */
    static final int MAX_SPLITS_MT76x = 8;
    /**
     * The maximum lines of tag 79 of MT707
     *
     */
    static final int MAX_TAG79MT707_LENGTH = 35;

    /**
     * The maximum lines of tag 77J of MT734
     *
     */
    static final int MAX_TAG77JMT734_LENGTH = 70;

    /**
     * The maximum lines of tag 77J of MT750
     *
     */
    static final int MAX_TAG77JMT750_LENGTH = 70;

    /**
     * The maximum lines of tag 77C of MT760 and MT767
     *
     */
    static final int MAX_TAG77CMT76X_LENGTH = 150;

    /**
     * The maximum lines of tag 79 of MT799 and MT499
     *
     */
    static final int MAX_TAG79MT799_499_LENGTH = 35;

    /**
     * SCORE Message Type
     * 
     */

    static final String TYPE798 = "798";
    static final String TAG12 = ":12:";
    static final String TAG20 = ":20:";
    static final String TAG77E = ":77E:";
    static final String TAG26E = ":26E:";
    static final String TAG27A = ":27A:";
    static final String MT798SCORE_INDEX = "Index";
    static final String MT798SCORE_DETAILS = "Details";
    static final String MT798SCORE_SUBMESSAGE = "SubMessage";
    /**
     * The maximum lines of tag 79 of MTn99
     *
     */
    static final int MAX_TAG79MTn99_LENGTH = 35;

    static final String X_CHARACTER_SET = "x";
    static final String Z_CHARACTER_SET = "z";

    static String SWIFT_X_CHARS = "^[ a-zA-Z0-9/?:().,'+-]*$";
    static String SWIFT_Z_CHARS = "^[- a-zA-Z0-9 .,()/='+:?!\"%&*<>;{@#_]*$";

    static final String ACKNACK_MESSAGE_TYPE = "F21";
    

}
