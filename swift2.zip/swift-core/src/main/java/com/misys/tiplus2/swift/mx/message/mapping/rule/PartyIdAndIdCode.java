package com.misys.tiplus2.swift.mx.message.mapping.rule;

import java.util.function.Predicate;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.rule.MessageRuleHelper;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * 
 * Format [/1!a][/34X]    (party Identifier) MT_TO_MXFinancialInstitutationAccount
 *        4!a2!a2!c[3!c]   (Identifier Code BIC) MT_TO_MXBICFI 
 * 
 * Fields 57A
 * 
 * @author DaiD1
 *
 **/
public class PartyIdAndIdCode implements Predicate<RuleResult> {

    @Override
    public boolean test(RuleResult ruleResult) {
        boolean result = false;

        DataField mapField = ruleResult.getMapField();
        TagDataField tiField = ruleResult.getTiField();

        if (mapField == null || tiField == null) {
            return result;
        }

        String tag = mapField.getTag();
        String[] tags = null;
        if (tag != null && tag.contains(":")) {
            tags = tag.split(":");
        }
        String srcValue = tiField.getValue();
        if (srcValue == null) {
            return result;
        }

        String[] lines = MessageRuleHelper.splitLine(srcValue);
        int size = lines.length;
        String line = null;
        if (size > 1) {
            if (tags != null && tags.length > 1) {
                ruleResult.getMapField().setTag(tags[0]);
            }
            MT2MXFinancialInstTranslation.mt2mxFinancialInstAcct(ruleResult, lines[0]);
            line = lines[1];
        } else {
            line = lines[0];
        }
        
        if (tags!=null && tags.length>1) {
            ruleResult.getMapField().setTag(tags[1]);
        }
        MT2MXFinancialInstTranslation.mt2mxBICFI(ruleResult, line);
        result = true;
        return result;
    }

}
