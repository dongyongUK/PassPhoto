package com.misys.tiplus2.swift.mx.message;

import java.io.Serializable;
import java.util.Objects;

/**
 * 
 * @author DaiD1
 *
 */
public class FieldData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2395908157200494081L;

	private String tag;
	private String path;
	private String type;
	private String tagValue;
	private boolean mandatory;
	private String description;
	private String errorDetails;
	private String errorCode;
	private String errorSeverity;

	public FieldData(String path, String tag) {

		this.path = path;
		this.tag = tag;
	}

	public FieldData(String path, String tag, String tagValue) {
		
		this.path = path;
		this.tag = tag;
		this.tagValue = tagValue;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getTagValue() {
		return tagValue;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setTagValue(String tagValue) {
		this.tagValue = tagValue;
	}

	public boolean isMandatory() {
		return mandatory;
	}

	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	 public String getErrorSeverity() {
        return errorSeverity;
    }

    public void setErrorSeverity(String errorSeverity) {
        this.errorSeverity = errorSeverity;
    }

    public FieldData copy() {
	        FieldData result = new FieldData(this.path, this.tag, this.tagValue);
	        result.setMandatory(mandatory);
	        result.setDescription(description);
	        result.setErrorDetails(errorDetails);
	        result.setErrorDetails(errorCode);
	        return result;
	    }

    @Override
    public int hashCode() {
        return Objects.hash(path, tag, tagValue, type);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        FieldData other = (FieldData) obj;
        return Objects.equals(path, other.path) && Objects.equals(tag, other.tag)
                && Objects.equals(tagValue, other.tagValue) && Objects.equals(type, other.type);
    }

    @Override
    public String toString() {
        return "FieldData [tag=" + tag + ", path=" + path + ", type=" + type + ", tagValue=" + tagValue + "]";
    }
}
