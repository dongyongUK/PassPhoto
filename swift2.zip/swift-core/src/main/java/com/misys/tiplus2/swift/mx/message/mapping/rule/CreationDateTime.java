package com.misys.tiplus2.swift.mx.message.mapping.rule;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoUnit;
import java.util.function.Predicate;

import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * Get the current date and time in UTC ISO format e.g:
 * 2023-10-11T17:38:00.000+01:00
 * 
 * 
 * @author DaiD1
 *
 */
public class CreationDateTime implements Predicate<RuleResult> {

    static final String ruleID = "pred.gen.creDtTm";

    @Override
    public boolean test(RuleResult ruleResult) {
        boolean result = false;
      
        DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
                .append(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssxxxxx"))
                .toFormatter();
        String tgtValue = ZonedDateTime.now().truncatedTo(ChronoUnit.MINUTES).format(formatter);
              
        ruleResult.setTextValue(tgtValue);
        result = true;
        return result;
    }
}
