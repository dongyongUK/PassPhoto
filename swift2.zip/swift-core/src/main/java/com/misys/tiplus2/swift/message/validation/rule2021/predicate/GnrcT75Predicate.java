package com.misys.tiplus2.swift.message.validation.rule2021.predicate;

import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.FINMessageHelper;

/**
 * Rule for swift.T75
 * 
 * @author DaiD1
 *
 */
public class GnrcT75Predicate implements Predicate<String[]> {

    private static final Logger LOG = LoggerFactory.getLogger(GnrcT75Predicate.class);

    @Override
    public boolean test(String... args) {
        Loggers.method().enter(LOG);
        boolean result = true;
        if (args!=null && args.length>1) {
            String fieldValue = args[0];
            String messageType = args[1];
            if (fieldValue != null && !fieldValue.isEmpty() && FINMessageHelper.isnForwardSlashmFormat(fieldValue)) {
                int n1 = Integer.parseInt(fieldValue.substring(0, 1));
                int n2 = Integer.parseInt(fieldValue.substring(2));        
                switch(messageType) {
                    case "MT700":
                    case "MT707":
                    case "MT710":
                    case "MT720":
                    case "MT760":
                    case "MT767":
                        if (n1!=1 || n2<1 || n2>8 || n1>n2) {
                            result = false;
                        }
                        break;
                    case "MT701":
                    case "MT708":
                    case "MT711":
                    case "MT721":
                    case "MT761":
                    case "MT775":
                        if (n1<1 || n1>8  || n2<1 || n2>8 || n1>n2) {
                            result = false;
                        }
                        break;
                    case "MT759":
                        if (n1<0 || n1>8  || n2<0 || n2>8 || n1>n2) {
                            result = false;
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        
        Loggers.method().exit(LOG, result);
        return result;
    }

}
