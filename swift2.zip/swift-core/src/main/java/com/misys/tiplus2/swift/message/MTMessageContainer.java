package com.misys.tiplus2.swift.message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;

/**
 * This represents a de-constructed SWIFT message, holding data in a loose
 * representation of a SWIFT message, using tag names as keys to data, as well
 * as being able to store and errors associated with the message and the swift
 * message itself.
 *
 * @author DaiD1
 *
 */
public class MTMessageContainer extends IntermediateMessage {

    private static final long serialVersionUID = -2420369478798895425L;

    private static final Logger LOG = LoggerFactory.getLogger(MTMessageContainer.class);

    private Map<String, TagDataField> headerFieldsByKey = new HashMap<String, TagDataField>();
    private Map<String, TagDataField> dataFieldsByKey = new HashMap<String, TagDataField>();
    private Map<String, TagMarkerField> markerFieldsByKey = new HashMap<String, TagMarkerField>();
    // The size of list is the number of repeated data blocks within a message,
    // the key is the block name
    private Map<String, List<TagDataBlock>> dataBlocksByName = new HashMap<String, List<TagDataBlock>>();
    // include messages for MT798 SCORE messages/subMessages
    private Map<String, MTMessageContainer> embeddedMessagesByName = new HashMap<String, MTMessageContainer>();

    private String finMessage;
    private String messageType;
    private String reference;
    private TagDataField trn;
    private String description;
    private boolean isMerged;

    private List<FieldError> nonFieldErrors = new ArrayList<FieldError>();

    private List<MTMessageContainer> componentMessages;

    public MTMessageContainer(String type) {
        this.messageType = type;
    }

    public void addDataField(TagDataField dataField) {

        Loggers.method().enter(LOG, dataField);

        dataFieldsByKey.put(dataField.getKey(), dataField);

        Loggers.method().exit(LOG);
    }

    public void removeDataField(String key) {

        Loggers.method().enter(LOG, key);

        dataFieldsByKey.remove(key);

        Loggers.method().exit(LOG);
    }

    public void addMarkerField(TagMarkerField markerField) {

        Loggers.method().enter(LOG, markerField);

        markerFieldsByKey.put(markerField.getTag(), markerField);

        Loggers.method().exit(LOG);
    }

    public void removeMarkerField(String key) {

        Loggers.method().enter(LOG, key);

        markerFieldsByKey.remove(key);

        Loggers.method().exit(LOG);
    }

    public void addHeaderField(TagDataField headerField) {

        Loggers.method().enter(LOG, headerField);

        headerFieldsByKey.put(headerField.getTag(), headerField);

        Loggers.method().exit(LOG);
    }

    public void addDataBlock(String name, List<TagDataBlock> dataBlockList) {

        Loggers.method().enter(LOG, name, dataBlockList);

        dataBlocksByName.put(name, dataBlockList);

        Loggers.method().exit(LOG);
    }

    public void addDataBlock(String name, TagDataBlock dataBlock) {
        Loggers.method().enter(LOG, name, dataBlock);

        List<TagDataBlock> listOfTagDataBlock = dataBlocksByName.get(name);
        if (listOfTagDataBlock == null) {
            listOfTagDataBlock = new ArrayList<TagDataBlock>();
            addDataBlock(name, listOfTagDataBlock);
        }
        listOfTagDataBlock.add(dataBlock);

        Loggers.method().exit(LOG);
    }

    public TagDataField getHeaderField(String key) {

        Loggers.method().enter(LOG, key);
        TagDataField result = headerFieldsByKey.get(key);
        Loggers.method().exit(LOG, result);
        return result;
    }

    public TagDataField getDataFieldByKey(String key) {

        Loggers.method().enter(LOG, key);
        TagDataField result = null;
        if (key!=null) {
            if (key.endsWith("a")) {
                result = getOptionalDataField(key, null);
            } else {
                result = dataFieldsByKey.get(key);
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public TagDataField getDataField(String tag, String sequence) {

        Loggers.method().enter(LOG, tag, sequence);
        TagDataField result=null;
        if (tag!=null && sequence!=null) {
            if (tag.endsWith("a")) {
                result = getOptionalDataField(tag,sequence);
            } else {
                result = dataFieldsByKey.get(tag+"_"+sequence);
            }
        } else if (tag!=null) {
            result = getDataFieldByKey(tag);
        }
        
        Loggers.method().exit(LOG, result);
        return result;
    }
    
    public TagDataField getOptionalDataField(String tag, String sequence) {

        Loggers.method().enter(LOG, tag);
        TagDataField result=null;
        if (tag!=null && tag.endsWith("a")) {
            tag = tag.substring(0, tag.length()-1);
            for (Entry<String, TagDataField> entry : dataFieldsByKey.entrySet()) {
                TagDataField tagDataField = entry.getValue();
                if (tagDataField != null &&  tagDataField.getTag().startsWith(tag)){
                    if (sequence==null) {
                        result = tagDataField;
                        break;
                    } else if (sequence.equals(tagDataField.getSequence())) {
                        result = tagDataField;
                        break;
                    }
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public List<TagDataField> getTagDataFieldsFromTagDataBlock(String tag, String sequence){
        Loggers.method().enter(LOG, tag,sequence);
        List<TagDataField> result = null;
        if (tag!=null && !dataBlocksByName.isEmpty()) {
            for (Entry<String, List<TagDataBlock>> entry : dataBlocksByName.entrySet()) {
                List<TagDataBlock> blockList = entry.getValue();
                if (blockList != null && !blockList.isEmpty()) {
                    for (TagDataBlock tbk : blockList) {
                        if (tbk.getDataFields() != null) {
                            for (Entry<String, TagDataField> ent : tbk.getDataFields().entrySet()) {
                                TagDataField f = ent.getValue();
                                if (f != null && f.getTag().equals(tag)) {
                                    if (sequence==null||sequence.equals(f.getSequence())) {
                                        if (result == null) {
                                            result = new ArrayList<TagDataField>();
                                        }
                                        result.add(f);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    /**
     * Return the first tagDataField from DtaFeildByKeyby tag name
     * 
     * @param tag
     * @return
     */
    public TagDataField getDataFieldByTag(String tag) {

        Loggers.method().enter(LOG, tag);
        TagDataField result = null;
        if (tag != null) {
            for (Entry<String, TagDataField> entry : dataFieldsByKey.entrySet()) {
                TagDataField tagDataField = entry.getValue();
                if (tagDataField != null && tag.equals(tagDataField.getTag())) {
                    result = tagDataField;
                    break;
                }
            }
        }
        return result;
    }

    public TagMarkerField getMarkerField(String key) {

        Loggers.method().enter(LOG, key);
        TagMarkerField result = markerFieldsByKey.get(key);
        Loggers.method().exit(LOG, result);
        return result;
    }

    public List<TagDataBlock> getDataBlockList(String name) {

        Loggers.method().enter(LOG, name);
        List<TagDataBlock> result = dataBlocksByName.get(name);
        Loggers.method().exit(LOG, result);
        return result;
    }

    public boolean hasSequence(String sequenceName) {
        Loggers.method().enter(LOG, sequenceName);
        boolean result=false;
        
        if (sequenceName!=null) {
            for (Entry<String, TagDataField> entry : dataFieldsByKey.entrySet()) {
                TagDataField tagDataField = entry.getValue();
                if (sequenceName.equals(tagDataField.getSequence())) {
                    result = true;
                    break;
                }
            }
            
            if (!result) {
                
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }
    public Map<String, TagDataField> getHeaderFields() {
        return headerFieldsByKey;
    }

    public void setHeaderFields(Map<String, TagDataField> headFields) {
        headerFieldsByKey.putAll(headFields);
    }

    public Map<String, TagDataField> getDataFields() {
        return dataFieldsByKey;
    }

    public Map<String, TagMarkerField> getMarkerFields() {
        return markerFieldsByKey;
    }

    public Map<String, List<TagDataBlock>> getDataBlocksByName() {
        return dataBlocksByName;
    }

    public String getType() {

        Loggers.method().enter(LOG);
        String result = null;
        if (messageType != null) {
            result = messageType;
        } else {
            result = headerFieldsByKey.get(MTMessageConstant.B2_MESSAGE_TYPE_TAG).getValue();
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

    public String getDirection() {
        TagDataField dir = headerFieldsByKey.get(MTMessageConstant.B2_DIRECTION_TAG);
        return dir.getValue();
    }

    public String getServiceId() {
        TagDataField serviceId = headerFieldsByKey.get(MTMessageConstant.B1_SERVICE_ID_TAG);
        if (serviceId != null) {
            return serviceId.getValue();
        } else {
            if (messageType.equals("F21")) {
                return MTMessageConstant.B1_SERVICE_ID_ACK_VALUE;
            } else {
                return MTMessageConstant.B1_SERVICE_ID_FIN_VALUE;
            }
        }
    }

    public String getFINMessage() {
        return finMessage;
    }

    public void setFINMessage(String finMessage) {
        this.finMessage = finMessage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getTotalNumberOfValidationErrors() {

        Loggers.method().enter(LOG);
        int result = getNumberOfErrorsFromMessage(this);
        result += nonFieldErrors.size();
        Loggers.method().exit(LOG, result);
        return result;
    }

    /**
     * Get field validation errors of a message, but not including embedded and
     * components messages
     * 
     * @param message
     * @return
     */
    public int getNumberOfErrorsFromMessage(MTMessageContainer message) {

        Loggers.method().enter(LOG);
        int result = 0;

        if (!message.hasEmbeddedMessages()) {
            // FIN message
            if (message.getComponentMessages() == null || message.getComponentMessages().isEmpty()) {
                result = getNumberOfErrorsFromFieldmaps(message);
            } else {
                for (MTMessageContainer comp : message.getComponentMessages()) {
                    result += getNumberOfErrorsFromFieldmaps(comp);
                }
            }
        } else {
            // MT798Score message
            for (Entry<String, MTMessageContainer> entry : embeddedMessagesByName.entrySet()) {
                MTMessageContainer embeddedMsg = entry.getValue();
                result += getNumberOfErrorsFromMessage(embeddedMsg);
            }
        }
        Loggers.method().exit(LOG);
        return result;
    }

    private int getNumberOfErrorsFromFieldmaps(MTMessageContainer message) {

        Loggers.method().enter(LOG);
        int result = 0;
        for (Entry<String, TagDataField> entry : message.headerFieldsByKey.entrySet()) {
            TagDataField tdf = entry.getValue();
            if (tdf.getErrorDetails() != null && !tdf.getErrorDetails().isEmpty()) {
                result++;
            }
        }

        for (Entry<String, TagDataField> entry : message.dataFieldsByKey.entrySet()) {
            TagDataField tdf = entry.getValue();
            if (tdf.getErrorDetails() != null && !tdf.getErrorDetails().isEmpty()) {
                result++;
            }
        }

        for (Entry<String, TagMarkerField> entry : message.markerFieldsByKey.entrySet()) {
            TagMarkerField tdf = entry.getValue();
            if (tdf.getErrorDetails() != null && !tdf.getErrorDetails().isEmpty()) {
                result++;
            }
        }

        for (Entry<String, List<TagDataBlock>> entry : message.dataBlocksByName.entrySet()) {
            List<TagDataBlock> listOfDataBlocks = entry.getValue();

            if (listOfDataBlocks != null && listOfDataBlocks.size() > 0) {

                for (TagDataBlock tagDataBlock : listOfDataBlocks) {

                    for (Entry<String, TagDataField> ety : tagDataBlock.dataFields.entrySet()) {
                        TagDataField tdf = ety.getValue();
                        if (tdf.getErrorDetails() != null && !tdf.getErrorDetails().isEmpty()) {
                            result++;
                        }
                    }
                }
            }
        }
        Loggers.method().exit(LOG);
        return result;
    }

    public void addNonFieldError(FieldError nonfieldError) {

        Loggers.method().enter(LOG, nonfieldError);

        nonFieldErrors.add(nonfieldError);

        Loggers.method().exit(LOG);
    }

    public List<FieldError> getNonFieldErrors() {

        return this.nonFieldErrors;
    }

    public MTMessageContainer copy(boolean includeHeader) {

        Loggers.method().enter(LOG, includeHeader);

        MTMessageContainer result = flatCopy(this, includeHeader);

        if (componentMessages != null && !componentMessages.isEmpty()) {
            List<MTMessageContainer> cmpList = new ArrayList<MTMessageContainer>();
            for (MTMessageContainer msg : componentMessages) {
                MTMessageContainer compCopyMsg = flatCopy(msg, includeHeader);
                cmpList.add(compCopyMsg);
            }
            result.setComponentMessages(componentMessages);
        }

        if (hasEmbeddedMessages()) {
            for (Entry<String, MTMessageContainer> entry : embeddedMessagesByName.entrySet()) {
                String name = entry.getKey();
                MTMessageContainer embeddedMsg = entry.getValue();
                MTMessageContainer embCopyMsg = flatCopy(embeddedMsg, includeHeader);
                result.addEmbeddedMessage(name, embCopyMsg);
            }
        }

        Loggers.method().exit(LOG);
        return result;
    }

    private MTMessageContainer flatCopy(MTMessageContainer message, boolean includeHeader) {

        Loggers.method().enter(LOG, includeHeader);
        MTMessageContainer result = new MTMessageContainer(message.messageType);

        if (includeHeader) {
            for (Entry<String, TagDataField> entry : message.headerFieldsByKey.entrySet()) {
                result.addHeaderField(entry.getValue().copy());
            }
        }

        for (Entry<String, TagDataField> entry : message.dataFieldsByKey.entrySet()) {
            result.addDataField(entry.getValue().copy());
        }

        for (Entry<String, TagMarkerField> entry : message.markerFieldsByKey.entrySet()) {
            result.addMarkerField(entry.getValue().copy());
        }

        for (Entry<String, List<TagDataBlock>> entry : message.dataBlocksByName.entrySet()) {
            List<TagDataBlock> listOfDataBlocks = entry.getValue();
            if (listOfDataBlocks != null && listOfDataBlocks.size() > 0) {
                for (TagDataBlock tagDataBlock : listOfDataBlocks) {
                    result.addDataBlock(tagDataBlock.getName(), tagDataBlock.copy());
                }
            }
        }

        if (message.finMessage != null) {
            result.setFINMessage(finMessage);
        }
        if (message.description != null) {
            result.setDescription(description);
        }

        if (message.nonFieldErrors != null && !message.nonFieldErrors.isEmpty()) {
            for (FieldError fe : message.nonFieldErrors) {
                result.addNonFieldError(fe);
            }
        }

        result.setMerged(message.isMerged);

        Loggers.method().exit(LOG);
        return result;
    }

    public List<MTMessageContainer> getComponentMessages() {
        return componentMessages;
    }

    public void setComponentMessages(List<MTMessageContainer> componentMessages) {
        this.componentMessages = componentMessages;
    }

    public boolean hasEmbeddedMessages() {
        if (embeddedMessagesByName == null || embeddedMessagesByName.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }

    public void addEmbeddedMessage(String key, MTMessageContainer embeddedMessage) {
        if (embeddedMessagesByName != null) {
            this.embeddedMessagesByName.put(key, embeddedMessage);
        }
    }

    public boolean isMerged() {
        return isMerged;
    }

    public void setMerged(boolean isMerged) {
        this.isMerged = isMerged;
    }

    public void setDirection(String direction) {
        Loggers.method().enter(LOG, direction);
        TagDataField tagDirection = new TagDataField(MTMessageConstant.B2_DIRECTION_TAG, direction);
        headerFieldsByKey.put(tagDirection.getTag(), tagDirection);
        Loggers.method().exit(LOG);
    }

    public void setServiceId(String serviceId) {
        Loggers.method().enter(LOG, serviceId);
        TagDataField tagServiceId = new TagDataField(MTMessageConstant.B1_SERVICE_ID_TAG, serviceId);
        headerFieldsByKey.put(tagServiceId.getTag(), tagServiceId);
        Loggers.method().exit(LOG);
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public void setMessageType(String messageType) {

        this.messageType = messageType;
    }

    public TagDataField getTrn() {
        return trn;
    }

    public void setTrn(TagDataField trn) {
        this.trn = trn;
    }

    public MTMessageContainer findEmbeddedMessage(String name) {

        Loggers.method().enter(LOG, name);
        MTMessageContainer result = null;
        if (embeddedMessagesByName != null) {
            result = embeddedMessagesByName.get(name);
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

}
