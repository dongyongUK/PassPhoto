package com.misys.tiplus2.swift.adaptor.visitor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.MessageMapException;
import com.misys.tiplus2.swift.maps.MessageMapsLoader;
import com.misys.tiplus2.swift.maps.visitor.UnloadMTMessageContainerVisitor;
import com.misys.tiplus2.swift.message.MTMessageContainer;

/**
 * Set field or repeated field value to EnigmaSwiftPane
 *
 * @author DaiD1
 *
 */
public class UnloadToFieldEntryCollectionVisitor extends UnloadMTMessageContainerVisitor<FieldEntryCollection> {

	protected static final Logger LOG = LoggerFactory.getLogger(UnloadToFieldEntryCollectionVisitor.class);

	@Override
	public void setFieldInTarget(FieldEntryCollection target, String fieldName, String value) {
		Loggers.method().enter(LOG, fieldName, value);

		setPropertiesFieldValue(target, fieldName, value);
		Loggers.method().exit(LOG);

	}

	@Override
	public void setFieldInTarget(FieldEntryCollection target, int blockIndex, String fieldName, String value) {

		Loggers.method().enter(LOG, fieldName, value);

		setPropertiesFieldValue(target, FieldPropertiesHelper.convertRepeatedFieldName(fieldName, blockIndex), value);

		Loggers.method().exit(LOG);

	}

	private void setPropertiesFieldValue(FieldEntryCollection properties, String fieldPath, String value)
			throws MessageMapException {
		Loggers.method().enter(LOG, value, fieldPath);

		properties.setFieldEntryValue(fieldPath, value, false);

		Loggers.method().exit(LOG);
	}

	@Override
	public void setMarkerInTarget(FieldEntryCollection arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setEmbeddedInTarget(FieldEntryCollection arg0, MessageMapsLoader arg1, MTMessageContainer arg2,
			String arg3) {
		// TODO Auto-generated method stub

	}
}
