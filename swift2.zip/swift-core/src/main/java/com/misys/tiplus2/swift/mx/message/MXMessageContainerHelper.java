package com.misys.tiplus2.swift.mx.message;

import org.apache.commons.lang3.StringUtils;

import com.misys.tiplus2.swift.message.validation.rule.MessageRuleHelper;

/**
 * 
 * @author DaiD1
 *
 */
public class MXMessageContainerHelper {

    static final String INDENT_2="  ";
    public static String mtDateToMxDate(String value) {

        String result = null;
        if (value != null && !value.isEmpty() && isDigit(value)) {
            if (value.length() == 6) { // yymmdd
                value = "20" + value;
                result = value.substring(0, 4) + "-" + value.substring(4, 6) + "-" + value.substring(6);
            } else if (value.length() == 8) { // yyyymmdd
                result = value.substring(0, 4) + "-" + value.substring(4, 6) + "-" + value.substring(6);
            }
        }
        return result;
    }

    public static boolean isDigit(String value) {

        boolean result = false;
        if (value != null && !value.isEmpty()) {
            result = value.chars().allMatch(Character::isDigit);
        }
        return result;
    }

    public static String createMXDocwithEnvelop(String header, String document) {

        String result = null;
        if (header != null && document != null) {
            StringBuilder resultBd = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>").append("\n");
            resultBd.append("<Envelope xmlns=\"urn:swift:xsd:envelope\" ")
            .append("xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
            resultBd.append("\n");
            resultBd.append(reformat(header));
            resultBd.append(reformat(document));
            resultBd.append("</Envelope>");
            result = resultBd.toString();
        }
        return result;
    }
    
    public static String encludeEnvelop(String document, String type ) {

        String result = null;
        if (document != null) {
            if (type!=null && type.endsWith(".cov")) {
                int cut = type.indexOf(".cov");
                type = type.substring(0, cut);
            }
            StringBuilder resultBd = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>").append("\n");
            resultBd.append("<Envelope xmlns=\"urn:swift:xsd:envelope\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ")
            .append("xmlns:err=\"urn:swift:xsd:errors\" ")
            .append("xmlns:hdr=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.02\" ")
            .append("xmlns:doc=\"urn:iso:std:iso:20022:tech:xsd:").append(type).append("\" ")
            .append(">")
            .append("\n");
            resultBd.append(reformat(document));
            resultBd.append("</Envelope>");
            result = resultBd.toString();
        }
        return result;
    }
    
    public static String encludeEnvelop(String document) {

        String result = null;
        if (document != null && !document.contains("<Envelope") && !document.contains("</Envelope>")) {
            StringBuilder resultBd = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>").append("\n");
            resultBd.append("<Envelope xmlns=\"urn:swift:xsd:envelope\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">")
            .append("\n");
            resultBd.append(reformat(document));
            resultBd.append("</Envelope>");
            result = resultBd.toString();
        }
        return result;
    }
    
    public static boolean hasEnvelope(String message) {
     
        boolean result = true;
        
        if ( message != null && !message.contains("<Envelope") && !message.contains("</Envelope>")) {
           result = false;   
        }
        return result;
    }
    
    public static String combineMXDocs(String header, String document) {

        String result = null;
        if (header != null && document != null) {
            StringBuilder resultBd = new StringBuilder();
            resultBd.append(reformat(header));
            resultBd.append(reformat(document));
            result = resultBd.toString();
        }
        return result;
    }
    /**
     * Replace timezone "00:01" of XMLGregorianCalender in UTC "with 00:00"
     * 
     * @param text
     * @return
     */
    public static String replaveTimeZone0001(String text) {
        String result = text;
        
        if (!StringUtils.isEmpty(text)) {
           result = text.replace("+00:01</", "+00:00</");
        }
        return result;
    }
    
    
    public static String reformat(String text) {
     
        String result = null;
        if (text!=null) {
          String[] lines = MessageRuleHelper.splitLine(text);
          
          if (lines!=null) {
              StringBuilder txtBld = new StringBuilder();
              for (String line:lines) {
                if (!line.trim().startsWith("<?xml")) {
                    txtBld.append(INDENT_2).append(line);
                    txtBld.append("\n");
                } else {
                   line = line.trim();
                   int idx1 = line.lastIndexOf("?>");
                   int idx2 = line.lastIndexOf("<");
                   if (idx1<idx2) {
                       line=line.substring(idx1+2);
                       txtBld.append(INDENT_2).append(line);
                       txtBld.append("\n");
                   }
                }
              }
              result = txtBld.toString();
          }
        }
        
        return result;
    }
}
