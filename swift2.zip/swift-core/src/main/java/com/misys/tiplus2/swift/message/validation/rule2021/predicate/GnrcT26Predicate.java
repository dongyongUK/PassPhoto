package com.misys.tiplus2.swift.message.validation.rule2021.predicate;

import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
/**
 * general rule for SWIFT.T26 
 * @author DaiD1
 *
 */
public class GnrcT26Predicate implements Predicate<String[]> {

    private static final Logger LOG = LoggerFactory.getLogger(GnrcT26Predicate.class);

    @Override
    public boolean test(String... args) {
        // one element only which is a field value
        Loggers.method().enter(LOG);
        boolean result = true;
        if (args != null) {
            String fieldValue = args[0];
            if (fieldValue != null && !fieldValue.isEmpty()) {
                if (fieldValue.startsWith("/") || fieldValue.endsWith("/") || fieldValue.contains("//")) {
                    result = false;
                }
            }
        }
        Loggers.method().exit(LOG, result);
        return result;
    }

}
