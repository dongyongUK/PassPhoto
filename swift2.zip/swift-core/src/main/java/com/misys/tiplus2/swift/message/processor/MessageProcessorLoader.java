package com.misys.tiplus2.swift.message.processor;

public interface MessageProcessorLoader {
    MessageProcessor getMTMessageProcessor();
    MessageProcessor getMXMessageProcessor();
}
