package com.misys.tiplus2.swift.mx.message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.contract.AssertArgument;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.FieldError;
import com.misys.tiplus2.swift.message.IntermediateMessage;

/**
 * 
 * @author DaiD1
 *
 */
public class MXMessageContainer extends IntermediateMessage {

    private static final long serialVersionUID = 1L;

    private static final Logger LOG = LoggerFactory.getLogger(MXMessageContainer.class);

    private Map<String, FieldData> fieldDataByKey = new HashMap<String, FieldData>();
    private Map<String, List<Map<String, Object>>> listFieldByKey = new HashMap<String, List<Map<String, Object>>>();
    private MXMessageContainer businessAppHeader;
    private List<FieldError> nonFieldErrors = new ArrayList<FieldError>();
    private Map<String, FieldError> mandatoryNodeErrors = new HashMap<String, FieldError>();
    private Map<String, List<FieldData>> listErrorField = new HashMap<String, List<FieldData>>();

    // TRN
    private FieldData BizMsgId;

    // UETR or GrgnIUETR
    private String uetrOrOrgnIuetr;

    private String messageId;
    private String description;
    private String xmlMessage;
    private String xmlLongMessage;
    private String variation;

    public MXMessageContainer(String messageId) {

        Loggers.method().enter(LOG, messageId);
        this.messageId = messageId;
        Loggers.method().exit(LOG);
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Map<String, FieldData> getFieldDataByKey() {
        return fieldDataByKey;
    }

    public Map<String, List<Map<String, Object>>> getListFieldByKey() {
        return listFieldByKey;
    }

    public void setListFieldByKey(Map<String, List<Map<String, Object>>> newlistFieldByKey) {
        listFieldByKey = newlistFieldByKey;
    }

    public void addListField(String key, List<Map<String, Object>> listFieldData) {
        listFieldByKey.put(key, listFieldData);
    }

    public void addFieldData(FieldData fieldData) {

        Loggers.method().enter(LOG, fieldData);

        String path = fieldData.getPath();
        String tag = fieldData.getTag();
        if (path != null && tag != null) {
            fieldDataByKey.put(path + "." + tag, fieldData);
        }
        Loggers.method().exit(LOG);
    }

    public void addFieldData(String key, FieldData fieldData) {
        AssertArgument.notBlank(key, "key");

        Loggers.method().enter(LOG, key, fieldData);

        fieldDataByKey.put(key, fieldData);
        Loggers.method().exit(LOG);
    }

    public void addFieldData(String path, String tag, FieldData fieldData) {
        AssertArgument.notBlank(path, "path");
        AssertArgument.notBlank(tag, "tag");

        Loggers.method().enter(LOG, path, tag, fieldData);

        fieldDataByKey.put(path + "." + tag, fieldData);
        Loggers.method().exit(LOG);
    }

    public FieldData getField(String key) {
        AssertArgument.notBlank(key, "key");

        Loggers.method().enter(LOG, key);
        FieldData result = fieldDataByKey.get(key);
        Loggers.method().exit(LOG, result);
        return result;
    }

    public FieldData getField(String path, String tag) {
        AssertArgument.notBlank(path, "path");
        AssertArgument.notBlank(tag, "tag");

        Loggers.method().enter(LOG, path, tag);
        FieldData result = fieldDataByKey.get(path + "." + tag);
        Loggers.method().exit(LOG, result);
        return result;
    }

    public boolean isNotNull(String prePath) {
        AssertArgument.notBlank(prePath, "prePath");
        boolean result = false;

        if (prePath.startsWith("AppHdr.")) { //  BusinessApplication Header
            if (businessAppHeader!=null) {
                for (Entry<String, FieldData> entry : businessAppHeader.getFieldDataByKey().entrySet()) {
                    String key = entry.getKey();
                    FieldData fieldData = entry.getValue();
                    if (key.startsWith(prePath) && fieldData.getTagValue() != null) {
                        result = true;
                        return result;
                    }
                }
            } else {  // unit test only
                for (Entry<String, FieldData> entry : fieldDataByKey.entrySet()) {
                    String key = entry.getKey();
                    FieldData fieldData = entry.getValue();
                    if (key.startsWith(prePath) && fieldData.getTagValue() != null) {
                        result = true;
                        return result;
                    }
                }
            }
        }
        for (Entry<String, FieldData> entry : fieldDataByKey.entrySet()) {
            String key = entry.getKey();
            FieldData fieldData = entry.getValue();
            if (key.startsWith(prePath) && fieldData.getTagValue() != null) {
                result = true;
                break;
            }
        }
        
        if(result==false && !listFieldByKey.isEmpty()) {
            for (Entry<String, List<Map<String, Object>>> entry : listFieldByKey.entrySet()) {
                String key = entry.getKey();
                List<Map<String, Object>> mapList = entry.getValue();
                if (!mapList.isEmpty()) {
                    for (Map<String, Object> map : mapList) {
                        if (!map.isEmpty()) {
                            for (Entry<String, Object> etry2 : map.entrySet()) {
                                String k = etry2.getKey();
                                Object val = etry2.getValue();
                                if (k.startsWith(prePath) && val != null) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    public String contains(String part) {
        AssertArgument.notBlank(part, "part");

        String result = null;
        if (part.startsWith(".")) {
            for (Entry<String, FieldData> entry : fieldDataByKey.entrySet()) {
                String key = entry.getKey();
                FieldData fieldData = entry.getValue();
                if (key.contains(part) && fieldData.getTagValue() != null) {
                    result = fieldData.getPath();
                    break;
                }
            }

            if (result == null && !listFieldByKey.isEmpty()) {
                for (Entry<String, List<Map<String, Object>>> entry : listFieldByKey.entrySet()) {
                    String key = entry.getKey();
                    List<Map<String, Object>> mapList = entry.getValue();
                    if (!mapList.isEmpty()) {
                        for (Map<String, Object> map : mapList) {
                            if (!map.isEmpty()) {
                                for (Entry<String, Object> etry2 : map.entrySet()) {
                                    String k = etry2.getKey();
                                    Object val = etry2.getValue();
                                    if (k.contains(part) && val != null) {
                                        result = k;
                                        return result;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    public MXMessageContainer getBusinessAppHeader() {
        return businessAppHeader;
    }

    public void setBusinessAppHeader(MXMessageContainer appHeader) {

        if (appHeader != null) {
            if (this.businessAppHeader == null) {
                this.businessAppHeader = new MXMessageContainer(MXMessageConstant.APP_HEADER_ID);
            }
            this.businessAppHeader.getFieldDataByKey().putAll(appHeader.getFieldDataByKey());
        }
    }

    public String getXmlMessage() {
        return xmlMessage;
    }

    public void setXmlMessage(String xmlMessage) {
        this.xmlMessage = xmlMessage;
    }

    public String getXmlLongMessage() {
        return xmlLongMessage;
    }

    public void setXmlLongMessage(String xmlLongMessage) {
        this.xmlLongMessage = xmlLongMessage;
    }

    /**
     * get the first field with has tag= MsgId
     * 
     * @return
     */
    public FieldData findBizMsgId() {

        FieldData result = null;
        for (Entry<String, FieldData> item : fieldDataByKey.entrySet()) {
            String key = item.getKey();
            if (key.contains(MXMessageConstant.GROUP_HEADER) && key.endsWith(MXMessageConstant.DOT_MESSAGE_ID)) {
                result = item.getValue();
                break;
            } else if (key.contains(MXMessageConstant.ASSIGNMENT) && key.endsWith(MXMessageConstant.DOT_ID)) {
                result = item.getValue();
                break;
            }
        }
        return result;
    }

    public FieldData getBizMsgId() {
        return BizMsgId;
    }

    public void setBizMsgId(FieldData bizMsgId) {
        BizMsgId = bizMsgId;
    }

    public List<FieldData> getErrorFields() {

        List<FieldData> result = new ArrayList<FieldData>();

        for (Entry<String, FieldData> item : businessAppHeader.getFieldDataByKey().entrySet()) {
            FieldData field = item.getValue();
            if (field.getErrorCode() != null || field.getErrorDetails() != null) {
                result.add(field);
            }
        }

        for (Entry<String, FieldData> item : fieldDataByKey.entrySet()) {
            FieldData field = item.getValue();
            if (field.getErrorCode() != null || field.getErrorDetails() != null) {
                result.add(field);
            }
        }

        for (Entry<String, List<FieldData>> entry : listErrorField.entrySet()) {
            List<FieldData> listField = entry.getValue();
            if (!listField.isEmpty()) {
                result.addAll(listField);
            }
        }
        return result;
    }

    public void addNonFieldError(FieldError nonfieldError) {

        Loggers.method().enter(LOG, nonfieldError);

        nonFieldErrors.add(nonfieldError);

        Loggers.method().exit(LOG);
    }

    public List<FieldError> getNonFieldErrors() {

        return this.nonFieldErrors;
    }

    public void addMandatoryNodeError(String node, FieldError fieldError) {

        Loggers.method().enter(LOG, fieldError);

        mandatoryNodeErrors.put(node, fieldError);

        Loggers.method().exit(LOG);
    }

    public Map<String, FieldError> getMandatoryNodeErrors() {

        return this.mandatoryNodeErrors;
    }

    public Map<String, List<FieldData>> getListErrorField() {
        return listErrorField;
    }

    public void addListErrorField(String arrayKey, List<FieldData> listError) {
        listErrorField.put(arrayKey, listError);
    }

    public boolean isCover() {

        boolean result = false;

        if ("cov".equals(variation)) {
            result = true;
        }
        return result;
    }

    public String getVariation() {
        return variation;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public String getUetrOrOrgnIuetr() {
        return uetrOrOrgnIuetr;
    }

    public void setUetrOrOrgnIuetr(String uetrOrOrgnIuetr) {
        this.uetrOrOrgnIuetr = uetrOrOrgnIuetr;
    }
}
