package com.misys.tiplus2.swift.mx.message.mapping.rule;

import java.util.function.Predicate;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.rule.MessageRuleHelper;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * MT_TO_ MT_TO_MXPartyAccount MT_TO_MAXPartyNameandAddress
 * 
 * Format [/34x] 4*35x Fields 59
 * 
 * @author DaiD1
 *
 */
public class AccountAndAddress implements Predicate<RuleResult> {

    static final String ruleID = "pred.account.address.2";

    @Override
    public boolean test(RuleResult ruleResult) {
        boolean result = false;

        DataField mapField = ruleResult.getMapField();
        TagDataField tiField = ruleResult.getTiField();

        if (mapField == null || tiField == null) {
            return result;
        }

        String path = mapField.getPath();
        String tag = mapField.getTag();
        String[] tags = null;
        if (tag != null && tag.contains(":")) {
            tags = tag.split(":");
            if (tags.length > 1) {
                ruleResult.getMapField().setTag(tags[0]);
            }
        }

        String srcValue = tiField.getValue();
        String tgtValue = null;
        String key = null;

        if (srcValue == null) {
            return result;
        }

        String[] lines = MessageRuleHelper.splitLine(srcValue);

        if (lines[0].startsWith("/") && lines.length > 1) {
            MT2MXCustomerPartyTranslation.mt2mxPartyAccount(ruleResult, lines[0]);
        }

        if (tags != null && tags.length > 1) {
            ruleResult.getMapField().setTag(tags[1]);
        }
        String subTag = ruleResult.getMapField().getTag();

        int c = 1;
        while (c < lines.length) {
            tgtValue = lines[c];
            key = path + "." + subTag + ".PstlAr.AdrLine." + String.valueOf(c);
            ruleResult.addToMapValue(key, tgtValue);
            c++;
        }
        result = true;
        return result;
    }

}
