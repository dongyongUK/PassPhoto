package com.misys.tiplus2.swift.mx.message;

import java.io.Serializable;

/**
 * @author DaiD1
 *
 */
public class FieldDataError implements Serializable {

	private static final long serialVersionUID = 6606214782411453334L;

	private String path;
	private String tag;
	private String errorDetails;
	private int code;

	public FieldDataError(String path, String tag) {
		this.path = path;
		this.tag = tag;
	}

	public FieldDataError(String path, String tag, String errorDetails) {
		this.path = path;
		this.tag = tag;
		this.errorDetails = errorDetails;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
	
	
}
