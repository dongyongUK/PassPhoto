package com.misys.tiplus2.swift.message.validation.error.interpretation;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;

public class DescriptionPhrases {
    private static final Logger LOG = LoggerFactory.getLogger(DescriptionPhrases.class);

    public static final String swift_type_n_des = "digits";
    public static final String swift_type_d_des = "digits with decimal comma";
    public static final String swift_type_h_des = "uppercase hexadecimal";
    public static final String swift_type_a_des = "uppercase letters";
    public static final String swift_type_c_des = "uppercase alphanumeric characters";
    public static final String swift_type_e_des = "Space";
    public static final String swift_type_x_des = "valid SWIFT X characters";
    public static final String swift_type_y_des = "uppercase level A ISO 9735 character";
    public static final String swift_type_z_des = "valid SWIFT Z characters";
    public static final String swift_type_L_des = "new line";

    public static final String swift_optional = "Optional";

    public static final String swift_FIELD_FORMAT_ERROR = "This field is incorrectly formatted or has invalid SWIFT character, the correct format is:";
    public static final String swift_MANDATORY_FIELD_MISSING = "This mandatory field is empty.";
    public static final String swift_NETWORK_RULE_ERROR = "The following Network rule error was generated for this field:";
    public static final String swift_INVALID_CODE_ERROR = "This field contains an invalid code:";
    public static final String swift_NO_DESCRIPTION = "No Description for: ";
    public static final String swift_NO_SPECIFIED_ERROR = "No specified error: ";
    public static final String swift_INVALID_X_CHARACTER_ERROR = "This field contains one or more character(s) that are not in the permitted SWIFT X character set: a-zA-Z0-9/?:().,'+- ";
    public static final String swift_INVALID_Z_CHARACTER_ERROR = "This field contains one or more character(s) that are not in the permitted SWIFT Z character set: - a-zA-Z0-9 .,()/='+:?!\"%&*<>;{@#_";
    public static final String swift_NO_COLON_OR_HYPHEN = "All lines (apart from the first) must not start with a colon or hyphen";

    public static final String swift_MAXIMUM_LINES = "the maximum number of lines is ";
    public static final String swift_MAXIMUM_LINE_LENGTH = "each line must not exceed ";
    public static final String swift_MAXIMUM = "a maximum of";
    public static final String swift_MINIMUM = "a minimum of";
    public static final String swift_FIXED_LENGTH = "an exact number of";
    public static final String swift_SLASH_MAXIMUM = "a / followed by a maximum of";
    public static final String swift_SLASH_MINIMUM = "a / followed by a minimum of";
    public static final String swift_SLASH_FIXED_LENGTH = "a / followed by an exact number of";
    public static final String swift_NEW_LINE = System.getProperty("line.separator");

    public static final String FIELD_FORMAT_ERROR="Field format error";
    
    public static List<String> getFields() {
        Loggers.method().enter(LOG);

        List<String> result = new ArrayList<String>();
        try {
            Class cl = Class
                    .forName("com.misys.tiplus2.meridian.swiftdriver.processor.errorhandling.DescriptionPhrases");
            Field fields[] = cl.getDeclaredFields();
            for (Field field : fields) {
                String name = field.getName();
                if (name.startsWith("swift_")) result.add(field.getName());
            }
        } catch (Exception e) {
            // ExceptionPublisher.getInstance().suppressed(e, LOG,
// "Failed in getFields");
        }

        Loggers.method().exit(LOG, result);
        return result;
    }
}
