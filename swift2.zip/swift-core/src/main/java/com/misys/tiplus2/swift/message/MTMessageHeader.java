package com.misys.tiplus2.swift.message;

public class MTMessageHeader {

    public enum Block1 {
        ApplicationId, ServiceId, LogicalTerminalAddress, Session, Sequence
    }

    public enum Block2_Incoming {
        InputOutputIdentifier, MessageType, ReceiverAddress, Priority, DeliveryMonitoring, ObsolescencePeriod
    }

    public enum Block2_Outgoing {
        InputOutputIdentifier, MessageType, InputTime, MIR, OutputDate, OutputTime, Priority
    }

    public enum Block3 {
        T103,T108,T111,T113,T119,T121
    }

    public enum Block5 {
        Trailer
    }

    public static boolean inBlock1(String tag) {

        boolean result = false;

        try {
            Block1 b1tag = Enum.valueOf(Block1.class, tag);

            switch (b1tag) {
            case ApplicationId:
                result = true;
                break;
            case ServiceId:
                result = true;
                break;
            case LogicalTerminalAddress:
                result = true;
                break;
            case Session:
                result = true;
                break;
            case Sequence:
                result = true;
                break;
            default:
                break;
            }
        } catch (IllegalArgumentException e) {
            ;
        }
        return result;
    }

    public static int getBlock1Index(String tag) {
        return Block1.valueOf(tag).ordinal();
    }
    
    public static String getBlock1Name(int i){
        return Block1.values()[i].name();
    }
    
    public static boolean inBlock2Incoming(String tag) {

        boolean result = false;

        try {
            Block2_Incoming b2tag = Enum.valueOf(Block2_Incoming.class, tag);

            switch (b2tag) {
            case InputOutputIdentifier:
                result = true;
                break;
            case MessageType:
                result = true;
                break;
            case ReceiverAddress:
                result = true;
                break;
            case Priority:
                result = true;
                break;
            case DeliveryMonitoring:
                result = true;
                break;
            case ObsolescencePeriod:
                result = true;
                break;
            default:
                break;
            }
        } catch (IllegalArgumentException e) {
            ;
        }
        return result;
    }

    public static int getBlock2IncomingIndex(String tag) {
        return Block2_Incoming.valueOf(tag).ordinal();
    }
    
    public static String getBlock2IncomingName(int i){
        return Block2_Incoming.values()[i].name();
    }
    
    public static boolean inBlock2Outgoing(String tag) {

        boolean result = false;

        try {
            Block2_Outgoing b2tag = Enum.valueOf(Block2_Outgoing.class, tag);

            switch (b2tag) {
            case InputOutputIdentifier:
                result = true;
                break;
            case MessageType:
                result = true;
                break;
            case InputTime:
                result = true;
                break;
            case MIR:
                result = true;
                break;
            case OutputDate:
                result = true;
                break;
            case OutputTime:
                result = true;
                break;
            case Priority:
                result = true;
                break;
            default:
                break;
            }
        } catch (IllegalArgumentException e) {
            ;
        }
        return result;
    }

    public static int getBlock2OutgoingIndex(String tag) {
        return Block2_Outgoing.valueOf(tag).ordinal();
    }
    
    public static String getBlock2OutgoingName(int i){
        return Block2_Outgoing.values()[i].name();
    }
    
    public static boolean inBlock3(String tag) {

        boolean result = false;
        tag = "T" + tag.trim();

        try {
            Block3 b3tag = Enum.valueOf(Block3.class, tag);

            switch (b3tag) {
            case T103:
                result = true;
                break;
            case T113:
                result = true;
                break;
            case T108:
                result = true;
                break;
            case T111:
                result = true;
                break;
            case T121:
                result = true;
                break;
            case T119:
                result = true;
                break;
            default:
                break;
            }
        } catch (IllegalArgumentException e) {
            ;
        }
        return result;
    }

    public static int getBlock3Index(String tag) {
        return Block3.valueOf(tag).ordinal();
    }
    
    public static String getBlock3Name(int i){
        return Block3.values()[i].name();
    }
    
    public static boolean inBlock5(String tag) {

        boolean result = false;
        try {
            Block5 b5tag = Enum.valueOf(Block5.class, tag);

            switch (b5tag) {
            case Trailer:
                result = true;
                break;
            default:
                break;
            }
        } catch (IllegalArgumentException e) {
            ;
        }
        return result;
    }
    
    public static String getBlock5Name(int i){
        return Block5.values()[i].name();
    }
    
    public static int getHeaderBlockIn(String header){
        
        int result = getHeaderBlock(header);
        
        if (result==0){
            if (inBlock2Incoming(header)){
                result = 2;
            }
        }
        return result;
    }
    
    public static int getHeaderBlockOut(String header){
        
        int result = getHeaderBlock(header);
        
        if (result==0){
            if (inBlock2Outgoing(header)){
                result = 2;
            }
        }
        return result;
    }

    private static int getHeaderBlock(String header){
        
        int result = 0;
        if (inBlock1(header)){
            result = 1;
        } else if (inBlock3(header)){
            result = 3;
        } else if (inBlock5(header)){
            result = 5;
        }
        return result;
    }
}
