package com.misys.tiplus2.swift.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.processor.MessageProcessorException;

/**
 * @author DaiD1
 *
 */
public class MT798ScoreFINMessageHelper {

	private static final Logger LOG = LoggerFactory.getLogger(MT798ScoreFINMessageHelper.class);

	public static String extractMT798(String finMessage) {

		Loggers.method().enter(LOG, finMessage);
		String result = null;

		try {
			int index = finMessage.indexOf(MTMessageConstant.TAG77E);
			if (index != -1) {
				result = finMessage.substring(0, index + MTMessageConstant.TAG77E.length());
				result = result.replace("}{2:O798", "}{2:O198");
				result = result + MTMessageConstant.BLOCK4_END;
			}
		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", finMessage);
			throw new MessageProcessorException(e);
		}
		Loggers.method().exit(LOG, result);
		return result;
	}

	public static String extractIndexMessage(String finMessage) {

		Loggers.method().enter(LOG, finMessage);
		String result = extractDetailsMessage(finMessage, null);

		Loggers.method().exit(LOG, result);

		return result;
	}

	public static String extractDetailsMessage(String finMessage, String refTag) {

		Loggers.method().enter(LOG, finMessage);
		String result = null;

		try {
			finMessage = FINMessageHelper.normalize(finMessage);
			int index = finMessage.indexOf(MTMessageConstant.WINDOWS_CRLF + MTMessageConstant.TAG20);

			if (index > 0) {
				result = finMessage.substring(0, index - 1);

				String subType = extractSubType(finMessage);

				index = finMessage.indexOf(MTMessageConstant.TAG77E);
				if (index != -1) {
					String second = finMessage.substring(index + MTMessageConstant.TAG77E.length());

					if (refTag != null && !refTag.isEmpty()) {
						refTag = refTag.trim();
						index = second.indexOf(refTag);
						second = second.substring(index + refTag.length());
						index = second.indexOf(MTMessageConstant.WINDOWS_CRLF);
						second = MTMessageConstant.WINDOWS_CRLF + second.substring(index + 2);
					}

					result = result + second;

					result = result.replace("}{2:O798", "}{2:O" + subType);
				}
			}
		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", finMessage);
			throw new MessageProcessorException(e);
		}
		Loggers.method().exit(LOG, result);

		return result;
	}

	public static String extractSubType(String finMessage) {

		Loggers.method().enter(LOG, finMessage);
		String result = null;

		try {
			finMessage = FINMessageHelper.normalize(finMessage);
			int index1 = finMessage.indexOf(MTMessageConstant.TAG12);
			if (index1 != -1) {
				int index2 = finMessage.indexOf(MTMessageConstant.WINDOWS_CRLF + MTMessageConstant.TAG77E);
				if (index2 != -1) {
					result = finMessage.substring(index1 + MTMessageConstant.TAG12.length(), index2);
				}
			}
		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", finMessage);
			throw new MessageProcessorException(e);
		}

		Loggers.method().exit(LOG, result);

		return result;
	}

	public static String getHeader(String finMessage) {
		Loggers.method().enter(LOG, finMessage);
		String result = null;

		int index = finMessage.indexOf(MTMessageConstant.BLOCK4_START);

		result = finMessage.substring(0, index);
		Loggers.method().exit(LOG, result);

		return result;

	}

	/**
	 * Get embedded message after 77E
	 * 
	 * @param value77E
	 * @param refTag
	 * @return
	 */
	public static String getEmbeddedFINMessage(String value77E, String refTag) {

		Loggers.method().enter(LOG, value77E);
		String result = null;

		try {
			if (refTag != null && !refTag.isEmpty()) {
				refTag = refTag.trim();
				value77E = FINMessageHelper.normalize(value77E);
				int index = value77E.indexOf(refTag);
				value77E = value77E.substring(index + refTag.length());
				index = value77E.indexOf(MTMessageConstant.WINDOWS_CRLF);
				value77E = MTMessageConstant.WINDOWS_CRLF + value77E.substring(index + 2);
				if (value77E.startsWith(MTMessageConstant.WINDOWS_CRLF)) {
					value77E = value77E.substring(MTMessageConstant.WINDOWS_CRLF.length());
				}
			}

			if (value77E.startsWith(MTMessageConstant.WINDOWS_CRLF)) {
				value77E = value77E.substring(2);
			}
			result = value77E;

		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", value77E);
			throw new MessageProcessorException(e);
		}
		Loggers.method().exit(LOG, result);

		return result;
	}

	public static String getEmbeddedFINMessage(String value77E) {

		Loggers.method().enter(LOG, value77E);
		String result = null;

		String refTag = getFirstReference(value77E);
		result = getEmbeddedFINMessage(value77E, refTag);

		Loggers.method().exit(LOG, result);

		return result;
	}

	public static String getFirstReference(String value77E) {

		String result = null;
		String TAG21A = ":21A:";
		String TAG21P = ":21P:";
		int index1 = value77E.indexOf(TAG21A);
		int index2 = value77E.indexOf(TAG21P);

		if (index1 >= 0 && index2 < 0) {
			return TAG21A;
		}

		if (index1 < 0 && index2 >= 0) {
			return TAG21P;
		}

		if (index1 >= 0 && index2 > 0 && index2 > index1) {
			return TAG21A;
		}

		if (index1 > 0 && index2 >= 0 && index1 > index2) {
			return TAG21P;
		}

		return result;
	}

	public static String getSequence(String value77E) {
		Loggers.method().enter(LOG, value77E);
		String result = null;
		try {
			value77E = FINMessageHelper.normalize(value77E);
			int index = value77E.indexOf(MTMessageConstant.TAG27A);
			if (index > 0) {
				result = value77E.substring(index + MTMessageConstant.TAG27A.length());
				index = result.indexOf(MTMessageConstant.WINDOWS_CRLF);
				result = result.substring(0, index);
			}
		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", value77E);
			throw new MessageProcessorException(e);
		}
		Loggers.method().exit(LOG, result);
		return result;

	}

	public static String setSequence(String value77E, String newValue) {
		Loggers.method().enter(LOG, value77E, newValue);
		String result = null;
		try {
			value77E = FINMessageHelper.normalize(value77E);
			int index = value77E.indexOf(MTMessageConstant.TAG27A);
			if (index > 0) {
				String oldValue = value77E.substring(index + MTMessageConstant.TAG27A.length());
				index = oldValue.indexOf(MTMessageConstant.WINDOWS_CRLF);
				oldValue = oldValue.substring(0, index);
				result = value77E.replaceFirst(MTMessageConstant.TAG27A + oldValue,
						MTMessageConstant.TAG27A + newValue);
			}
		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", value77E);
			throw new MessageProcessorException(e);
		}
		Loggers.method().exit(LOG, result);
		return result;

	}

	public static String getReferenceTag(String value77E) {

		Loggers.method().enter(LOG, value77E);
		String result = null;

		try {
			value77E = FINMessageHelper.normalize(value77E);
			int index = value77E.indexOf(MTMessageConstant.TAG27A);

			if (index != -1) {
				result = value77E.substring(index + MTMessageConstant.TAG27A.length());
				index = result.indexOf(MTMessageConstant.WINDOWS_CRLF);
				if (index!=-1) {
					result = result.substring(index + 2);
					index = result.indexOf(MTMessageConstant.TAG_DELIMITER);
					if (index!=-1) {
						result = result.substring(index);
						index = result.indexOf(MTMessageConstant.TAG_DELIMITER, 2);
						if (index!=-1) {
							result = result.substring(1, index);
							if (result == null || !result.startsWith("21") || result.trim().length() != 3) {
								throw new Exception("invalid reference tag");
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", value77E);
			throw new MessageProcessorException(e);
		}
		Loggers.method().exit(LOG, result);

		return result;
	}

	public static String getReferenceValue(String value77E) {

		Loggers.method().enter(LOG, value77E);
		String result = null;

		try {
			value77E = FINMessageHelper.normalize(value77E);
			int index = value77E.indexOf(MTMessageConstant.TAG27A);
			if (index != -1) {
				result = value77E.substring(index + MTMessageConstant.TAG27A.length());
				index = result.indexOf(MTMessageConstant.WINDOWS_CRLF);
				if (index != -1) {
					result = result.substring(index + 2);
					index = result.indexOf(MTMessageConstant.TAG_DELIMITER);
					if (index != -1) {
						result = result.substring(index);
						index = result.indexOf(MTMessageConstant.TAG_DELIMITER, 2);
						if (index != -1) {
							int end = result.indexOf(MTMessageConstant.WINDOWS_CRLF, 2);
							result = result.substring(index + 1, end);
						}
					}
				}
			}
		} catch (Exception e) {
			Loggers.general().error(LOG, "Message format error : ", value77E);
			throw new MessageProcessorException(e);
		}
		Loggers.method().exit(LOG, result);

		return result;
	}

	public static String getFrom77E(String finMessage) {

		Loggers.method().enter(LOG, finMessage);
		String result = null;
		finMessage = FINMessageHelper.normalize(finMessage);
		if (finMessage != null && !finMessage.isEmpty()) {
			int begin = finMessage.indexOf(MTMessageConstant.TAG77E);
			int end = finMessage.indexOf(MTMessageConstant.BLOCK4_END);
			result = finMessage.substring(begin, end);
		}

		Loggers.method().exit(LOG, result);
		return result;
	}

	public static String getFromMT798Tag20(String finMessage) {

		Loggers.method().enter(LOG, finMessage);
		String result = null;
		finMessage = FINMessageHelper.normalize(finMessage);
		if (finMessage != null && !finMessage.isEmpty() && finMessage.contains(MTMessageConstant.TAG20)) {
			int begin = finMessage.indexOf(MTMessageConstant.TAG20);
			int end = finMessage.indexOf(MTMessageConstant.BLOCK4_END);
			result = finMessage.substring(begin, end);
		}

		Loggers.method().exit(LOG, result);
		return result;
	}
	
	public static String getFirstField26E(String finMessage) {

		Loggers.method().enter(LOG, finMessage);
		String result = null;
		finMessage = FINMessageHelper.normalize(finMessage);
		if (finMessage != null && !finMessage.isEmpty() && finMessage.contains(MTMessageConstant.TAG26E)) {
			int begin = finMessage.indexOf(MTMessageConstant.TAG26E);
			int end = finMessage.indexOf(MTMessageConstant.WINDOWS_CRLF, begin+5);
			result = finMessage.substring(begin+5, end);
		}

		Loggers.method().exit(LOG, result);
		return result;
	}

	public static String getSequenceFrom77E(String value77E) {
		Loggers.method().enter(LOG, value77E);
		String result = null;

		value77E = FINMessageHelper.normalize(value77E);
		int index = value77E.indexOf(MTMessageConstant.TAG27A);
		if (index != -1) {
			result = value77E.substring(index + MTMessageConstant.TAG27A.length());
			index = result.indexOf(MTMessageConstant.WINDOWS_CRLF);
			if (index != -1) {
				result = result.substring(0, index);
			}
		}
		Loggers.method().exit(LOG, result);
		return result;

	}

	public static String getLastSequence(String finMessage) {
		Loggers.method().enter(LOG, finMessage);
		String result = null;

		finMessage = FINMessageHelper.normalize(finMessage);
		int index = finMessage.lastIndexOf(MTMessageConstant.TAG27A);
		if (index > 0) {
			result = finMessage.substring(index + MTMessageConstant.TAG27A.length());
			index = result.indexOf(MTMessageConstant.WINDOWS_CRLF);
			if (index != -1) {
				result = result.substring(0, index);
			}
		}
		Loggers.method().exit(LOG, result);
		return result;

	}

	public static String getSequenceNumber(String sequence) {

		String result = null;

		if (sequence != null && sequence.contains("/")) {
			int index = sequence.indexOf("/");
			result = sequence.substring(0, index);
		}
		Loggers.method().exit(LOG, result);
		return result;
	}

	public static String getTotalNumbderFromSequence(String sequence) {

		Loggers.method().enter(LOG, sequence);
		String result = null;

		if (sequence.contains("/")) {
			int index = sequence.indexOf("/");
			result = sequence.substring(index + 1);

		}
		Loggers.method().exit(LOG, result);
		return result;
	}

}
