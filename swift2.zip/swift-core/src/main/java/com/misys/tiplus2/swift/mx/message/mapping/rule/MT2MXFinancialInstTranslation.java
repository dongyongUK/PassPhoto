package com.misys.tiplus2.swift.mx.message.mapping.rule;

import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * MT to MX Financial Institution translation Rules
 * 
 * @author DaiD1
 *
 */
public class MT2MXFinancialInstTranslation {

    public static void mt2mxFinancialInstAcct(RuleResult ruleResult, String value) {

        String tgtValue;
        String key;
        String tag;
        
        if (ruleResult != null && ruleResult.getMapField() != null ) {
            String path = ruleResult.getMapField().getPath();
            String subTag = ruleResult.getMapField().getTag();
            if (value.startsWith("//CH")) {
                tag = subTag+".Id.Othr.SchmeNm.Cd";
                key = path + "." + tag;
                tgtValue = "CUID";
                ruleResult.addToMapValue(key, tgtValue);
                
                tag = subTag+".Id.Othr.id";
                key = path + "." + tag;
                tgtValue = value.substring(4);
                ruleResult.addToMapValue(key, tgtValue);

            } else if (value.startsWith("/C/")) {
                tgtValue = value.substring(3);
                tag = subTag+".Id.Othr.Id";
                key = path + "." + tag;
                ruleResult.addToMapValue(key, tgtValue);
            } else if (value.startsWith("/D/")) {
                tgtValue = value.substring(3);
                tag = subTag+".Id.Othr.Id";
                key = path + "." + tag;
                ruleResult.addToMapValue(key, tgtValue);
            } else if (value.startsWith("/")){
                tgtValue = value.substring(1);
                tag = subTag+".Id.Othr.Id";
                key = path + "." + tag;
                ruleResult.addToMapValue(key, tgtValue); 
           }
        }
    }

    public static void mt2mxBICFI(RuleResult ruleResult, String value) {
       
        String tgtValue;
        String key;

        if (ruleResult != null && ruleResult.getMapField() != null ) {
            String path = ruleResult.getMapField().getPath();
            String tag = ruleResult.getMapField().getTag();
            
            tgtValue = value;
            tag = tag+".FinInstnId.BICFI";
            key = path + "." + tag;
            ruleResult.addToMapValue(key, tgtValue); 
        }
    }
}
