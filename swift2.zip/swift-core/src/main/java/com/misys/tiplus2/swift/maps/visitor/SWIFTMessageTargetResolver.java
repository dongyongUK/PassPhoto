package com.misys.tiplus2.swift.maps.visitor;

/**
 * This interface provides the ability to create/retrieve a target object based
 * on the required message type.
 *
 * @author DaiD1
 *
 */
public interface SWIFTMessageTargetResolver {

    Object createTarget(String type);

}
