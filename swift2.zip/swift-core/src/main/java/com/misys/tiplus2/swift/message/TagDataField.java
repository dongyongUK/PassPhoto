package com.misys.tiplus2.swift.message;

import java.io.Serializable;

/**
 *
 * @author DaiD1
 *
 */

public class TagDataField implements Serializable {

    private static final long serialVersionUID = 2949604856891652108L;

    private String tag;
    private String sequence;
    private String value;
    private String characterSet;
    private boolean multiline;
    private int width;
    private int lines;
    private int multilineOffset;
    private boolean mandatory;
    private String description;
    private String errorDetails;
    private String errorCode;
    private int blockNumber;

    public TagDataField(String tag) {
        this.tag = tag;
    }

    public TagDataField(String tag, String value) {
        this.tag = tag;
        this.value = value;
    }
    
    public TagDataField(String tag, String sequence, String value) {
        this.tag = tag;
        this.sequence = sequence;
        this.value = value;
    }

    public String getKey() {
        String key = null;
        if (tag!=null && sequence!=null) {
            key= tag+"_"+sequence;
        } else if (tag!=null) {
            key= tag; 
        }
        return key;
    }

    public String getTag() {
       return tag;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCharacterSet() {
        return characterSet;
    }

    public void setCharacterSet(String characterSet) {
        this.characterSet = characterSet;
    }

    public boolean isMultiline() {
        return multiline;
    }

    public void setMultiline(boolean multiline) {
        this.multiline = multiline;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getLines() {
        return lines;
    }

    public void setLines(int lines) {
        this.lines = lines;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }
    
    public int getMultilineOffset() {
        return multilineOffset;
    }


    public void setMultilineOffset(int multilineOffset) {
        this.multilineOffset = multilineOffset;
    }
    
    public boolean isMandatory() {
        return mandatory;
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory = mandatory;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public int getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(int blockNumber) {
        this.blockNumber = blockNumber;
    }

    public TagDataField copy() {
        TagDataField result = new TagDataField(this.tag, this.sequence, this.value);
        result.setCharacterSet(characterSet);
        result.setMultiline(multiline);
        result.setWidth(width);
        result.setLines(lines);
        result.setMandatory(mandatory);
        result.setMultilineOffset(multilineOffset);
        result.setDescription(description);
        result.setErrorDetails(errorDetails);
        result.setErrorDetails(errorCode);
        result.setBlockNumber(blockNumber);
        return result;
    }
}
