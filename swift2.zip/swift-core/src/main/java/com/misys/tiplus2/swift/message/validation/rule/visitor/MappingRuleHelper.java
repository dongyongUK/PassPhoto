package com.misys.tiplus2.swift.message.validation.rule.visitor;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.misys.tiplus2.swift.message.validation.rule.RuleResult;
import com.misys.tiplus2.swift.mx.message.MXMessageFieldHelper;

/**
 * 
 * @author DaiD1
 *
 */
public class MappingRuleHelper {

    public static final String INTERVAL_SIGN = "-";
    public static final String LINE_RANGE_SIGN = ":";

    public static boolean isDigit(String value) {

        boolean result = false;
        try {
            Integer.parseInt(value);
            result = true;
        } catch (NumberFormatException e) {
            ;
        }
        return result;
    }

    public static void equalCheck(RuleResult ruleResult, String value1, String value2) {

        if (value1 != null && !value1.isEmpty()) {
            if (value1.equals(value2)) {
                ruleResult.setLogicalValue(true);
            } else {
                ruleResult.setLogicalValue(false);
            }
        }
    }

    public static boolean isInterval(String value) {

        boolean result = false;

        if (value != null && value.contains(INTERVAL_SIGN)) {
            result = true;
        }
        return result;
    }

    public static boolean isLineRange(String value) {

        boolean result = false;

        if (value != null && value.contains(LINE_RANGE_SIGN)) {
            result = true;
        }
        return result;
    }

    /**
     * In the case of subIndex is a interval
     * 
     * @param ruleResult
     * @param value
     * @param srcValue
     * @param interval
     */
    public static void checkIntervalValue(RuleResult ruleResult, String value, String srcValue, String[] interval) {

        if (interval != null && interval.length == 2) {
            String begin = interval[0];
            String end = interval[1];
            if (MappingRuleHelper.isDigit(begin) && MappingRuleHelper.isDigit(end)) {
                int startIdx = Integer.parseInt(begin);
                int endIdx = Integer.parseInt(end);
                if (srcValue != null) {
                    srcValue = srcValue.substring(startIdx - 1, endIdx);
                    MappingRuleHelper.equalCheck(ruleResult, value, srcValue);
                }
            } else {
                int startIdx = srcValue.indexOf(begin);
                int endIdx = srcValue.indexOf(end, startIdx + 1);
                if (srcValue != null) {
                    srcValue = srcValue.substring(startIdx, endIdx + end.length());
                    MappingRuleHelper.equalCheck(ruleResult, value, srcValue);
                }
            }
        }
    }

    /**
     * In the case of subIndex is a single value; a digit, or single char
     * 
     * @param ruleResult
     * @param subValueIndex
     * @param value
     * @param srcValue
     */
    public static void checkIndexValue(RuleResult ruleResult, String subValueIndex, String value, String srcValue) {
        if (MappingRuleHelper.isDigit(subValueIndex)) {
            int indx = Integer.parseInt(subValueIndex);
            srcValue = srcValue.substring(indx);
            MappingRuleHelper.equalCheck(ruleResult, value, srcValue);
        } else {
            int indx = srcValue.indexOf(subValueIndex);
            if (indx != -1) {
                srcValue = srcValue.substring(indx);
                MappingRuleHelper.equalCheck(ruleResult, value, srcValue);
            }
        }
    }

    public static void existIntervalValue(RuleResult ruleResult, String srcValue, String[] interval) {

        if (interval != null && interval.length == 2) {
            String begin = interval[0];
            String end = interval[1];
            if (MappingRuleHelper.isDigit(begin) && MappingRuleHelper.isDigit(end)) {
                int startIdx = Integer.parseInt(begin);
                int endIdx = Integer.parseInt(end);
                if (srcValue != null) {
                    if ((startIdx < endIdx) && (endIdx <= srcValue.length())) {
                        ruleResult.setLogicalValue(true);
                    } else {
                        ruleResult.setLogicalValue(false);
                    }
                }
            } else {
                int startIdx = srcValue.indexOf(begin);
                int endIdx = srcValue.indexOf(end, startIdx + 1);
                if (srcValue != null) {
                    if ((startIdx < endIdx) && (endIdx <= srcValue.length())) {
                        ruleResult.setLogicalValue(true);
                    } else {
                        ruleResult.setLogicalValue(false);
                    }
                }
            }
        }
    }

    public static void existIndexValue(RuleResult ruleResult, String subValueIndex, String srcValue) {
        if (MappingRuleHelper.isDigit(subValueIndex)) {
            int indx = Integer.parseInt(subValueIndex);
            if (indx > srcValue.length()) {
                ruleResult.setLogicalValue(false);
            } else {
                ruleResult.setLogicalValue(true);
            }
        } else {
            int indx = srcValue.indexOf(subValueIndex);
            if (indx == -1) {
                ruleResult.setLogicalValue(false);
            } else {
                ruleResult.setLogicalValue(true);
            }
        }
    }

    /**
     * In the case of subIndex is a interval
     * 
     * @param ruleResult
     * @param key
     * @param srcValue
     * @param interval
     */
    public static void setIntervalValue(RuleResult ruleResult, String key, String srcValue, String[] interval) {

        if (interval != null && interval.length == 2) {
            String begin = interval[0];
            String end = interval[1];
            if (MappingRuleHelper.isDigit(begin) && MappingRuleHelper.isDigit(end)) {
                int startIdx = Integer.parseInt(begin);
                int endIdx = Integer.parseInt(end);
                if (srcValue != null) {
                    srcValue = srcValue.substring(startIdx - 1, endIdx);
                    ruleResult.addToMapValue(key, srcValue);
                }
            } else {
                int startIdx = srcValue.indexOf(begin);
                int endIdx = srcValue.indexOf(end, startIdx + 1);
                if (srcValue != null) {
                    srcValue = srcValue.substring(startIdx, endIdx + end.length());
                    ruleResult.addToMapValue(key, srcValue);
                }
            }
        }
    }

    public static void setLineRangeValue(RuleResult ruleResult, String key, String srcValue, String[] interval) {

        if (interval != null && interval.length == 2) {
            String begin = interval[0];
            String end = interval[1];
            if (MappingRuleHelper.isDigit(begin) && MappingRuleHelper.isDigit(end)) {
                int startLine = Integer.parseInt(begin);
                int endLine = Integer.parseInt(end);
                String[] lines = srcValue.split("\\\r\\\n");

                if (srcValue != null) {
                    StringBuilder valBuilder = new StringBuilder();
                    for (int i = startLine; i <= endLine; i++) {
                        valBuilder.append(lines[i - 1]);
                        if (i > startLine && i < endLine) {
                            valBuilder.append("\r\n");
                        }
                    }
                    ruleResult.addToMapValue(key, valBuilder.toString());
                }
            }
        }
    }

    /**
     * In the case of subIndex is a single value; a digit, or single char
     * 
     * @param ruleResult
     * @param subValueIndex
     * @param key
     * @param srcValue
     */
    public static void setIndexValue(RuleResult ruleResult, String subValueIndex, String key, String srcValue) {
        if (MappingRuleHelper.isDigit(subValueIndex)) {
            int indx = Integer.parseInt(subValueIndex);
            srcValue = srcValue.substring(indx - 1);
            ruleResult.addToMapValue(key, srcValue);
        } else {
            int indx = srcValue.indexOf(subValueIndex);
            if (indx != -1) {
                srcValue = srcValue.substring(indx);
                ruleResult.addToMapValue(key, srcValue);
            }
        }
    }

    /**
     * Check string value against the given regular expression
     * 
     * @param value
     * @param regex
     * @return
     */
    public static boolean matchRegExp(String value, String regex) {
        boolean result = false;

        Pattern pattern = Pattern.compile(regex);

        Matcher matcher = pattern.matcher(value);
        if (matcher.find()) {
            result = true;
        }
        return result;
    }

    public static void matchRegExp(RuleResult ruleResult, String value, String regex) {

        if (value != null && regex != null) {
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(value);
            if (matcher.find()) {
                ruleResult.setLogicalValue(true);
            } else {
                ruleResult.setLogicalValue(false);
            }

        }
    }
    
    /**
     * Check whether a given field path is contained in List
     * 
     * @param path
     * @param list
     * @return
     */
    public static boolean listContainsPath(String path,  List<Map<String, Object>> list) {
        boolean result = false;
        if (list!=null && !list.isEmpty()) {
            path = MXMessageFieldHelper.removeSigns(path);
            for (Map<String, Object> mapItem:list) {      
               for (Entry<String, Object> entry:mapItem.entrySet()) {
                   String key = entry.getKey();
                   String value="";
                   if(entry.getValue() != null)
                	   value = entry.getValue().toString();
                   key = MXMessageFieldHelper.removeArraySigns(key);
                   if (key.startsWith(path) && StringUtils.isNotEmpty(value)) {
                    result = true;
                    return result;
                   }
               }  
            }   
        }
        return result;
    }
    
    /**
     * Check whether a given field path is contained in the index of List
     * @return
     */
    public static boolean existInIndexOfArray(String path, int indx, List<Map<String, Object>> list) {
    
    	boolean result = false;
    	 if (list!=null && !list.isEmpty()) {
             path = MXMessageFieldHelper.removeSigns(path);
             int count=0;
             for (Map<String, Object> mapItem:list) {
            	if (count==indx) { 
            		for (Entry<String, Object> entry:mapItem.entrySet()) {
            			String key = entry.getKey();
            			String value="";
            			if(entry.getValue() != null)
            				value = entry.getValue().toString();
            			key = MXMessageFieldHelper.removeArraySigns(key);
            			if (key.startsWith(path) && StringUtils.isNotEmpty(value)) {
            				result = true;
            				return result;
            			}
            		}
            	}
                count++;
             }   
         }
    	return result;
    }
    
    
    public static String getValueFromSet(Set set ) {    
        String result = null;
        if (set!=null && !set.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Object element:set) {
                if (element instanceof Map) {
                    Map elMap = (Map) element;
                    for (Object keyObj:  elMap.keySet()) {
                        Object setItemObj = elMap.get(keyObj);
                        
                        if (setItemObj instanceof Map) {
                            Set newSet = ((Map) setItemObj).entrySet();
                            result = getValueFromSet(newSet); 
                        } else if (setItemObj instanceof String ) {
                            String sValue = (String) setItemObj;
                            sb.append(sValue);
                            sb.append("\r\n");
                        }
                    }
                }
            }
            if (sb.length()>1) {
                result = sb.toString();
            }
        }    
        return result;
    }
}
