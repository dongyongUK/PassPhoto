package com.misys.tiplus2.swift.mx.message.processor;

import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.processor.MessageProcessorException;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;

/**
 * 
 * @author DaiD1
 *
 */
public interface MXMessageProcessor {
    public static final String BEAN_NAME = "message.processor";

    MXMessageContainer transformIncomingMXMessage(String finMessage) throws MXMessageProcessorException;

    MXMessageContainer transformFromMXMessage(String finMessage) throws MXMessageProcessorException;

    MXMessageContainer transformFromMXMessage(String finMessage, boolean validation)
            throws MessageProcessorException;

    MXMessageContainer transformToMXMessage(MXMessageContainer messageContainer, boolean validation)
            throws MXMessageProcessorException;

    MTMessageContainer annotate(MTMessageContainer messageContainer) throws MXMessageProcessorException;

    String getVersion();
}
