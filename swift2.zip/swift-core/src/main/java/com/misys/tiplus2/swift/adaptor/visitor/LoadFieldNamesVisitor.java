package com.misys.tiplus2.swift.adaptor.visitor;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.FieldOptions;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.maps.visitor.SWIFTMessageMapsVisitor;

/**
 * Load data value from EnigmaSwiftPane for a given TI field name or repeated
 * field name with index
 *
 * @author DaiD1
 *
 */
public class LoadFieldNamesVisitor extends SWIFTMessageMapsVisitor {

    protected static final Logger LOG = LoggerFactory.getLogger(LoadFieldNamesVisitor.class);

    private List<String> fieldNames;

    private DataBlock currentDataBlock;
    private int currentDataBlockIndex;

    public List<String> load(String type) {
        Loggers.method().enter(LOG, type);
        fieldNames = null;
        MessageMap messageMap = getMessageMapsLoader().findByName(type);
        if (messageMap != null) {
            fieldNames = new ArrayList<String>();
            messageMap.accept(this, fieldNames);
        }
        List<String> result = fieldNames;
        Loggers.method().exit(LOG, result);
        return result;
    }

    @Override
    public Object visit(HeaderField headerField, Object data) {

        Loggers.method().enter(LOG, headerField, data);

        fieldNames.add(headerField.getName());

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataBlock dataBlock, Object data) {

        Loggers.method().enter(LOG, dataBlock, data);
        currentDataBlock = dataBlock;
        currentDataBlockIndex = 0;

        int repeat = Integer.parseInt(dataBlock.getRepeat());

        for (int i = 0; i < repeat; i++) {
            currentDataBlockIndex = i;

            for (DataTypeChoice choice : dataBlock.getDataTypeChoices()) {
            	switch (choice.getChosen()) {
                case DATAFIELD:
                    choice.getDataField().accept(this, data);
                    break;
                case FIELDOPTIONS:
                    FieldOptions fieldOptions = choice.getFieldOptions();
                    currentFieldOptionsTag = fieldOptions.getTag();
                    fieldOptions.accept(this,data);
                    currentFieldOptionsTag = null;
                    break;
                default:
                    break;
                }
            }
        }
        currentDataBlockIndex = 0;
        currentDataBlock = null;

        Loggers.method().exit(LOG, data);
        return data;
    }

    @Override
    public Object visit(DataField dataField, Object data) {
        Loggers.method().enter(LOG, dataField, data);
        String fieldName = "";
        if (currentDataBlock != null && currentDataBlock.getName() != null) {
            fieldName = FieldPropertiesHelper.convertRepeatedFieldName(dataField.getName(), currentDataBlockIndex);
        } else {
            fieldName = dataField.getName();
        }
        fieldNames.add(fieldName);
        Loggers.method().exit(LOG, data);
        return data;
    }

}
