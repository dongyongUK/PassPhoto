package com.misys.tiplus2.swift.message;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;

/**
 * Helper class for MTMessdageContainer
 *
 * @author DaiD1
 *
 */
public class MTMessageContainerHelper {

	private static final Logger LOG = LoggerFactory.getLogger(MTMessageContainerHelper.class);

	public static int calculateMessageSize(MTMessageContainer message) {

		Loggers.method().enter(LOG, message.getType());
		int result = 0;

		result += calculateHeaderSize(message.getHeaderFields());

		// block 4 start
		result += 5; // 5 for {4:\r\n

		result += calculateDataFieldsSize(message.getDataFields());
		if (!message.getDataBlocksByName().isEmpty()) {
			result += calculateDataBlockSize(message.getDataBlocksByName());
		}

		result += 2; // 2 for end of block4 -}

		result += calculateTrailerSize(message.getHeaderFields());

		Loggers.method().exit(LOG, result);
		return result;

	}

	public static int calculateHeaderSize(Map<String, TagDataField> headerMap) {

		Loggers.method().enter(LOG);
		int result = 0;
		// block 1 is fixed length
		result = 29;

		// block 2
		TagDataField outDate = headerMap.get("OutputDate");
		TagDataField outTime= headerMap.get("OutputTime");
		
		if (outDate!=null && outTime!=null) {
			//block 2 with outputDate and outputTime has fixed length of 51 
			result += 51;
		} else {
			// otherwise block 2 has minimum 21 characters
			result += 21;
			if (headerMap.get("DeliveryMonitoring") != null && !"0".equals(headerMap.get("DeliveryMonitoring").getValue())) {
				result += 1;
			}
			if (headerMap.get("ObsolescencePeriod") != null) {
				result += 3;
			}
		}

		int b3size = 0;
		// block 3
		if (headerMap.get("103") != null) {
			b3size = 4; // for "{3:" and "}"
			result += headerMap.get("103").getValue().length() + 6; // for 103:, {, and }
		}
		if (headerMap.get("113") != null) {
			b3size = 4; // for "{3:" and "}"
			result += headerMap.get("113").getValue().length() + 6; // for 113:, {, and }
		}
		if (headerMap.get("108") != null) {
			b3size = 4; // for "{3:" and "}"
			result += headerMap.get("108").getValue().length() + 6; // for 108:, {, and }
		}
		if (headerMap.get("111") != null) {
			b3size = 4; // for "{3:" and "}"
			result += headerMap.get("111").getValue().length() + 6; // for 111:, {, and }
		}
		if (headerMap.get("119") != null) {
			b3size = 4; // for "{3:" and "}"
			result += headerMap.get("119").getValue().length() + 6; // for 119:, {, and }
		}
		if (headerMap.get("121") != null) {
			b3size = 4; // for "{3:" and "}"
			result += headerMap.get("121").getValue().length() + 6; // for 121:, {, and }
		}
		result += b3size;

		Loggers.method().exit(LOG, result);
		return result;
	}

	public static int calculateDataFieldsSize(Map<String, TagDataField> fieldMap) {
		Loggers.method().enter(LOG);
		int result = 0;
		if (fieldMap != null && !fieldMap.isEmpty()) {
			for (Entry<String, TagDataField> fEntry : fieldMap.entrySet()) {
				result += fEntry.getValue().getTag().length() + 2; // 2 for :tag:
				String v=fEntry.getValue().getValue();
				if (v!=null) {
					result += v.length() + 2; // 2 for \r\n
				}
			}
		}
		Loggers.method().exit(LOG, result);
		return result;

	}

	public static int calculateDataBlockSize(Map<String, List<TagDataBlock>> blockMap) {
		Loggers.method().enter(LOG);
		int result = 0;

		if (blockMap != null && !blockMap.isEmpty()) {
			for (Entry<String, List<TagDataBlock>> entry : blockMap.entrySet()) {
				List<TagDataBlock> tdbList = entry.getValue();
				if (tdbList != null && !tdbList.isEmpty()) {
					for (TagDataBlock block : tdbList) {
						if (block.getDataFields() != null && !block.getDataFields().isEmpty()) {
							for (Entry<String, TagDataField> fEntry : block.getDataFields().entrySet()) {
								result += fEntry.getValue().getTag().length() + 2; // 2 for :tag:
								String v=fEntry.getValue().getValue();
								if (v!=null) {
									result += v.length() + 2; // 2 for \r\n
								}
							}
						}
					}
				}
			}
		}
		Loggers.method().exit(LOG, result);
		return result;

	}

	public static int calculateTrailerSize(Map<String, TagDataField> headerMap) {

		Loggers.method().enter(LOG);
		int result = 0;
		if (headerMap.get("Trailer") != null) {
			result = 4; // for "{5:" and "}"
			result += headerMap.get("Trailer").getValue().length();
		}
		Loggers.method().exit(LOG, result);
		return result;
	}
	
   public static boolean isDummyF21(MTMessageContainer message) {
        
        boolean result = false;
        
        String fin = message.getFINMessage();
        
        if (fin!=null ) {
            FinMessageHandler handler = new FinMessageHandler(fin);
            result = handler.isDummyF21;
        }
        return result;
    }
}
