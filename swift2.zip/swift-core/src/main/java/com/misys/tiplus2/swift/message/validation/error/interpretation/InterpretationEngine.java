package com.misys.tiplus2.swift.message.validation.error.interpretation;

import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.validation.exception.FieldValidationException;

/**
 * Translate Engine for field format code. This class will be injected as a
 * singleton spring bean
 * 
 * @author daid1
 * 
 */
public class InterpretationEngine {

    private static final Logger LOG = LoggerFactory.getLogger(InterpretationEngine.class);

    private FieldFormatInterpreter fieldFormatInterpreter;
    private SwiftValidationResources errorCodeResources;

    /**
     * 
     * Pair for describing single variable in a field format
     * 
     */
    class VarPair {

        // digit part
        int digit;
        // type defined in the class FieldFormatDatTypes
        char type;

        public VarPair(int d, char t) {
            digit = d;
            type = t;
        }

        public int getDigit() {
            return digit;
        }

        public char getType() {
            return type;
        }
    }

    public static final String NEW_LINE = System.getProperty("line.separator");
    public static final String SEPARATE = ", ";

    /**
     * Process a field format which has no optional ([...]) variables
     * 
     * @param code
     * @param desList
     * @param numVar
     * @return
     */
    private String procFieldDesc(FieldDesc fieldDesc) throws RuntimeException {

        String[] results = null;
        String code = fieldDesc.getMatched();
        Map<String, String> desList = fieldDesc.getDescriptions();

        int numVar = desList.size();
        VarPair[] vars = new VarPair[numVar];

        if (code.equals("\\\\n")) {
            vars[0] = new VarPair(1, 'L');
        } else {

            for (int i = 0; i < numVar; i++) {
                String var = getVar(code, i + 1);
                vars[i] = new VarPair(getDigit(var), getType(var));
            }
        }
        results = formatDesc(vars, desList);

        StringBuilder result = new StringBuilder();
        int size = results.length;

        for (int i = 0; i < size; i++) {
            result.append(results[i]);
            if (size != (i + 1)) { // not the last one
                result.append(" AND ");
            }
        }
        return result.toString();
    }

    private String[] formatDesc(VarPair[] vars, Map<String, String> desList) throws RuntimeException {

        String[] out = new String[vars.length];
        Iterator<String> it = desList.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            int order = Integer.parseInt(key.substring(key.length() - 1));
            VarPair var = vars[order - 1];
            String des = "";

            des = FieldFormatDataTypes.d_types.get(var.getType());
            if (des == null) des = "";
            if (var.getType() != 'L') {
                out[order - 1] = FieldFormatDataTypes.desc_map_2.get(desList.get(key)) + " " + var.getDigit() + " "
                        + des;
            } else {
                out[order - 1] = FieldFormatDataTypes.desc_map_2.get(desList.get(key));
            }
        }
        return out;
    }

    public String translate(String fieldFormat) throws FieldValidationException {
        Loggers.method().enter(LOG, fieldFormat);

        String result = null;
        FieldDesc fieldDesc = null;

        if (fieldFormat == null) {
            result = "(No additional error information available)";
        } else {
            try {
                fieldDesc = fieldFormatInterpreter.getDescriptions(fieldFormat);
                if (fieldDesc == null) {
                    result = "No error description for: " + fieldFormat;
                } else {
                    if (fieldDesc.getGroups() == null || fieldDesc.getGroups().isEmpty()) {
                        result = procFieldDesc(fieldDesc);
                    } else {
                        StringBuilder sb = new StringBuilder();
                        int size = fieldDesc.getGroups().size();
                        for (int i = 0; i < size; i++) {
                            String ff = fieldDesc.getGroups().get(i);
                            boolean isOpt = false;
                            if (ff.startsWith("[") && ff.endsWith("]")) {
                                ff = ff.substring(1, ff.length() - 1);
                                isOpt = true;
                                sb.append("[Optional: ");
                            }
                            FieldDesc fd = fieldFormatInterpreter.getDescriptions(ff);
                            if (fd == null) {
                                sb.append("No error description for: ").append(ff);
                            } else {
                                sb.append(procFieldDesc(fd));
                            }
                            if (isOpt) {
                                sb.append("]");
                            }
                            if (size != (i + 1) && !fd.getMatched().equals("\\\\n") && !isOpt) {
                                sb.append(", ");
                            }
                        }
                        result = sb.toString();
                    }
                    result = result + ".";
                }
                Loggers.general().debug(LOG, "translated={}, pattern={}", result, fieldFormat);
            } catch (Exception e) {
                Loggers.general().error(LOG, "Failed to translate fieldFormat: " + fieldFormat);
                Loggers.general().error(LOG, e.getMessage());
                throw new FieldValidationException("Failed to translate fieldFormat: " + fieldFormat, e);
            }
        }

        Loggers.method().exit(LOG, result);
        return result;
    }

    /**
     * Return the ith variable from the fieldFormat
     * 
     * @param code
     * @return
     */
    private String getVar(String code, int i) throws RuntimeException {

        int c = 0, j = 0, p = 0;

        // Letter N as single variable
        if (code.charAt(0) == 'N') {
            return "N";
        }

        char[] varbuffer = new char[code.length()];
        while (j < code.length()) {

            varbuffer[j] = code.charAt(j);
            if (!Character.isDigit(code.charAt(j)) && code.charAt(j) != '!' && code.charAt(j) != '/') {
                c++;
                if (c != i) p = j + 1;
            }

            if (c == i) {
                break;
            }
            j++;
        }

        String var = new String(varbuffer);
        var = var.trim();

        if (j < code.length()) {
            return var.substring(p, j + 1);
        }
        return var.substring(p);
    }

    /**
     * Get type from a single field format
     */
    private Character getType(String var) throws RuntimeException {
        char c = var.charAt(var.length() - 1);
        if (!Character.isDigit(c) && c != '*' && c != '-') {
            return c;
        }
        return 0;
    }

    /**
     * Get digit from a single field format
     * 
     * @param var
     * @return
     */
    private Integer getDigit(String var) throws RuntimeException {

        // ignore prefix character "/"
        if (var.startsWith(FieldFormatDataTypes.FORWARD_SLASH)) {
            var = var.substring(1);
        }
        int j = 0;
        while (j < var.length()) {
            j++;
            if (!Character.isDigit(var.charAt(j))) break;
        }
        String ns = var.substring(0, j);
        return Integer.parseInt(ns);
    }

    public FieldFormatInterpreter getFieldFormatInterpreter() {
        return fieldFormatInterpreter;
    }

    public void setFieldFormatInterpreter(FieldFormatInterpreter fieldFormatInterpreter) {
        this.fieldFormatInterpreter = fieldFormatInterpreter;
    }

    public SwiftValidationResources getErrorCodeResources() {
        
        return errorCodeResources;
    }

    public void setErrorCodeResources(SwiftValidationResources errorCodeResources) {
        this.errorCodeResources = errorCodeResources;
    }
}
