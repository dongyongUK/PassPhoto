package com.misys.tiplus2.swift.mx.message.processor;

import com.misys.tiplus2.swift.exception.SWIFTMessageException;

/**
 * MXMessageProcessorException
 *
 * @author DaiD1
 *
 */
public class MXMessageProcessorException extends SWIFTMessageException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public MXMessageProcessorException() {
        super();
    }

    public MXMessageProcessorException(String message) {
        super(message);
    }

    public MXMessageProcessorException(Throwable cause) {
        super(cause);
    }

    public MXMessageProcessorException(String message, Throwable cause) {
        super(message, cause);
    }

    public MXMessageProcessorException(String code, String message) {
        super(code, message);
    }

    public MXMessageProcessorException(String code, String message, Throwable cause) {
        super(code, message, cause);

    }
    
//    public String getRootCauseError(){
//        
//        String error = "";
//        Throwable thr = this;
//        while (thr.getCause()!=null){
//            thr = thr.getCause();
//        }
//        error = thr.getMessage();
//        return error ;
//    }
}
