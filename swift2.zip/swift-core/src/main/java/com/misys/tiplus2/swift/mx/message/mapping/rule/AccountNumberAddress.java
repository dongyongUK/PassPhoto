package com.misys.tiplus2.swift.mx.message.mapping.rule;

import java.util.function.Predicate;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.rule.MessageRuleHelper;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * MT_TO_MXPartyAccount  
 * MT_TO_MXPartyNameAndStructuredAddress   
 * 
 * Format [/34x]
 *        4*(1!n/33x) 
 * Fields 50F and 59F of MT
 * 
 * @author DaiD1
 *
 */
public class AccountNumberAddress implements Predicate<RuleResult> {

    static final String ruleID="pred.account.address.1";
    
    @Override
    public boolean test(RuleResult ruleResult) {
        boolean result = false;
        
        DataField mapField = ruleResult.getMapField();
        TagDataField tiField = ruleResult.getTiField();
        
        if (mapField==null || tiField==null) {
            return result;
        }
        
       String path = mapField.getPath();
       String tag = mapField.getTag();
       String[] tags = null;
       if (tag!=null && tag.contains(":")) {
           tags = tag.split(":");
       }
       String srcValue = tiField.getValue();
       String tgtValue =null;
       String key=null;
       
       if (srcValue==null) {
           return result;
       }
       
       String[] lines = MessageRuleHelper.splitLine(srcValue);
       
       if (tags!=null && tags.length>1) {
           ruleResult.getMapField().setTag(tags[0]);
       }
       
       String subTag = ruleResult.getMapField().getTag();
       if (lines[0].startsWith("//CH")) {
           key = path+"."+subTag+".Id.Othr.SchmeNm.Cd";
           tgtValue="CUID";
           ruleResult.addToMapValue(key, tgtValue);
           
           key = path+"."+subTag+".Id.Othr.id";
           tgtValue = lines[0].substring(4);
           ruleResult.addToMapValue(key, tgtValue);
           
       } else if (lines[0].startsWith("/")) {
           tgtValue = lines[0].substring(1);
           // for TI, account map to  IBAN
           key = path+"."+subTag+".Id.IBAN";
           ruleResult.addToMapValue(key, tgtValue);
       }
        
       if (tags!=null && tags.length>1) {
           ruleResult.getMapField().setTag(tags[1]);
       }
       subTag = ruleResult.getMapField().getTag();
       int size = lines.length;
       int  c=1;
       StringBuilder oneBd = new StringBuilder();
       StringBuilder twoBd = new StringBuilder();
       StringBuilder threeBd = new StringBuilder();
       
       /*Max 140 characters are copied to Name. No truncation*/  
       
       /*Translation of address details present on line(s) starting with �2/�. 
        * As per field 50F, 59F format specifications,�2/� must not be used without
        *  �3/� (Country, Town) but �3/� can be used without �2/� 
        */
        while (c < size) {
            String line = lines[c];
            String num = line.substring(0, 2);
            
            switch (num) {
            case "1/":
                oneBd.append(line);
                break;
            case "2/":
                twoBd.append(line);
                break;
            case "3/":
                threeBd.append(line);
                break;
            default:
                break;
            };
            c++;
        }
        
        if (!oneBd.toString().isEmpty()) {
            tgtValue = oneBd.toString().replace("\r\n", " ");
            // remove 1/
            tgtValue = tgtValue.substring(2);
            key = path+"."+subTag+".Nm";
            ruleResult.addToMapValue(key, tgtValue);
        }
       
        if (!twoBd.toString().isEmpty()) {
            tgtValue = twoBd.toString();
            key = path+"."+subTag+".PstlAdr.AdrLine";
            ruleResult.addToMapValue(key, tgtValue);
        }
       
        if (!threeBd.toString().isEmpty()) {
            tgtValue = threeBd.toString();
            key = path+"."+subTag+".PstlAdr.AdrLine";
            ruleResult.addToMapValue(key, tgtValue);
        }
        
        result = true;
        return result;
    }

}
