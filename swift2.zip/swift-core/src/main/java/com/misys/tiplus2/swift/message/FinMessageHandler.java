package com.misys.tiplus2.swift.message;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.contract.AssertArgument;
import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.message.MTMessageConstant;

public class FinMessageHandler {

    private static final Logger LOG = LoggerFactory.getLogger(FinMessageHandler.class);

    private static Map<Integer, String> blockPrefixes = new HashMap<Integer, String>();
    static {
        blockPrefixes.put(1, MTMessageConstant.BLOCK1_START);
        blockPrefixes.put(2, MTMessageConstant.BLOCK2_START);
        blockPrefixes.put(3, MTMessageConstant.BLOCK3_START);
        blockPrefixes.put(4, MTMessageConstant.BLOCK4_START);
        blockPrefixes.put(5, MTMessageConstant.BLOCK5_START);
    }

    private static Map<Integer, String> blockSuffixes = new HashMap<Integer, String>();
    static {
        blockSuffixes.put(1, MTMessageConstant.BLOCK1_END);
        blockSuffixes.put(2, MTMessageConstant.BLOCK2_END);
        blockSuffixes.put(3, MTMessageConstant.BLOCK3_END);
        blockSuffixes.put(4, MTMessageConstant.BLOCK4_END);
        blockSuffixes.put(5, MTMessageConstant.BLOCK5_END);
    }

    private Map<Integer, String> blockMap;

    private static String message;
    public static boolean isF21 = false;
    public static boolean isDummyF21 = false;
    public static boolean isF21Embedded = false;
    
    public static String getBlockPrefix(Integer number) {
        return blockPrefixes.get(number);
    }

    public static String getBlockSuffix(Integer number) {
        return blockSuffixes.get(number);
    }

    public FinMessageHandler(String finMessage) {

        Loggers.method().enter(LOG, finMessage);

        message = finMessage.trim();
        String blockValue = message;
        isF21 = (blockValue.startsWith("{1:F21")) ? true : false;
        isF21Embedded = (isF21 && blockValue.contains(MTMessageConstant.BLOCK4_END)) ? true : false;
        
        this.blockMap = new HashMap<Integer, String>();

        try {
            // block 1
            int end = blockValue.indexOf(MTMessageConstant.BLOCK1_END);
            blockMap.put(1, blockValue.substring(MTMessageConstant.BLOCK1_START.length(), end));
            blockValue = blockValue.substring(end + 1);
            // block 2
            if (blockValue.startsWith(MTMessageConstant.BLOCK2_START)) {
                end = blockValue.indexOf(MTMessageConstant.BLOCK2_END);
                blockMap.put(2, blockValue.substring(MTMessageConstant.BLOCK2_START.length(), end));
                blockValue = blockValue.substring(end + 1);
            }
            // block 3
            if (blockValue.startsWith(MTMessageConstant.BLOCK3_START)) {
                end = blockValue.indexOf(MTMessageConstant.BLOCK4_START);
                int last = blockValue.lastIndexOf(MTMessageConstant.BLOCK3_END, end - 1);
                blockMap.put(3, blockValue.substring(MTMessageConstant.BLOCK3_START.length(), last));
                blockValue = blockValue.substring(end);
            }
            // block 4
            int start = blockValue.indexOf(MTMessageConstant.BLOCK4_START);
            blockValue = blockValue.substring(start + MTMessageConstant.BLOCK4_START.length());
            if (isF21 && !isF21Embedded) {
                end = blockValue.lastIndexOf(MTMessageConstant.BLOCK2_END);
                
                String bk1 = blockMap.get(1);
                if (bk1.length()>25) {
                    isDummyF21= true;
                }
            } else {
                end = blockValue.indexOf(MTMessageConstant.BLOCK4_END);
            }
            String v = blockValue.substring(0, end);
            blockMap.put(4, v);

            if (isF21 && !isF21Embedded) {
                blockValue = blockValue.substring(end + 1);
            } else {
                blockValue = blockValue.substring(end + MTMessageConstant.BLOCK4_END.length());
            }

            // block 5
            if (blockValue != null && blockValue.contains(MTMessageConstant.BLOCK5_START)) {
                start = blockValue.indexOf(MTMessageConstant.BLOCK5_START);
                blockValue = blockValue.substring(start + MTMessageConstant.BLOCK5_START.length());
                end = blockValue.lastIndexOf(MTMessageConstant.BLOCK5_END);
                blockMap.put(5, blockValue.substring(0, end));
                blockValue = blockValue.substring(end);
            }
        } catch (Exception e) {
            throw new IllegalStateException("Invalid block: " + blockValue, e);
        }

        Loggers.method().exit(LOG);
    }

    public String findBlockByNumber(int number) {

        return blockMap.get(number);
    }

    public static String reverseDirection(String direction) {

        Loggers.method().enter(LOG, direction);
        String result = "";
        if (MTMessageConstant.INCOMING.equals(direction)) {
            result = MTMessageConstant.OUTGOING;
        } else {
            result = MTMessageConstant.INCOMING;
        }

        Loggers.method().exit(LOG, result);
        return result;
    }

    public String getServiceId() {
        return blockMap.get(1).substring(1, 3);
    }

    public String getMessageType() {
        return blockMap.get(2).substring(1, 4);
    }

    public String getDirection() {
        return blockMap.get(2).substring(0, 1);
    }

    public static String normalize(String message) {

        Loggers.method().enter(LOG, message);
        AssertArgument.notBlank(message, "message");
        String result = message;

        if (result.contains("\r\n")) {
            result = result.replace("\r\n", "\r");
        }

        if (result.contains("\n")) {
            result = result.replace("\n", "\r");
        }

        result = result.replace("\r", "\r\n");

        Loggers.method().exit(LOG, result);
        return result;
    }

    public static String getMessage() {
        return message;
    }
}
