package com.misys.tiplus2.swift.mx.message.mapping.rule;

import java.util.function.Predicate;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.swift.message.TagDataField;
import com.misys.tiplus2.swift.message.validation.rule.MessageRuleHelper;
import com.misys.tiplus2.swift.message.validation.rule.RuleResult;

/**
 * 
 * Format [/1!a][/34X] (party Identifier) MT_TO_MXFinancialInstitutationAccount
 *        [/35x]        (Location)       ???
 * Fields 53B
 * 
 * @author DaiD1
 *
 */
public class PartyIdentifierAndLocation implements Predicate<RuleResult> {

    static final String ruleID="pred.partyId.location.1";
    @Override
    public boolean test(RuleResult ruleResult) {
        boolean result = false;

        DataField mapField = ruleResult.getMapField();
        TagDataField tiField = ruleResult.getTiField();

        if (mapField == null || tiField == null) {
            return result;
        }

        String tag = mapField.getTag();
        String[] tags = null;
        if (tag!=null && tag.contains(":")) {
            tags = tag.split(":");
        }
        String srcValue = tiField.getValue();
        if (srcValue == null) {
            return result;
        }

        String[] lines = MessageRuleHelper.splitLine(srcValue);
        int size = lines.length;
      
        //if (size > 1) {
            if (tags!=null && tags.length>1) {
                ruleResult.getMapField().setTag(tags[0]);
            }
            MT2MXFinancialInstTranslation.mt2mxFinancialInstAcct(ruleResult, lines[0]); 
        //} 
        // TODO  how to mapping location [34x] -- the second line

        result = true;
        return result;
    }

}
