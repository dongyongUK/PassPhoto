package com.misys.tiplus2.swift.message;

public class TestMessageMT767 {

    MTMessageContainer mt767;

    public TestMessageMT767() {

        mt767 = new MTMessageContainer("767");
        TagDataField headerField = new TagDataField(MTMessageConstant.B1_APPLICATION_ID_TAG,
                MTMessageConstant.B1_APPLICATION_ID_VALUE);
        mt767.addHeaderField(headerField);
        mt767.addHeaderField(new TagDataField(MTMessageConstant.B1_SERVICE_ID_TAG,
                MTMessageConstant.B1_SERVICE_ID_FIN_VALUE));

        mt767.addHeaderField(new TagDataField("LogicalTerminalAddress", "BACIGB2L1500"));
        mt767.addHeaderField(new TagDataField("Session", "4321"));
        mt767.addHeaderField(new TagDataField("Seqence", "666666"));

        mt767.addHeaderField(new TagDataField("InputOutputIdentifier", "I"));
        mt767.addHeaderField(new TagDataField("MessageType", "700"));
        mt767.addHeaderField(new TagDataField("ReceiverAddress", "BARCGB2LXXXX"));
        mt767.addHeaderField(new TagDataField("DeliveryMonitoring", "2"));
        mt767.addHeaderField(new TagDataField("Priority", "U"));
        mt767.addHeaderField(new TagDataField("ObsolescencePeriod", "003"));

        mt767.addHeaderField(new TagDataField("108", "{108:N-XXX-A01}"));
        mt767.addHeaderField(new TagDataField("Trailer", "{MAC:00000000}{CHK:04E4CC43D6D9}"));

        TagMarkerField tag15A = new TagMarkerField("15A");
        tag15A.setDescription("New Sequence");
        mt767.addMarkerField(tag15A);

        TagDataField tag27 = new TagDataField("27", "1/2");
        tag27.setDescription("Sequence of Total");
        mt767.addDataField(tag27);

        TagDataField tag21 = new TagDataField("21", "UT221");
        tag21.setDescription("Related Reference");
        mt767.addDataField(tag21);

        TagDataField tag22A = new TagDataField("22A", "ISCA");
        tag22A.setDescription("Purpose of Message");
        mt767.addDataField(tag22A);

        TagDataField tag72Z = new TagDataField("72Z", "PLEASE AMEND AS SOON AS POSSIBLE");
        tag72Z.setDescription("Sender to Receiver Information");
        mt767.addDataField(tag72Z);

        TagDataField tag23X = new TagDataField("23X", "EMAL/XXX");
        tag23X.setDescription("File Identification");
        mt767.addDataField(tag23X);

        TagMarkerField tag15B = new TagMarkerField("15B");
        tag15B.setDescription("New Sequence");
        mt767.addMarkerField(tag15B);

        TagDataField tag20 = new TagDataField("20", "IGT001221");
        tag20.setDescription("Undertaking Number");
        mt767.addDataField(tag20);

        TagDataField tag26E = new TagDataField("26E", "001");
        tag26E.setDescription("Number of Amendment");
        mt767.addDataField(tag26E);

        TagDataField tag30 = new TagDataField("30", "190228");
        tag30.setDescription("Date of Amendment");
        mt767.addDataField(tag30);

        TagDataField tag52A = new TagDataField("52A", "FINBGBLNXXX");
        tag52A.setDescription("Issuer");
        mt767.addDataField(tag52A);

        TagDataField tag32B = new TagDataField("32B", "USD20000,00");
        tag32B.setDescription("Increase of Undertaking Amount");
        mt767.addDataField(tag32B);

        TagDataField tag23B = new TagDataField("23B", "COND");
        tag23B.setDescription("Expiry Type");
        mt767.addDataField(tag23B);

        TagDataField tag31E = new TagDataField("31E", "200228");
        tag31E.setDescription("Date of Expiry");
        mt767.addDataField(tag31E);

        TagDataField tag35G = new TagDataField("35G", "In the case of a hard Brexit");
        tag35G.setDescription("Expiry Condition/Event");
        mt767.addDataField(tag35G);

        TagDataField tag59A = new TagDataField("59A", "CHRYSLER TOWER COMPLEX\r\n5th Avenue\r\nNYC");
        tag59A.setDescription("Beneficiary");
        mt767.addDataField(tag59A);

        TagDataField tag77U = new TagDataField(
                "77U",
                "123456789012345678901234567890123456789\r\n123456789012345678901234567890123456789\r\n123456789012345678901234567890123456789");
        tag77U.setDescription("Other Amendments to Undertaking");
        mt767.addDataField(tag77U);

        TagDataField tag24E = new TagDataField("24E", "COLL/abc");
        tag24E.setDescription("Delivery of Amendment to Undertaking");
        mt767.addDataField(tag24E);

        TagDataField tag24G = new TagDataField("24G", "BENE");
        tag24G.setDescription("Delivery to/Collection By");
        mt767.addDataField(tag24G);

        TagMarkerField tag15C = new TagMarkerField("15C");
        tag15C.setDescription("New Sequence");
        mt767.addMarkerField(tag15C);

        TagDataField tag32bC = new TagDataField("32B", "USD30000,00", "32B_C");
        tag32bC.setDescription("Increase of Local Undertaking Amount");
        mt767.addDataField(tag32bC);

        TagDataField tag23bC = new TagDataField("23B", "BENE", "23B_C");
        tag23bC.setDescription("Expiry Type");
        mt767.addDataField(tag23bC);

        TagDataField tag59 = new TagDataField("59", "AMDAM COMPANY\r\nPO BOX 123\r\nNL/AMSTERDAM", "59_C");
        tag59.setDescription("Beneficiary");
        mt767.addDataField(tag59);

        TagDataField tag77L = new TagDataField("24G", "BENE");
        tag77L.setDescription("Other Amendments to Local Undertaking");
        mt767.addDataField(tag77L);

        TagDataField tag24gC = new TagDataField("24G", "MEESNL2A By PAYMENT", "24G_C");
        tag24gC.setDescription("Delivery to/Collection By");
        mt767.addDataField(tag24gC);

    }

    public MTMessageContainer getMt767() {
        return mt767;
    }

}
