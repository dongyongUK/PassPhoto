package com.misys.tiplus2.swift.message;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;

public class MessageRuleVlidateVisitorUnitTest {

	 MTMessageContainer mt103;

	    @Before
	    public void setUp() {
	    	  mt103 = new MTMessageContainer("103");
	    	  createHeader();
	    	  createBody();
	    }

	    private void createHeader() {

	    	 TagDataField headerField = new TagDataField(MTMessageConstant.B1_APPLICATION_ID_TAG,
	                 MTMessageConstant.B1_APPLICATION_ID_VALUE);
	         mt103.addHeaderField(headerField);
	         mt103.addHeaderField(new TagDataField(MTMessageConstant.B1_SERVICE_ID_TAG,
	                 MTMessageConstant.B1_SERVICE_ID_FIN_VALUE));
	         mt103.addHeaderField(new TagDataField("LogicalTerminalAddress", "PTSQGBB0XAAA"));
	         mt103.addHeaderField(new TagDataField("Session", "4321"));
	         mt103.addHeaderField(new TagDataField("Sequence", "654321"));

	         mt103.addHeaderField(new TagDataField("InputOutputIdentifier", "I"));
	         mt103.addHeaderField(new TagDataField("ReceiverAddress", "PTSQGBB0XADM"));
	         mt103.addHeaderField(new TagDataField("MessageType", "103"));
	         mt103.addHeaderField(new TagDataField("Priority", "N"));
	         //mt103.addHeaderField(new TagDataField("InputTime", "1233"));
	         //mt103.addHeaderField(new TagDataField("MIR", "970103BANKBEBBAXXX2222123456"));
	         //mt103.addHeaderField(new TagDataField("OutputDate", "170510"));
	         //mt103.addHeaderField(new TagDataField("OutputTime", "1125"));

	         //mt103.addHeaderField(new TagDataField("113", "{113:xxxx}"));
	         //mt103.addHeaderField(new TagDataField("108", "{108:N-XXX-A01}"));

	         //mt103.addHeaderField(new TagDataField("Trailer", "{MAC:00000000}{CHK:04E4CC43D6D9}"));
	    }

	    private void createBody() {
	    	
	    	TagDataField dataField = new TagDataField("20", "CPC/MBW/21/0352");
	        mt103.addDataField(dataField);

	       /*
	        int max_number_of_repeats = 3;
	        List<TagDataBlock> listOfBlock = new ArrayList<TagDataBlock>(max_number_of_repeats);

	        int number_of_fields_in_block = 1;
	        Map<String, TagDataField> fieldList1 = new HashMap<String, TagDataField>();
	        fieldList1.put("13C", new TagDataField("13C", "/SNDTIME/0100+0100"));
	        TagDataBlock block1 = new TagDataBlock("Time", fieldList1);
	        listOfBlock.add(block1);

	        Map<String, TagDataField> fieldList2 = new HashMap<String, TagDataField>();
	        fieldList2.put("13C", new TagDataField("13C", "/SNDTIME/0200+0100"));
	        TagDataBlock block2 = new TagDataBlock("Time", fieldList2);
	        listOfBlock.add(block2);

	        Map<String, TagDataField> fieldList3 = new HashMap<String, TagDataField>();
	        fieldList3.put("13C", new TagDataField("13C", "/SNDTIME/0300+0100"));
	        TagDataBlock block3 = new TagDataBlock("Time", fieldList3);
	        listOfBlock.add(block3);
            
	        mt103.addDataBlock("Time", listOfBlock);
            */
	        mt103.addDataField(new TagDataField("23B", "CRED"));

	        int max_number_of_repeats = 6;
	        List<TagDataBlock> listOfBlock = new ArrayList<TagDataBlock>(max_number_of_repeats);

	        int number_of_fields_in_block = 1;

	        Map<String, TagDataField> fieldList1 = new HashMap<String, TagDataField>();
	        fieldList1.put("23E", new TagDataField("23E", "GBP1039,05"));
	        TagDataBlock block1 = new TagDataBlock("Instruction", fieldList1);
	        listOfBlock.add(block1);
	        mt103.addDataBlock("Instruction", listOfBlock);
	        
	        
	        mt103.addDataField(new TagDataField("32A", "211203GBP159649,99"));
	        mt103.addDataField(new TagDataField("33B", "GBP159999,99"));
	        
	        String value = "/BO-LOND-ATLANT GEN-CA-GBP-1\r\n1/ATLANTIC GENERAL PLC GENERAL PLC"
					+ "\r\n1/225 QUEENS ROAD225 QUEENS ROAD\r\n2/17 CLEWER HILL ROAD\r\n3/GB/LONDON, ENGLAND";
	        mt103.addDataField(new TagDataField("50F", value));
	        
	        mt103.addDataField(new TagDataField("53B", "/9018-987176-00101"));
	        mt103.addDataField(new TagDataField("57A", "/9018-987176-00101"));
	        
	        value = "/USCHEMCOGBPACNNT10\r\n1/US CHEMICAL COMPANY\r\n1/LONG COMPANY NAME DETAILS"
					+ "\r\n2/4TH AVENUE NEW YORK\r\n3/US/NEW YORK NY2078";
	        mt103.addDataField(new TagDataField("59F", value));
	        
	        mt103.addDataField(new TagDataField("70", "/RFB/BENEREFSW21TC01"));
	        
	        mt103.addDataField(new TagDataField("71A", "BEN"));
	      
	        max_number_of_repeats = 6;
	        listOfBlock = new ArrayList<TagDataBlock>(max_number_of_repeats);

	        number_of_fields_in_block = 1;

	        fieldList1 = new HashMap<String, TagDataField>();
	        fieldList1.put("71F", new TagDataField("71F", "GBP350,00"));
	        block1 = new TagDataBlock("Charges", fieldList1);
	        listOfBlock.add(block1);
	        mt103.addDataBlock("Charges", listOfBlock);
	        
	        value = "/ACC/CREDIT THE WHOLE AMOUNT\r\n//SPECIFIED IN THE INSTRUCTIONS\r\n//WITH SWIFT CHARGES.";
	        mt103.addDataField(new TagDataField("72", value));
	  
	    }
}
