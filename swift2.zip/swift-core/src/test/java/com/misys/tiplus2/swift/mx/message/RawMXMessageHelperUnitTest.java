package com.misys.tiplus2.swift.mx.message;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RawMXMessageHelperUnitTest {

	@Test
	public void testgetMsgDefId() {
		String field1="<head:BizMsgIdr>2025050900000777</head:BizMsgIdr>\r\n"
				+ " <head:MsgDefIdr>pacs.008.001.08</head:MsgDefIdr>\r\n"
				+"<head:BizSvc>swift.cbprplus.02</head:BizSvc>";
		
		String actual = RawMXMessageHelper.getMsgDefId(field1);
		assertEquals("pacs.008.001.08", actual);
		
	}
	
	@Test
	public void testgetBizSvc() {
		String field1="<head:BizMsgIdr>2025050900000777</head:BizMsgIdr>\r\n"
				+ " <head:MsgDefIdr>pacs.008.001.08</head:MsgDefIdr>\r\n"
				+"<head:BizSvc>swift.cbprplus.02</head:BizSvc>";
		
		String actual = RawMXMessageHelper.getBizSvc(field1);
		assertEquals("swift.cbprplus.02", actual);
		
	}
	
	
}
