package com.misys.tiplus2.swift.message;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.misys.tiplus2.swift.FileLoader;

public class FinMessageHelperUnitTest {

    @Test
    public void testExtractFINMessageBody() throws Exception {

        String swiftText = FileLoader.loadFile("messages/2021/MT700In.txt");

        String out = FINMessageHelper.extractFINMessageBody(swiftText);

        System.out.println(out);
    }

    @Test
    public void testNormalise2Message() {

        String text = "{163198319}\n{xxxxxxx}\n{00000000}\n{ghfkghfkgffhj}\n-}";
        String actual = FINMessageHelper.normalize(text);
        String expected = "{163198319}\r\n{xxxxxxx}\r\n{00000000}\r\n{ghfkghfkgffhj}\r\n-}";

        assertEquals(expected, actual);

    }

    @Test
    public void testNormalise3Message() {

        String text = "{163198319}\n{xxxxxxx}\r\n{00000000}\n{ghfkghfkgffhj}\r\n-}";
        String actual = FINMessageHelper.normalize(text);
        String expected = "{163198319}\r\n{xxxxxxx}\r\n{00000000}\r\n{ghfkghfkgffhj}\r\n-}";

        assertEquals(expected, actual);

    }
    
    @Test
    public void testextractLines() {

        String text = "163198319\r\nxxxxxxxyyyyyyyyyy\r\n00000000\r\nghfkghfkgffhj\r\n";
        String[] result = FINMessageHelper.extractLines(text);
        
        int actual = result.length;
        assertEquals(4, actual);
    }
    
    @Test
    public void testexcludeFirstLine() {

        String text = "163198319\r\nxxxxxxxyyyyyyyyyy\r\n00000000\r\nghfkghfkgffhj\r\n";
        String actual = FINMessageHelper.excludeFirstLine(text);
        String expected = "xxxxxxxyyyyyyyyyy\r\n00000000\r\nghfkghfkgffhj\r\n";
        
        assertEquals(expected, actual);
    }
    
    @Test
    public void testextractFirstLine2() {

        String text = "163198319";
        String actual = FINMessageHelper.extractFirstLine(text);
        String expected = text;
        
        assertEquals(expected, actual);
    }
    
    @Test
    public void testexcludeFirstLine2() {

        String text = "163198319";
        String actual = FINMessageHelper.excludeFirstLine(text);
        String expected = null;
        
        assertEquals(expected, actual);
    }
}
