package com.misys.tiplus2.swift.message;

public class TestMessageMT700 {

    MTMessageContainer mt700;

    public TestMessageMT700() {

        mt700 = new MTMessageContainer("700");
        TagDataField headerField = new TagDataField(MTMessageConstant.B1_APPLICATION_ID_TAG,
                MTMessageConstant.B1_APPLICATION_ID_VALUE);
        mt700.addHeaderField(headerField);
        mt700.addHeaderField(new TagDataField(MTMessageConstant.B1_SERVICE_ID_TAG,
                MTMessageConstant.B1_SERVICE_ID_FIN_VALUE));

        mt700.addHeaderField(new TagDataField("LogicalTerminalAddress", "BACIGB2L1500"));
        mt700.addHeaderField(new TagDataField("Session", "4321"));
        mt700.addHeaderField(new TagDataField("Seqence", "666666"));

        mt700.addHeaderField(new TagDataField("InputOutputIdentifier", "I"));
        mt700.addHeaderField(new TagDataField("MessageType", "700"));
        mt700.addHeaderField(new TagDataField("ReceiverAddress", "BARCGB2LXXXX"));
        mt700.addHeaderField(new TagDataField("DeliveryMonitoring", "2"));
        mt700.addHeaderField(new TagDataField("Priority", "U"));
        mt700.addHeaderField(new TagDataField("ObsolescencePeriod", "003"));

        mt700.addHeaderField(new TagDataField("108", "{108:N-XXX-A01}"));
        mt700.addHeaderField(new TagDataField("Trailer", "{MAC:00000000}{CHK:04E4CC43D6D9}"));

        mt700.addDataField(new TagDataField("27", "1/1"));
        mt700.addDataField(new TagDataField("40A", "IRREVOCABLE"));
        mt700.addDataField(new TagDataField("20", "123456"));
        mt700.addDataField(new TagDataField("31C", "120217"));
        mt700.addDataField(new TagDataField("40E", "UCP LATEST VERSION"));
        mt700.addDataField(new TagDataField("31D", "150430AMSTERDAM"));
        mt700.addDataField(new TagDataField("50", "ABC COMPANY\r\nKAERNTNERSTRASSE 3\r\n \r\nAT/VIENNA "));
        mt700.addDataField(new TagDataField("59", "AMDAM COMPANY\r\nPO BOX 123\r\n \r\nNL/AMSTERDAM"));
        mt700.addDataField(new TagDataField("32B", "EUR100000,"));
        mt700.addDataField(new TagDataField("41A", "MEESNL2A By PAYMENT"));
        mt700.addDataField(new TagDataField("43P", "NOT ALLOWED"));
        mt700.addDataField(new TagDataField("43T", "ALLOWED"));
        mt700.addDataField(new TagDataField("44E", "AMSTERDAM"));
        mt700.addDataField(new TagDataField("44F", "VIENNA,"));
        mt700.addDataField(new TagDataField("44C", "150415"));

        String val45 = "+400,000 BOTTLES OF BEER" + "\r\nPACKED 12 TO AN EXPORT CARTON"
                + "\r\nVIA 2 SHIPS FROM ENGLAND and IRELAND" + "\r\nWITH 1 CAPTION AND 2 SEALERS"
                + "\r\n+FCA AMSTERDAM";
        mt700.addDataField(new TagDataField("45A", val45));

        String val46 = "+SIGNED COMMERCIAL INVOICE IN" + "\r\nDUPLICATE" + "\r\n+PACKINGL LIST IN DUPLICATE" + "\r\n"
                + "\r\n+FORWARDING AGENT'S CERTIFICATE OF RECEIPT,"
                + "SHOWING GOODS SHOWING GOODS ADDRESSED TO APPLICANT";

        mt700.addDataField(new TagDataField("46A", val46));

        mt700.addDataField(new TagDataField("71D",
                "ALL BANKING CHARGES OUTSIDE ISSUING\r\nBANK ARE FOR ACCOUNT OF THE BENEFICIARY"));
        mt700.addDataField(new TagDataField("48", "6/FORWARDING AGENT'S CERTIFICATE OF RECEIPT"));
        mt700.addDataField(new TagDataField("49", "CONFIRM"));
        mt700.addDataField(new TagDataField("58A", "MEESNL2A"));
        mt700.addDataField(new TagDataField("57A", "MEESNL2A"));
    }

    public MTMessageContainer getMt700() {
        return mt700;
    }

}
