package com.misys.tiplus2.swift.maps;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import javax.management.modelmbean.XMLParseException;

import org.junit.Test;

import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataBlock;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.DataField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.HeaderField;
import com.misys.tiplus2.catalog.swift.message.map.v1.elements.MessageMap;
import com.misys.tiplus2.catalog.swift.message.map.v1.groups.DataTypeChoice;

/**
 * 
 * @author DaiD1
 *
 */
public class MessageMapsLoaderUnitTest {

    @Test
    public void testMessageMapsLoader() throws XMLParseException {
        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        assertNotNull(loader);

        try {
            loader = new MessageMapsLoader("fhdlfhdlfdhldd");
        } catch (Exception e) {
            String error = e.getMessage();
        }
    }

    @Test
    public void testGetMessageMap() throws XMLParseException {
        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap envelope = loader.findByName("swift_envelope");

        String expected = "swift_envelope";
        String actual = envelope.getName();
        assertEquals(expected, actual);

        envelope = loader.findByName("swift_xyz");

        assertNull(envelope);
    }

    @Test
    public void testFindByName() throws XMLParseException {
        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap map = loader.findByName("MT799");
        String actual = map.getMessage();
        String expected = "799";
        assertEquals(expected, actual);
    }

    @Test
    public void testFindByMessage() throws XMLParseException {
        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap map = loader.findByMessage("199");
        String actual = map.getName();
        String expected = "MT199";
        assertEquals(expected, actual);
    }

    @Test
    public void testHeaderFieldMT103() throws Exception {

        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap envelope = loader.findByName(MessageMapConstant.SWIFT_ENVELOPE_NAME);

        List<HeaderField> headerFields = envelope.getHeaderFields();

        System.out.println("========== HeaderField Begin ============= ");

        for (HeaderField hf : headerFields) {
            if (hf.getName() != null && hf.getConstant() != null) {
                System.out.println("name: " + hf.getName() + " constant: " + hf.getConstant());
            } else {
                System.out.println("name: " + hf.getName() + " tag: " + hf.getTag());
            }
        }

        System.out.println("========== HeaderField End ============= ");
    }

    @Test
    public void testDataFieldMT103() throws Exception {

        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap mt103 = loader.findByName("MT103");

        List<DataField> dataFields = mt103.getDataFields();

        System.out.println("========== DataField Begin ============= ");
        for (DataField df : dataFields) {
            if (df.getName() != null && df.getConstant() != null) {
                System.out.println("name: " + df.getName() + " constant: " + df.getConstant());
            } else {
                System.out.println("name: " + df.getName() + " tag: " + df.getTag());
            }
        }

        System.out.println("========== DataField End ============= ");
    }

    @Test
    public void testDataBlockMT103() throws Exception {

        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap mt103 = loader.findByName("MT103");

        List<DataBlock> dataBlocks = mt103.getDataBlocks();

        assertEquals(3, dataBlocks.size());
        System.out.println("========== DataBlock Begin ============= ");
        for (DataBlock db : dataBlocks) {
            System.out.println("name: " + db.getName() + "  repeat: " + db.getRepeat());
            
            List<DataTypeChoice> choices = db.getDataTypeChoices();
            for (DataTypeChoice choice:choices) {
                switch (choice.getChosen()) {
                    case DATAFIELD:
                        String tag = choice.getDataField().getTag();
                        System.out.println("tag: " + tag);
                        break;
                    case FIELDOPTIONS:
                        List<DataField> dadaFields = choice.getFieldOptions().getDataFields();
                        String oTag = choice.getFieldOptions().getTag();
                        System.out.println("optional tag: " + oTag);
                        for (DataField f:dadaFields) {
                            System.out.println("\t tag: "+f.getTag());
                        }
                        break;
                    default:
                        break;
                }
            }
            System.out.println("========== DataBlock End ============= ");
        }
    }

    @Test
    public void testDataBlockMT110() throws Exception {

        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap mt110 = loader.findByName("MT110");

        List<DataBlock> dataBlocks = mt110.getDataBlocks();

        assertEquals(1, dataBlocks.size());
        System.out.println("========== DataBlock Begin ============= ");
        for (DataBlock db : dataBlocks) {
            System.out.println("name: " + db.getName() + "  repeat: " + db.getRepeat());
            List<DataTypeChoice> choices = db.getDataTypeChoices();
            for (DataTypeChoice choice:choices) {
                switch (choice.getChosen()) {
                    case DATAFIELD:
                        String tag = choice.getDataField().getTag();
                        System.out.println("tag: " + tag);
                        break;
                    case FIELDOPTIONS:
                        List<DataField> dadaFields = choice.getFieldOptions().getDataFields();
                        String oTag = choice.getFieldOptions().getTag();
                        System.out.println("optional tag: " + oTag);
                        for (DataField f:dadaFields) {
                            System.out.println("\t tag: "+f.getTag());
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        System.out.println("========== DataBlock End ============= ");
    }

    @Test
    public void testDataBlockMT202() throws Exception {

        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"2018" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_2018);
        MessageMap mt202 = loader.findByName("MT202");

        List<DataField> dataFields = mt202.getDataFields();

        System.out.println("========== DataField Begin ============= ");
        for (DataField df : dataFields) {
            if (df.getName() != null && df.getConstant() != null) {
                System.out.println("name: " + df.getName() + " constant: " + df.getConstant());
            } else {
                System.out.println("name: " + df.getName() + " tag: " + df.getTag());
            }
        }

        System.out.println("========== DataField End ============= ");
    }
    
    @Test
    public void testMxMessageMapsLoader() throws XMLParseException {
        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"mx" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_MX);
        assertNotNull(loader);

        MessageMap envelope = loader.findByName("swift_envelope");

        String expected = "swift_envelope";
        String actual = envelope.getName();
        assertEquals(expected, actual);

        envelope = loader.findByName("swift_xyz");

        assertNull(envelope);
    }
    
    @Test
    public void testMxMT103() throws Exception {

        MessageMapsLoader loader = new MessageMapsLoader("mapping" + System.getProperty("file.separator")
                +"mx" + System.getProperty("file.separator")
                + MessageMapConstant.TI_SWIFTMESSAGE_MX);
        MessageMap mt103 = loader.findByName("MT103");

        List<DataBlock> dataBlocks = mt103.getDataBlocks();

        assertEquals(3, dataBlocks.size());
        System.out.println("========== DataBlock Begin ============= ");
        for (DataBlock db : dataBlocks) {
            System.out.println("name: " + db.getName() + "  repeat: " + db.getRepeat());
            
            List<DataTypeChoice> choices = db.getDataTypeChoices();
            for (DataTypeChoice choice:choices) {
                switch (choice.getChosen()) {
                    case DATAFIELD:
                        String tag = choice.getDataField().getTag();
                        System.out.println("tag: " + tag);
                        break;
                    case FIELDOPTIONS:
                        List<DataField> dadaFields = choice.getFieldOptions().getDataFields();
                        String oTag = choice.getFieldOptions().getTag();
                        System.out.println("optional tag: " + oTag);
                        for (DataField f:dadaFields) {
                            System.out.println("\t tag: "+f.getTag());
                        }
                        break;
                    default:
                        break;
                }
            }
            System.out.println("========== DataBlock End ============= ");
        }
    }

}
