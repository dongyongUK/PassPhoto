package com.misys.tiplus2.swift.mx.message;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MXMessageFieldHelperUnitTest {

	@Test
	public void testGetArraySize() {
		String field1="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Amt";
		
		int rtn = MXMessageFieldHelper.getArraySize(field1);
		assertEquals(Integer.MAX_VALUE, rtn);
		
		field1="AdrLine[3]";
		rtn = MXMessageFieldHelper.getArraySize(field1);
		assertEquals(3, rtn);
		
	}
	
	@Test
    public void testGetArrayKeyAtIndx() {
        String path="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n]";
        String tag="Amt";
        String rtn = MXMessageFieldHelper.getArrayKeyAtIndex(path, tag, 1);
        
        String expected="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf";
        assertEquals(expected, rtn);
       
        path="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n].Agt.FinInstnId.PstlAdr";
        tag = "AdrLine[3]";
        expected = "Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf.Agt.FinInstnId.PstlAdr.AdrLine";
        
        rtn = MXMessageFieldHelper.getArrayKeyAtIndex(path, tag, 2);
        
        assertEquals(expected, rtn);
    }
	
	@Test
    public void testRemoveFirstArray() {
        String path1="Document.FIToFICstmrCdtTrf.CdtTrfTxInf";
        String path2="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n]";
        String path3="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n].InfLine";
        String path4="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n].Lines[n]";
        String path5="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n].Lines[n].line1";
       
        String exp1="Document.FIToFICstmrCdtTrf.CdtTrfTxInf";
        String exp2="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf";
        String exp3="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf.InfLine";
        String exp4="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf.Lines[n]";
        String exp5="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf.Lines[n].line1";
        
        String rtn = MXMessageFieldHelper.removeFirstArraySigns(path1);
        assertEquals(exp1, rtn);
        
        rtn = MXMessageFieldHelper.removeFirstArraySigns(path2);
        assertEquals(exp2, rtn);
        
        rtn = MXMessageFieldHelper.removeFirstArraySigns(path3);
        assertEquals(exp3, rtn);
        
        rtn = MXMessageFieldHelper.removeFirstArraySigns(path4);
        assertEquals(exp4, rtn);
        
        rtn = MXMessageFieldHelper.removeFirstArraySigns(path5);
        assertEquals(exp5, rtn);
    }

   @Test 
   public void testGetHumberOfArray() {
	  
       String path1="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Agt.FinInstnId";
       String path2="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.|ChrgsInf[n].Agt.FinInstnId.PstlAdr";
       String path3="Document.FIToFICstmrCdtTrf.CdtTrfTxInf";
       String tag1="Nm";
       String tag2="AdrLine[3]";
       String tag3="LEI";
       
       int actual = MXMessageFieldHelper.countNumberOfArray(path1, tag1);
       assertEquals(1, actual);
       
       actual = MXMessageFieldHelper.countNumberOfArray(path2, tag2);
       assertEquals(2, actual);
       
       actual = MXMessageFieldHelper.countNumberOfArray(path3, tag3);
       assertEquals(0, actual);
   }
   
   @Test
   public void testgetLastArray() {
       String key="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n].FinInstnId[3]";
       
       String actual = MXMessageFieldHelper.getLastArrayKey(key);
       assertEquals("Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf.FinInstnId[3]", actual);
       
   }
   
   @Test
   public void testgetFirstArrayKey() {
       String key="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n].FinInstnId[3].inf[n]";
       
       String actual = MXMessageFieldHelper.getFirstArrayKey(key);
       assertEquals("Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n]", actual);   
   }
   
   @Test
   public void testgetArrayKey1() {
       String key="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n].FinInstnId[3].inf[n]";
       
       String actual = MXMessageFieldHelper.getArrayKey1(key,0);
       assertEquals("Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf[n]", actual);
       
       int fromIndex = actual.length();
       actual = MXMessageFieldHelper.getArrayKey1(key,fromIndex+3);
       assertEquals("Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf.FinInstnId[3]", actual);
       
       fromIndex = actual.length();
       actual = MXMessageFieldHelper.getArrayKey1(key,fromIndex+5);
       assertEquals("Document.FIToFICstmrCdtTrf.CdtTrfTxInf.ChrgsInf.FinInstnId.inf[n]", actual);
   }
   
   @Test
   public void testgetArrayFirstKey() {
       String path="Document.FIToFICstmrCdtTrf.CdtTrfTxInf.RgltryRptg[10].Dtls[n]";
       String tag="Inf[n]";
       String actual = MXMessageFieldHelper.getFirstArrayKey(path, tag, 61);
       assertEquals("Document.FIToFICstmrCdtTrf.CdtTrfTxInf.RgltryRptg.Dtls.Inf[n]", actual);
   }
}
