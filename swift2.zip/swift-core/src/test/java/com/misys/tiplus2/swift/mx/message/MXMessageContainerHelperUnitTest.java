package com.misys.tiplus2.swift.mx.message;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * 
 * @author DaiD1
 *
 */
public class MXMessageContainerHelperUnitTest {

    @Test
    public void testMtDateToMxDate() {
        String mtdate="230612";
        
        String actual =MXMessageContainerHelper.mtDateToMxDate(mtdate);
        String expected="2023-06-12";
        assertEquals(expected, actual);
        
        mtdate="20230708";
        actual =MXMessageContainerHelper.mtDateToMxDate(mtdate);
        expected="2023-07-08";
        assertEquals(expected, actual);
        
        mtdate="30708";
        actual =MXMessageContainerHelper.mtDateToMxDate(mtdate);
        assertNull(actual);
    }

    @Test
    public void testIsDigit() {
        
        assertTrue(MXMessageContainerHelper.isDigit("8341"));
        assertFalse(MXMessageContainerHelper.isDigit("A8341"));
    }

    @Test
    public void testcreateMXDocwithEnvelop() {
        
        String header="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n"
                + "<AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.02\">\r\n"
                + "    <Fr>\r\n"
                + "        <FIId>\r\n"
                + "            <FinInstnId>\r\n"
                + "                <BICFI>PTSQGBB0XAAA</BICFI>\r\n"
                + "            </FinInstnId>\r\n"
                + "        </FIId>\r\n"
                + "    </Fr>\r\n"
                + "    <MsgDefIdr>pacs.008.001.08</MsgDefIdr>\r\n"
                + "</AppHdr>";
        String document="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n"
                + "<Document xmlns=\"urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08\">\r\n"
                + "    <FIToFICstmrCdtTrf>\r\n"
                + "        <GrpHdr>\r\n"
                + "            <MsgId>CPC/MBW/21/0352</MsgId>\r\n"
                + "            <SttlmInf>\r\n"
                + "                <SttlmAcct>\r\n"
                + "                    <Nm>/9018-987176-00101</Nm>\r\n"
                + "                </SttlmAcct>\r\n"
                + "            </SttlmInf>\r\n"
                + "        </GrpHdr>\r\n"
                + "    </FIToFICstmrCdtTrf>\r\n"
                + "</Document>";
        
           String actual = MXMessageContainerHelper.createMXDocwithEnvelop(header, document);
           String expected="";
        
    }
}
