package com.misys.tiplus2.swift;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.misys.tiplus2.foundations.spring.beans.BeanFactory;

public class ContextTestHelper {

    final static String springContextFile = "classpath:/swift-processor-meridian-spring.xml";

    public static void initialiseSpringContext() {

        try {
            ApplicationContext ctx = new ClassPathXmlApplicationContext(springContextFile);
            BeanFactory.getInstance().setApplicationContext(ctx);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static Object getBeanByName(String beanName) {
        return BeanFactory.getInstance().getBean(beanName);
    }
}
