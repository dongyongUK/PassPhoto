package com.misys.tiplus2.swift.message;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SWIFTMessageContainerUnitTest {

    @Test
    public void testSetServiceIdNotNull() {
        MTMessageContainer mt700 = new MTMessageContainer("700");

        mt700.addHeaderField(new TagDataField(MTMessageConstant.B1_SERVICE_ID_TAG,
                MTMessageConstant.B1_SERVICE_ID_FIN_VALUE));

        assertEquals("01", mt700.getServiceId());

    }

    @Test
    public void testSetServiceIdNull() {
        MTMessageContainer mt700 = new MTMessageContainer("700");

        assertEquals("01", mt700.getServiceId());

    }

    @Test
    public void testSetServiceIdF21() {
        MTMessageContainer mtF21 = new MTMessageContainer("F21");

        assertEquals("21", mtF21.getServiceId());

    }

}
