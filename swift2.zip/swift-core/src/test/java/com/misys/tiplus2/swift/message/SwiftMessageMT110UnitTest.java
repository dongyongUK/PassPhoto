package com.misys.tiplus2.swift.message;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class SwiftMessageMT110UnitTest {

    MTMessageContainer mt110;

    @Before
    public void setUp() {

        mt110 = new TestMessageMT110().getMt110();
    }

    @Test
    public void testAddDataBlock() {

        List<TagDataBlock> rptf = mt110.getDataBlockList("Cheque");

        assertEquals(3, rptf.size());

        rptf = mt110.getDataBlockList("Cheque2");

        assertNull(rptf);

        int number_of_fields_in_block = 7;

        int max_number_of_repeats = 10;
        List<TagDataBlock> listOfBlock = new ArrayList<TagDataBlock>(max_number_of_repeats);

        Map<String, TagDataField> rpbk1 = new HashMap<String, TagDataField>(number_of_fields_in_block);
        rpbk1.put("21", new TagDataField("21", "111111", null));
        rpbk1.put("30", new TagDataField("30", "070501", null));
        rpbk1.put("32A", new TagDataField("32A", "070501GBP100,00", null));
        rpbk1.put("59", new TagDataField("59", "Mr. Line One\nBurnham\nBerkshire", null));
        TagDataBlock b1 = new TagDataBlock("Cheque", rpbk1);
        listOfBlock.add(b1);

        Map<String, TagDataField> rpbk2 = new HashMap<String, TagDataField>(number_of_fields_in_block);
        rpbk2.put("21", new TagDataField("21", "22222", null));
        rpbk2.put("30", new TagDataField("30", "070502", null));
        rpbk2.put("32A", new TagDataField("32A", "070502GBP200,00", null));
        rpbk2.put("59", new TagDataField("59", "Mr Line Tow\nGlasgow\nScotland", null));
        TagDataBlock b2 = new TagDataBlock("Cheque", rpbk2);
        listOfBlock.add(b2);

        Map<String, TagDataField> rpbk3 = new HashMap<String, TagDataField>(number_of_fields_in_block);
        rpbk3.put("21", new TagDataField("21", "333333", null));
        rpbk3.put("30", new TagDataField("30", "070503", null));
        rpbk3.put("32A", new TagDataField("32A", "070503GBP300,00", null));
        rpbk3.put("59", new TagDataField("59", "Mr Line Three\nReading\nBerkshire", null));
        TagDataBlock b3 = new TagDataBlock("Cheque", rpbk3);
        listOfBlock.add(b3);

        Map<String, TagDataField> rpbk4 = new HashMap<String, TagDataField>(number_of_fields_in_block);
        rpbk4.put("21", new TagDataField("21", "444444", null));
        rpbk4.put("30", new TagDataField("30", "070504", null));
        rpbk4.put("32A", new TagDataField("32A", "070504GBP400,00", null));
        rpbk4.put("59", new TagDataField("59", "Mr Line Four\nReading\nBerkshire", null));
        TagDataBlock b4 = new TagDataBlock("Cheque", rpbk4);
        listOfBlock.add(b4);

        mt110.addDataBlock("Cheque", listOfBlock);

        rptf = mt110.getDataBlockList("Cheque");

        assertEquals(4, rptf.size());
    }

}
