package com.misys.tiplus2.swift.message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestMessageMT103 {

    MTMessageContainer mt103;

    public TestMessageMT103() {

        mt103 = new MTMessageContainer("103");
        TagDataField headerField = new TagDataField(MTMessageConstant.B1_APPLICATION_ID_TAG,
                MTMessageConstant.B1_APPLICATION_ID_VALUE);
        mt103.addHeaderField(headerField);
        mt103.addHeaderField(new TagDataField(MTMessageConstant.B1_SERVICE_ID_TAG,
                MTMessageConstant.B1_SERVICE_ID_FIN_VALUE));
        mt103.addHeaderField(new TagDataField("LogicalTerminalAddress", "KAPIGB2L1543"));
        mt103.addHeaderField(new TagDataField("Session", "1234"));
        mt103.addHeaderField(new TagDataField("Sequence", "654321"));

        mt103.addHeaderField(new TagDataField("InputOutputIdentifier", "O"));
        mt103.addHeaderField(new TagDataField("ReceiverAddress", "BANKBEBBAXXX"));
        mt103.addHeaderField(new TagDataField("MessageType", "103"));
        mt103.addHeaderField(new TagDataField("Priority", "N"));
        mt103.addHeaderField(new TagDataField("InputTime", "1233"));
        mt103.addHeaderField(new TagDataField("MIR", "970103BANKBEBBAXXX2222123456"));
        mt103.addHeaderField(new TagDataField("OutputDate", "170510"));
        mt103.addHeaderField(new TagDataField("OutputTime", "1125"));

        mt103.addHeaderField(new TagDataField("113", "{113:xxxx}"));
        mt103.addHeaderField(new TagDataField("108", "{108:N-XXX-A01}"));

        mt103.addHeaderField(new TagDataField("Trailer", "{MAC:00000000}{CHK:04E4CC43D6D9}"));

        TagDataField dataField = new TagDataField("20", "CPC00001009");
        mt103.addDataField(dataField);

        int max_number_of_repeats = 3;
        List<TagDataBlock> listOfBlock = new ArrayList<TagDataBlock>(max_number_of_repeats);

        int number_of_fields_in_block = 1;
        Map<String, TagDataField> fieldList1 = new HashMap<String, TagDataField>();
        fieldList1.put("13C", new TagDataField("13C", "/SNDTIME/0100+0100"));
        TagDataBlock block1 = new TagDataBlock("Time", fieldList1);
        listOfBlock.add(block1);

        Map<String, TagDataField> fieldList2 = new HashMap<String, TagDataField>();
        fieldList2.put("13C", new TagDataField("13C", "/SNDTIME/0200+0100"));
        TagDataBlock block2 = new TagDataBlock("Time", fieldList2);
        listOfBlock.add(block2);

        Map<String, TagDataField> fieldList3 = new HashMap<String, TagDataField>();
        fieldList3.put("13C", new TagDataField("13C", "/SNDTIME/0300+0100"));
        TagDataBlock block3 = new TagDataBlock("Time", fieldList3);
        listOfBlock.add(block3);

        mt103.addDataBlock("Time", listOfBlock);

        mt103.addDataField(new TagDataField("23B", "CRED"));

        max_number_of_repeats = 6;
        listOfBlock = new ArrayList<TagDataBlock>(max_number_of_repeats);

        number_of_fields_in_block = 1;

        fieldList1 = new HashMap<String, TagDataField>();
        fieldList1.put("23E", new TagDataField("23E", "GBP1039,05"));
        block1 = new TagDataBlock("Instruction", fieldList1);
        listOfBlock.add(block1);

        fieldList2 = new HashMap<String, TagDataField>();
        fieldList2.put("23E", new TagDataField("23E", "USD3039,05"));
        block2 = new TagDataBlock("Instruction", fieldList2);
        listOfBlock.add(block2);

        fieldList3 = new HashMap<String, TagDataField>();
        fieldList3.put("23E", new TagDataField("23E", "EUD6039,05"));
        block3 = new TagDataBlock("Instruction", fieldList3);
        listOfBlock.add(block3);

        mt103.addDataBlock("Instruction", listOfBlock);

        mt103.addDataField(new TagDataField("26T", "AAA"));
        mt103.addDataField(new TagDataField("32A", "070419GBP597865,80"));
        mt103.addDataField(new TagDataField("50K", "/Ext 0543001123799USD"));
        mt103.addDataField(new TagDataField("59A", "/796917971901"));
        mt103.addDataField(new TagDataField("72", "/REC/PLEASE ADVISE PAY SOONEST" + "\n" + "// AS PER ARRANGEMENT"));
    }

    public MTMessageContainer getMt103() {
        return mt103;
    }

}
