package com.misys.tiplus2.swift.message;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.misys.tiplus2.swift.FileLoader;

public class MT798ScoreFinMessageHelperUnitTest {

    String finMessage;

    @Before
    public void setUp() throws Exception {

        finMessage = FileLoader.loadFile("messages/2021/MT798(736)In.txt");

    }

    @Test
    public void testExrtractMT798() {
        String mt798 = MT798ScoreFINMessageHelper.extractMT798(finMessage);
        System.out.println(mt798);
    }

    @Test
    public void testExtractIndexMessage() {

        String exMt798 = MT798ScoreFINMessageHelper.extractIndexMessage(finMessage);
        System.out.println(exMt798);
    }

    @Test
    public void testExtractDetailMessage() {

        String exMt798 = MT798ScoreFINMessageHelper.extractDetailsMessage(finMessage, ":21P:");
        System.out.println(exMt798);
    }
    
    @Test
    public void testExtractSubType() {

        String subType = MT798ScoreFINMessageHelper.extractSubType(finMessage);
        assertEquals("736", subType);
    }
    
    
    @Test
    public void testExtractAmendmentNumber() {

        String value = MT798ScoreFINMessageHelper.getFirstField26E(finMessage);
        assertEquals(3, Integer.parseInt(value));
    }

    @Test
    public void testExtractSequenceTag() {

        String seqTag = MT798ScoreFINMessageHelper.getSequence(finMessage);
        assertEquals("1/1", seqTag);
    }

    @Test
    public void testExtractReferenceTag() {

        String seqTag = MT798ScoreFINMessageHelper.getReferenceTag(finMessage);
        assertEquals("21P", seqTag);
    }

    @Test
    public void testExtractReference() {

        String seqTag = MT798ScoreFINMessageHelper.getReferenceValue(finMessage);
        assertEquals("6555/6771", seqTag);
    }

    @Test
    public void testGetHeader() {

        String header = MT798ScoreFINMessageHelper.getHeader(finMessage);
        System.out.println(header);
    }

    @Test
    public void testGetEmbededMessage() {

        String value77E = MT798ScoreFINMessageHelper.extractIndexMessage(finMessage);
        String refTag = MT798ScoreFINMessageHelper.getReferenceTag(finMessage);
        String embeddedMessage = MT798ScoreFINMessageHelper.getEmbeddedFINMessage(value77E, ":" + refTag + ":");

        System.out.println(embeddedMessage);

    }

    @Test
    public void testgetSequenceFrom77E() throws Exception {

        String swiftText = FileLoader.loadFile("messages/2021/MT798(771)In.txt");

        String actual = MT798ScoreFINMessageHelper.getSequenceFrom77E(swiftText);

        String expected = "1/2";

        assertEquals(expected, actual);
    }

    @Test
    public void testgetFromMT798Tag20() throws Exception {

        String swiftText = FileLoader.loadFile("messages/2021/MT798(771)In.txt");

        String actual = MT798ScoreFINMessageHelper.getFromMT798Tag20(swiftText);

        assertTrue(actual.startsWith(":20:"));
    }
    
    @Test
    public void testGetTotalNumbderFromSequence() throws Exception {

        String swiftText = FileLoader.loadFile("messages/2021/MT798(771)In.txt");

        String seq = MT798ScoreFINMessageHelper.getSequenceFrom77E(swiftText);

        String actual = MT798ScoreFINMessageHelper.getTotalNumbderFromSequence(seq);

        String expected = "2";

        assertEquals(expected, actual);

        actual = MT798ScoreFINMessageHelper.getSequenceNumber(seq);

        expected = "1";

        assertEquals(expected, actual);
    }

}
