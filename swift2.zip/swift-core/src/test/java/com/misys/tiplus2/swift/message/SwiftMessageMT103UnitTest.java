package com.misys.tiplus2.swift.message;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class SwiftMessageMT103UnitTest {

    MTMessageContainer mt103;

    @Before
    public void setUp() {
        mt103 = new TestMessageMT103().getMt103();
    }

    @Test
    public void testAddDataBlock() {

        List<TagDataBlock> listOfBlock = new ArrayList<TagDataBlock>();

        Map<String, TagDataField> list13 = new HashMap<String, TagDataField>();
        list13.put("13C", new TagDataField("13C", "/OKOKOKO/000+0100"));
        TagDataBlock b1 = new TagDataBlock("Time", list13);
        listOfBlock.add(b1);

        list13 = new HashMap<String, TagDataField>();
        list13.put("13C", new TagDataField("13C", "/OKOKOKO/100+0200"));
        TagDataBlock b2 = new TagDataBlock("Time", list13);
        listOfBlock.add(b2);

        list13 = new HashMap<String, TagDataField>();
        list13.put("13C", new TagDataField("13C", "/OKOKOKO/200+0300"));
        TagDataBlock b3 = new TagDataBlock("Time", list13);
        listOfBlock.add(b3);

        mt103.addDataBlock("Time", listOfBlock);

        String expected = "/OKOKOKO/100+0200";

        List<TagDataBlock> tbk = mt103.getDataBlocksByName().get("Time");
        String actual = tbk.get(1).getDataFields().get("13C").getValue();
        assertEquals(expected, actual);
    }

    @Test
    public void testGetDataBlock() {

        List<TagDataBlock> blockList = mt103.getDataBlockList("Instruction");
        TagDataBlock tbk = blockList.get(0);

        int s = blockList.size();
        assertEquals(3, s);
        String expected = "GBP1039,05";
        String actual = tbk.getDataFields().get("23E").getValue();
        assertEquals(expected, actual);

    }

    @Test
    public void testGetHeaderField() {

        TagDataField field1 = mt103.getHeaderField("MIR");
        String expected = "970103BANKBEBBAXXX2222123456";
        String actual = field1.getValue();
        assertEquals(expected, actual);

        expected = "1234";
        actual = mt103.getHeaderField("Session").getValue();
        assertEquals(expected, actual);

        expected = "103";
        actual = mt103.getHeaderField("MessageType").getValue();
        assertEquals(expected, actual);

        expected = "{108:N-XXX-A01}";
        actual = mt103.getHeaderField("108").getValue();
        assertEquals(expected, actual);

        expected = "CRED";
        actual = mt103.getDataFieldByKey("23B").getValue();
        assertEquals(expected, actual);

        expected = "{MAC:00000000}{CHK:04E4CC43D6D9}";
        actual = mt103.getHeaderField("Trailer").getValue();
        assertEquals(expected, actual);

        TagDataField hf = mt103.getHeaderField("KKK");
        assertNull(hf);
    }

    @Test
    public void testGetDataField() {

        String expected = "CRED";
        String actual = mt103.getDataFieldByKey("23B").getValue();
        assertEquals(expected, actual);

        TagDataField f = mt103.getDataFieldByKey("Time");
        assertNull(f);

        f = mt103.getDataFieldByKey("Unknow");
        assertNull(f);
    }

    @Test
    public void testSetDataField() {

        String expected = "TEST1 TEST1";
        mt103.addDataField(new TagDataField("70", expected));

        String actual = mt103.getDataFieldByKey("70").getValue();
        assertEquals(expected, actual);

        expected = "TEST2 TEST2";
        mt103.addDataField(new TagDataField("70", expected));
        actual = mt103.getDataFieldByKey("70").getValue();
        assertEquals(expected, actual);

    }

    @Test
    public void testChangeDataField() {

        TagDataField f = mt103.getDataFieldByKey("20");
        String actual = f.getValue();
        String expected = "CPC00001009";

        assertEquals(expected, actual);

        expected = "QQQ00001009";
        mt103.addDataField(new TagDataField("20", expected));

        actual = mt103.getDataFieldByKey("20").getValue();
        assertEquals(expected, actual);
    }

}
