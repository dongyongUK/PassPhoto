package com.misys.tiplus2.swift.message;

public class MultiLineTestHelper {

    public static String createMultiLineTag(int width, int lines) {

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < lines; i++) {
            result.append(String.format("%03d", i + 1)).append(" ");
            for (int j = 4; j < width - 2; j++) {
                result.append("X");
            }
            if (i + 1 != lines) {
                result.append(MTMessageConstant.WINDOWS_CRLF);
            }
        }
        return result.toString();
    }

}
