package com.misys.tiplus2.swift.multiline;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.misys.tiplus2.swift.message.MultilineHelper;

/**
 * 
 * @author DaiD1
 *
 */
public class MultilineHelperTest {

    @Test
    public void testFormatField() {
        String value = "123456789 123456789 12346\r\n" + " 23456789 123456789 12345\r\n"
                + "  3456789 123456789 12345\r\n" + "12345678  1234567   12345";
        StringBuilder errors = new StringBuilder();
        String result = MultilineHelper.formatField("45A", value, 25, 4, 0,true, "xxx", errors);

        assertEquals(value, result);
        assertEquals(0, errors.length());
    }

    @Test
    public void testFormatField2() {
        String value = "123456789 123456789 12345\r\n" + "123456789 123456789 123456789\r\n"
                + "123456789 123456789 12345";
        StringBuilder errors = new StringBuilder();
        String result = MultilineHelper.formatField("45A", value, 25, 4, 0,true, "xxx", errors);
        String expected = "123456789 123456789 12345\r\n" + "123456789 123456789\r\n" + "123456789\r\n"
                + "123456789 123456789 12345";
        assertEquals(expected, result);
        assertEquals(0, errors.length());
    }

    @Test
    public void testFormatField3() {
        String value = "123456789 123456789 12345\r\n" + "123456789 123456789 123456789\r\n"
                + "123456789 123456789 12345";
        StringBuilder errors = new StringBuilder();
        String result = MultilineHelper.formatField("45A", value, 10, 2,0, true, "x", errors);
        String expected = "Field format error: '2*10x'";
        String actual = errors.toString();
        assertEquals(expected, actual);

    }
    
    @Test
    public void testFormatField4() {
        String value = "ODBC\r\n" + "123456789 123456789 123456789\r\n"
                + "123456789 12345";
        StringBuilder errors = new StringBuilder();
        String actual = MultilineHelper.formatField("23R", value, 10,5,1, true, "x", errors);
        
        String expected = "ODBC\r\n123456789\r\n123456789\r\n123456789\r\n123456789\r\n12345";
        //String actual = errors.toString();
        assertEquals(expected, actual);

    }
    
    @Test
    public void testFormatField5() {
        String value = "ODBC\r\n" + "123456789 123456789\r\n"
                + "123456789 12345";
        StringBuilder errors = new StringBuilder();
        String actual = MultilineHelper.formatField("24G", value, 10,5,1, true, "x", errors);
        
        String expected = "ODBC\r\n123456789\r\n123456789\r\n123456789\r\n12345";
        //String actual = errors.toString();
        assertEquals(expected, actual);

    }
    
    @Test
    public void testFormatField6() {
        String value = "ODBC\r\n" + "123456789 123456789 123456789\r\n"
                + "123456789 12345";
        StringBuilder errors = new StringBuilder();
        String result = MultilineHelper.formatField("23R", value, 10,4,1, true, "x", errors);
        
        String expected = "Field format error: '4*10x'";
        String actual = errors.toString();
        
        assertEquals(expected, actual);

    }
    
    @Test
    public void testFormatField7() {
        String value = "123456789 123456789 123456789\r\n"
                + "123456789 12345\r\n123456789OABCD";
        StringBuilder errors = new StringBuilder();
        String actual = MultilineHelper.formatField("41D", value, 10,5,-1, true, "x", errors);
        
        String expected = "123456789\r\n123456789\r\n123456789\r\n123456789\r\n12345\r\n123456789OABCD";
        
        assertEquals(expected, actual);

    }
    
    @Test
    public void testFormatField8() {
        String value = "/HOLD/this is a field test at line1\r\n"
                + "//this is a field test at line 2 AB\r\n//this is a field test at line 3 CD";
        StringBuilder errors = new StringBuilder();
        String actual = MultilineHelper.formatField("77B", value, 35,3,0, true, "x", errors);
        
        String expected = value;
        
        assertEquals(expected, actual);

    }
    
    @Test
    public void testFormatField9() {
        String value = "/HOLD/this is a field test at line1 "
                + "this is a field test at line 2 AB this is a field test at line 3 CD";
        StringBuilder errors = new StringBuilder();
        String actual = MultilineHelper.formatField("77B", value, 35,3,0, true, "x", errors);
        
        String expected = "/HOLD/this is a field test at line1\r\n"
                + "//this is a field test at line 2 AB\r\n//this is a field test at line 3 CD";
        
        assertEquals(expected, actual);

    }
    
    @Test
    public void testFormatField10() {
        String value = "/HOLD/1234567890123456789012345678901234567890123456789012345678901234567890";
               
        StringBuilder errors = new StringBuilder();
        String actual = MultilineHelper.formatField("77B", value, 35,3,0, true, "x", errors);
        
        String expected = "/HOLD/12345678901234567890123456789\r\n"
                + "//012345678901234567890123456789012\r\n//34567890";
        
        assertEquals(expected, actual);

    }
}
