package com.misys.tiplus2.swift.message;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class MT798ScoreMessageHelperUnitTest {
 

    @Test
    public void testisIndexMessage() {
        List<String> indexMessages = new ArrayList<String>();
        indexMessages.add("770");
        indexMessages.add("771");
        
        MT798ScoreMessageHelper helper = new  MT798ScoreMessageHelper();
        helper.setIndexMessages(indexMessages);
        boolean actual = helper.isIndexMessage("770");
        assertEquals(true,actual);
        
        actual = helper.isIndexMessage("700");
        assertEquals(false,actual);
      
    }

    @Test
    public void testisDetailsMessage() {
        List<String> detailsMessages = new ArrayList<String>();
        detailsMessages.add("700");
        detailsMessages.add("701");
        
        MT798ScoreMessageHelper helper = new  MT798ScoreMessageHelper();
        helper.setIndexMessages(detailsMessages);
        boolean actual = helper.isDetailsMessage("770");
        assertEquals(false,actual);
        
        actual = helper.isIndexMessage("700");
        assertEquals(true,actual);
      
    }

    @Test
    public void testRefForDetailsMessage() {
        List<String> indexMessages = new ArrayList<String>();
        indexMessages.add("722");
        indexMessages.add("770-21A");
        indexMessages.add("771-21P");
       
        List<String> detailsMessages = new ArrayList<String>();
        detailsMessages.add("700");
        detailsMessages.add("701");
        
        MT798ScoreMessageHelper helper = new  MT798ScoreMessageHelper();
        helper.setIndexMessages(indexMessages);
        helper.setDetailsMessages(detailsMessages);
        
        boolean actual = helper.isDetailsMessage("770");
        assertEquals(false,actual);
        
        actual = helper.isIndexMessage("770");
        assertEquals(true,actual);
        
        actual = helper.isDetailsMessage("700");
        assertEquals(true,actual);
        
        String result = helper.getReferenceForDetailsMessage("722");
        assertEquals(null,result);
        
        result = helper.getReferenceForDetailsMessage("700");
        assertEquals(null,result);
        
        result = helper.getReferenceForDetailsMessage("770");
        assertEquals("21A",result);
    }
}
