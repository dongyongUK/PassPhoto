package com.misys.tiplus2.swift.message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestMessageMT110 {

    MTMessageContainer mt110;

    public TestMessageMT110() {

        mt110 = new MTMessageContainer("110");
        TagDataField headerField = new TagDataField(MTMessageConstant.B1_APPLICATION_ID_TAG,
                MTMessageConstant.B1_APPLICATION_ID_VALUE);
        mt110.addHeaderField(headerField);
        mt110.addHeaderField(new TagDataField(MTMessageConstant.B1_SERVICE_ID_TAG,
                MTMessageConstant.B1_SERVICE_ID_FIN_VALUE));

        mt110.addHeaderField(new TagDataField("LogicalTerminalAddress", "BACIGB2L1500"));
        mt110.addHeaderField(new TagDataField("Session", "4321"));
        mt110.addHeaderField(new TagDataField("Seqence", "666666"));

        mt110.addHeaderField(new TagDataField("InputOutputIdentifier", "I"));
        mt110.addHeaderField(new TagDataField("MessageType", "110"));
        mt110.addHeaderField(new TagDataField("ReceiverAddress", "BARCGB2LXXXX"));
        mt110.addHeaderField(new TagDataField("DeliveryMonitoring", "2"));
        mt110.addHeaderField(new TagDataField("Priority", "U"));
        mt110.addHeaderField(new TagDataField("ObsolescencePeriod", "003"));

        mt110.addHeaderField(new TagDataField("108", "{108:N-XXX-A01}"));
        mt110.addHeaderField(new TagDataField("Trailer", "{MAC:00000000}{CHK:04E4CC43D6D9}"));

        mt110.addDataField(new TagDataField("20", "AQW00001002"));
        mt110.addDataField(new TagDataField("53B", "/82600826"));

        int number_of_fields_in_block = 7;
        int max_number_of_repeats = 10;
        List<TagDataBlock> listOfBlock = new ArrayList<TagDataBlock>(max_number_of_repeats);

        Map<String, TagDataField> fieldList1 = new HashMap<String, TagDataField>();
        fieldList1.put("21", new TagDataField("21", "121212"));
        fieldList1.put("30", new TagDataField("30", "060121"));
        fieldList1.put("32A", new TagDataField("32A", "060121GBP100,00"));
        fieldList1.put("59", new TagDataField("59", "Mr. First. Barkis 11 Trotwood Lane\nBurnham\nBerkshire"));
        TagDataBlock block1 = new TagDataBlock("Cheque", fieldList1);
        listOfBlock.add(block1);

        Map<String, TagDataField> fieldList2 = new HashMap<String, TagDataField>();
        fieldList2.put("21", new TagDataField("21", "121212"));
        fieldList2.put("30", new TagDataField("30", "060125"));
        fieldList2.put("32A", new TagDataField("32A", "060125GBP500,00"));
        fieldList2.put("59", new TagDataField("59", "r. Second. Dave 44 Highclear Street\nGlasgow\nScotland"));
        TagDataBlock block2 = new TagDataBlock("Cheque", fieldList2);
        listOfBlock.add(block2);

        Map<String, TagDataField> fieldList3 = new HashMap<String, TagDataField>();
        fieldList3.put("21", new TagDataField("21", "121212"));
        fieldList3.put("30", new TagDataField("30", "060130"));
        fieldList3.put("32A", new TagDataField("32A", "060130GBP200,00"));
        fieldList3.put("59", new TagDataField("59", "Mr. Third. Inken 10 Willowmead Close\nReading\nBerkshire"));
        TagDataBlock block3 = new TagDataBlock("Cheque", fieldList3);
        listOfBlock.add(block3);

        mt110.addDataBlock("Cheque", listOfBlock);
    }

    public MTMessageContainer getMt110() {
        return mt110;
    }

}
