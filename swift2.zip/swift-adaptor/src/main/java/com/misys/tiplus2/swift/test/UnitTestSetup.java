package com.misys.tiplus2.swift.test;

import org.junit.BeforeClass;

import com.misys.tiplus2.swift.adaptor.DefaultSWIFTAdaptor;
import com.misys.tiplus2.swift.rules.RulesetController;

public class UnitTestSetup {

	static DefaultSWIFTAdaptor swiftAdaptor = null;
	static RulesetController rulesetController = null;

	final static String springContextFile = "classpath:unittestSwiftSpringContext.xml";

	@BeforeClass
	public static void beforeClass() throws Exception {
		AdaptorAndController adaptorAndController = ContextTestHelper.getAdaptorAndController(springContextFile);
		swiftAdaptor = adaptorAndController.getAdaptor();
		rulesetController = adaptorAndController.getController();
	}

	public DefaultSWIFTAdaptor getSwiftAdaptor() {
		return swiftAdaptor;
	}

	public RulesetController getRulesetController() {
		return rulesetController;
	}

}
