package com.misys.tiplus2.swift.test.adaptor;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.Directives;
import com.misys.tiplus2.swift.FilterDirectives;
import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.TransliterationDirectives;
import com.misys.tiplus2.swift.adaptor.SWIFTAdaptor;
import com.misys.tiplus2.swift.exception.SWIFTMessageException;
import com.misys.tiplus2.swift.test.driver.TestSwiftDriver;

/**
 * 
 * Test SWIFTAdaptorBridge
 * 
 * @author DaiD1
 *
 */
public class TestSWIFTAdaptorBridge implements TestSwiftDriver {

	private static final Logger LOG = LoggerFactory.getLogger(TestSWIFTAdaptorBridge.class);

	private SWIFTAdaptor adaptor;

	private TransliterationDirectives transliterationDirectives;
	private FilterDirectives filterDirectives;
	  private MessageResults lastMessageResults;

	public boolean next() throws Exception {
		Loggers.method().enter(LOG);

		boolean result = false;
		try {
			result = adaptor.generateNextMessageSummary();
		} catch(SWIFTMessageException e) {
			
		}
		Loggers.method().exit(LOG, result);
		return result;
	}

	public void summary(HashMap<String, String> pane, StringBuilder messageBuffer, String rulesYear) throws Exception {

		Loggers.method().enter(LOG, rulesYear);

		String msgType = null;

		try {
			adaptor.generateIncomingMessageSummary(pane, messageBuffer.toString(), rulesYear);
			msgType = pane.get("MessageType");

			if (msgType != null && !msgType.isEmpty()) {
				if (msgType.startsWith("MT")) {
					msgType = msgType.substring(2);
				}
				pane.put("MessageType", msgType);
			}
		} catch (SWIFTMessageException e) {
			throw new RuntimeException("error occurred in summary", e);
		}

		Loggers.method().exit(LOG);

	}

	@Override
	public void setFilter(String pattern) throws Exception {

		Loggers.method().enter(LOG, pattern);

		if (filterDirectives == null) {
			filterDirectives = new FilterDirectives();
		}

		filterDirectives.setCommonFilter(pattern);

		Loggers.method().exit(LOG);
	}

	@Override
	public void setXFilter(String pattern) throws Exception {

		Loggers.method().enter(LOG, pattern);

		if (filterDirectives == null) {
			filterDirectives = new FilterDirectives();
		}

		filterDirectives.setXFilter(pattern);

		Loggers.method().exit(LOG);
	}

	@Override
	public void setZFilter(String pattern) throws Exception {

		Loggers.method().enter(LOG, pattern);

		if (filterDirectives == null) {
			filterDirectives = new FilterDirectives();
		}

		filterDirectives.setZFilter(pattern);

		Loggers.method().exit(LOG);
	}

	@Override
	public void setControl(String ref, String ignore, String trans, String excl) throws Exception {

		Loggers.method().enter(LOG, ref, ignore, trans, excl);

		transliterationDirectives = new TransliterationDirectives();
		transliterationDirectives.setReference(ref);
		transliterationDirectives.setIgnore(ignore);
		transliterationDirectives.setTransliteration(trans);
		transliterationDirectives.setExclusion(excl);

		Loggers.method().exit(LOG);
	}

	@Override
	public boolean format(Object pane, String msgType, StringBuilder strBuilder, StringBuilder errorBuilder,
			boolean transliterate, boolean uppercase, boolean allowLargeNarrative, boolean validate, String ruleSetId)
			throws Exception {

		Loggers.method().enter(LOG, msgType, transliterate, uppercase, allowLargeNarrative, validate, ruleSetId);

		boolean result = false;
		Directives directives = new Directives();

		directives.setTransliteration(transliterationDirectives);
		directives.setFilters(filterDirectives);
		directives.setTransliterationRequired(transliterate);
		directives.setUppercase(uppercase);
		directives.setAllowLargeNarrative(allowLargeNarrative);
		//directives.setValidateMessage(validate);

		if (msgType != null && !msgType.startsWith("MT")) {
			msgType = "MT" + msgType;
		}

		try {
			lastMessageResults = adaptor.convertToRawMessage(ruleSetId, msgType, pane, directives, validate);
		} catch (SWIFTMessageException e) {
			if (lastMessageResults == null) {
				lastMessageResults = new MessageResults();
				lastMessageResults.setMessageHasErrors(true);
			}
			String theErrorMsg = getRootError(e);
			if (theErrorMsg == null || theErrorMsg.isEmpty() || "n/a".equals(theErrorMsg)) {
				theErrorMsg = "Error in converting to SWIFT message, please report this problem to Administrator with log files.";
			}
			 lastMessageResults.setShortRawMessage(theErrorMsg);
		}

		 if (lastMessageResults.getRawMessage() != null) {
	            strBuilder.append(lastMessageResults.getRawMessage());
	     }

		result = (lastMessageResults.isMessageHasErrors()) ? false : true;

		if (lastMessageResults.getErrorText() != null) {
			errorBuilder.append(lastMessageResults.getErrorText());
			result = false;
		}

		Loggers.method().exit(LOG, result);
		return result;
	}

	@Override
	public boolean scanData(Object pane, String msgType, String msgData, StringBuilder errorBuilder, boolean trans,boolean validate,
			String ruleSetId) throws Exception {
		Loggers.method().enter(LOG, msgType, msgData, trans, ruleSetId);

		boolean result = false;
		
		TransliterationDirectives directives = new TransliterationDirectives();
		//directives.setValidateMessage(validate);
		if (trans)
			directives = transliterationDirectives;
		
		try {

			lastMessageResults = adaptor.convertFromRawMessage(ruleSetId, pane, msgData, directives); 
			
			if (lastMessageResults.getErrorText() != null) {
				errorBuilder.append(lastMessageResults.getErrorText());
				result = false;
			}
			result = (lastMessageResults.isMessageHasErrors()) ? false : true;

		} catch (SWIFTMessageException e) {
			errorBuilder.append("An Exception was encountered when scanning a FINMessage - the exception message is");
			errorBuilder.append(getRootError(e));

			result = false;
		}

		Loggers.method().exit(LOG, result);
		return result;
	}
	
	@Override
	public boolean scanData(Object pane, String msgType, String msgData, StringBuilder errorBuilder, boolean trans,
			String rulesYear) throws Exception {
		Loggers.method().enter(LOG, msgType, msgData, trans, rulesYear);
		boolean result = scanData(pane, msgType, msgData, errorBuilder,trans,false,rulesYear);
		Loggers.method().exit(LOG, result);
		return result;
	}

	@Override
	public boolean expand(StringBuilder shortMsg, StringBuilder expMsg, StringBuilder nwShort, StringBuilder nwExp,
			boolean trans) throws Exception {

		Loggers.method().enter(LOG, trans);

		boolean result = false;
		if (lastMessageResults != null) {
			shortMsg.append(lastMessageResults.getShortRawMessage());
			// errMsg.append(lastMessageResults.getValidateRawMessage());
	         expMsg.append(lastMessageResults.getLongRawMessage());

			if (trans) {
				nwShort.append(lastMessageResults.getShortTransliteratedRawMessage());
	            nwExp.append(lastMessageResults.getLongTransliteratedRawMessage());
			}

			result = true;
		}

		Loggers.method().exit(LOG, result);
		return result;
	}

	@Override
	public String getRuleYears() {

		Loggers.method().enter(LOG);

		StringBuilder yearsBuilder = new StringBuilder();

		try {
			 List<String> yearList = adaptor.getRulesetIds();

	            int i = 0;
	            for (String year : yearList) {
	                if (i > 0) {
	                    yearsBuilder.append(",");
	                }
	                yearsBuilder.append(year);
	                i++;
	            }
		} catch (SWIFTMessageException e) {
			throw new RuntimeException("Error in getRuleYears", e);
		}
		Loggers.method().exit(LOG, yearsBuilder);
		return yearsBuilder.toString();
	}

	public void setAdaptor(SWIFTAdaptor adaptor) {
		this.adaptor = adaptor;
	}

	private String getRootError(Exception e) {

		String error = "";
		Throwable thr = e;
		while (thr.getCause() != null) {
			thr = thr.getCause();
		}
		error = thr.getMessage();
		return error;
	}

	public boolean validateFINMessage(String finMessage) {

		Loggers.method().enter(LOG, finMessage);

		boolean result = true;

		try {
			lastMessageResults = adaptor.validateRawMessage(finMessage);

		} catch (SWIFTMessageException e) {

			throw new RuntimeException("error occurred in validateMessage", e);
		}

		Loggers.method().exit(LOG);
		return result;
	}

	@Override
	public void setNotFullValidation() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setAllowLargeNarratives(boolean allow) {
		// TODO Auto-generated method stub

	}

	@Override
	public void summary(Object pane, StringBuilder messageBuffer, String rulesYear) throws Exception {
		Loggers.method().enter(LOG, rulesYear);

		String msgType = null;

		try {
			adaptor.generateIncomingMessageSummary(pane, messageBuffer.toString(), rulesYear);
			// msgType = pane.getMessageType().getEnValue();

			if (msgType != null && !msgType.isEmpty()) {
				if (msgType.startsWith("MT")) {
					msgType = msgType.substring(2);
				}
				// pane.getMessageType().setEnValue(msgType);
			}
		} catch (SWIFTMessageException e) {

			throw new Exception("error occurred in summary", e);
		}

		Loggers.method().exit(LOG);
	}

	@Override
	public SWIFTAdaptor getSWIFTAdaptor() {
		return this.adaptor;
	}

	@Override
	public MessageResults validateRawMessage(String rawMessage) throws Exception {
		
		  Loggers.method().enter(LOG, rawMessage);

	        MessageResults result = null;

	        try {
	            result = adaptor.validateRawMessage(rawMessage);

	        } catch (SWIFTMessageException e) {
	            throw new Exception("error occurred in validateMessage", e);
	        }

	        Loggers.method().exit(LOG);
	        return result;
	}

}
