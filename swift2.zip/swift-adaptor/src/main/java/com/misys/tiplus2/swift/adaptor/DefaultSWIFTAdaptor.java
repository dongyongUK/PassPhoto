package com.misys.tiplus2.swift.adaptor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.Directives;
import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.TransliterationDirectives;
import com.misys.tiplus2.swift.message.summary.SWIFTMessageSummary;
import com.misys.tiplus2.swift.rules.RulesetController;

/**
 *
 * @author DaiD1
 *
 */
public class DefaultSWIFTAdaptor implements SWIFTAdaptor {

	private static final Logger LOG = LoggerFactory.getLogger(DefaultSWIFTAdaptor.class);

	private RulesetController rulesetController;

	@Override
	public MessageResults convertToRawMessage(String ruleSetId, String type, Object source, Directives directives,
			boolean validate) {

		return rulesetController.convertToRawMessage(ruleSetId, type, source, directives, validate);
	}

	@Override
	public MessageResults convertFromRawMessage(String ruleSetId, Object target, String rawMessage,
			TransliterationDirectives directives) {

		return rulesetController.convertFromRawMessage(ruleSetId, target, rawMessage, directives);
	}

	@Override
	public void generateIncomingMessageSummary(Object target, String finMessage, String ruleSetId) {

		Loggers.method().enter(LOG, target, finMessage, ruleSetId);
		SWIFTMessageSummary messageSummary = rulesetController.processIncomingMessage(finMessage, ruleSetId);

		Loggers.method().exit(LOG);
	}

	@Override
	public boolean generateNextMessageSummary() {

		Loggers.method().enter(LOG);

		boolean result = false;

		Loggers.method().exit(LOG, result);
		return result;
	}

	@Override
	public List<String> getRulesetIds() {

		return rulesetController.getRulesetIds();
	}

	public void setRulesetController(RulesetController rulesetController) {
		this.rulesetController = rulesetController;
	}

	/**
	 * @since TSDS-42323
	 */
	@Override
	public MessageResults validateRawMessage(String rawMessage) {
		return rulesetController.validateRawMessage(rawMessage);
	}

	/**
	 * @since TSDS-42323
	 */
	@Override
	public String getSwiftVersion() {
		return rulesetController.getSwiftVersion();
	}
}
