package com.misys.tiplus2.swift.adaptor;

import com.misys.tiplus2.swift.message.summary.SWIFTMessageSummary;

/**
 * This interface provides a means to populate for summary data for each message and if necessary each component message.
 * 
 * @author DaiD1
 *
 */
public interface SWIFTSummaryPopulator {

    boolean transferSummary(SWIFTMessageSummary messageSummary);
    
    boolean transferNext();
}
