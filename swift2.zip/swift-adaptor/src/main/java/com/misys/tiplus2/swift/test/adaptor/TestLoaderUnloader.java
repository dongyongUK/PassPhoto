package com.misys.tiplus2.swift.test.adaptor;

import com.misys.tiplus2.swift.maps.MessageMapsLoader;
import com.misys.tiplus2.swift.maps.visitor.SWIFTMessageTargetResolver;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.message.MessageContainerLoaderUnloader;
import com.misys.tiplus2.swift.message.validation.rule.MessageRulesLoader;
import com.misys.tiplus2.swift.mx.message.MXMessageContainer;

public class TestLoaderUnloader implements MessageContainerLoaderUnloader {

	@Override
	public Object unloadSWIFTMessageContainer(MessageMapsLoader messageMapsLoader, SWIFTMessageTargetResolver resolver,
			MTMessageContainer message) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MTMessageContainer loadSWIFTMessageContainer(MessageMapsLoader messageMapsLoader, Object source,
			String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object unloadSWIFTMXMessageContainer(MessageMapsLoader messageMapsLoader, MessageRulesLoader rulesLoader,
			SWIFTMessageTargetResolver resolver, MXMessageContainer message) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MXMessageContainer loadSWIFTMXMessageContainer(MessageMapsLoader messageMapsLoader,
			MessageRulesLoader rulesLoader, Object source, String type) {
		// TODO Auto-generated method stub
		return null;
	}

}
