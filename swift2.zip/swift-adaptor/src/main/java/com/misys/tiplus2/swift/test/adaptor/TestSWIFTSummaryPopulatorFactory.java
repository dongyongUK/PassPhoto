package com.misys.tiplus2.swift.test.adaptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.adaptor.SWIFTSummaryPopulator;
import com.misys.tiplus2.swift.adaptor.SWIFTSummaryPopulatorFactory;

/**
 * 
 * @author DaiD1
 *
 */
public class TestSWIFTSummaryPopulatorFactory implements SWIFTSummaryPopulatorFactory {

    private static final Logger LOG = LoggerFactory.getLogger(TestSWIFTSummaryPopulatorFactory.class);

    @Override
    public SWIFTSummaryPopulator createSummaryPopulator(Object target) {

        Loggers.method().enter(LOG, target);

        TestSWIFTSummaryPopulator populator = new TestSWIFTSummaryPopulator(target);

        Loggers.method().exit(LOG, populator);

        return populator;
    }

}
