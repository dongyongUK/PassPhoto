package com.misys.tiplus2.swift.test.adaptor;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.swift.adaptor.SWIFTSummaryPopulator;
import com.misys.tiplus2.swift.message.summary.SWIFTMessageSummary;

/**
 * This provides a populator for the SwiftInPaneIF
 *
 * @author DaiD1
 *
 */
public class TestSWIFTSummaryPopulator implements SWIFTSummaryPopulator {

	protected static final Logger LOG = LoggerFactory.getLogger(TestSWIFTSummaryPopulator.class);

	private HashMap<String, String> targetPane;
	private SWIFTMessageSummary messageSummary;
	private int currentComponentNumber = -1;

	public TestSWIFTSummaryPopulator(Object target) {

		targetPane = (HashMap<String, String>) target;
	}

	@Override
	public boolean transferSummary(SWIFTMessageSummary summary) {

		Loggers.method().enter(LOG, summary);
		boolean result = false;

		messageSummary = summary;

		targetPane.put("InputReference", messageSummary.getInputReference());
		targetPane.put("SequenceNumber", messageSummary.getSequenceNumber());
		targetPane.put("MessageData", messageSummary.getMessageData());

		targetPane.put("Acknowledgement", String.valueOf(messageSummary.isAcknowledgmentMessage()));

		if (messageSummary.isAcknowledgmentMessage()) {
			targetPane.put("AcknowledgementResult", String.valueOf(messageSummary.getAcknowledgmentResult()));
		}

		String date = messageSummary.getDateSent();
		if (date != null) {
			targetPane.put("DateSent", formatDate(date));
		}

		String time = messageSummary.getTimeSent();
		targetPane.put("TimeSent", formatTime(time));

		targetPane.put("SenderAddress", messageSummary.getSenderAddress());
		targetPane.put("ReceiverAddress", messageSummary.getReceiverAddress());
		targetPane.put("Priority", messageSummary.getPriority());
		targetPane.put("Status", messageSummary.getStatus());
		targetPane.put("MessageType", messageSummary.getMessageType());
		String sTyp = messageSummary.getSubMessageType();
		if (sTyp != null && !sTyp.isEmpty()) {
			targetPane.put("SubMessageType", sTyp);
		}

		targetPane.put("PDEEntry", messageSummary.getPossibleDuplicateEmissionIndicator());
		targetPane.put("PDMEntry", messageSummary.getPossibleDuplicateMessageIndicator());
		targetPane.put("Reference", messageSummary.getReference());
		targetPane.put("RequiredMessageCount", messageSummary.getRequiredMessageCount());
		targetPane.put("MessageVersion", Integer.toString(messageSummary.getVersion()));

		if (messageSummary.getComponentMessageSummaries() != null
				&& messageSummary.getComponentMessageSummaries().size() > 0) {
			currentComponentNumber = 0;
			result = true;
		}

		if (targetPane.get("AmendmentNumber") != null) {
			targetPane.put("AmendmentNumber", Integer.toString(messageSummary.getAmendmentNumber()));
		}
		Loggers.method().exit(LOG, result);
		return result;
	}

	@Override
	public boolean transferNext() {

		Loggers.method().enter(LOG);
		boolean result = false;

		if (currentComponentNumber != -1) {
			SWIFTMessageSummary componentSummary = messageSummary.getComponentMessageSummaries()
					.get(currentComponentNumber);
			String type = componentSummary.getMessageType();
			if (type != null && type.startsWith("MT")) {
				type = type.substring(2);
			}
			targetPane.put("MessageType", type);
			targetPane.put("MessageData", componentSummary.getMessageData());
			targetPane.put("RequiredMessageCount", componentSummary.getRequiredMessageCount());
			targetPane.put("SequenceNumber", componentSummary.getSequenceNumber());
			targetPane.put("Status", componentSummary.getStatus());
			currentComponentNumber++;
			result = true;
			if (currentComponentNumber == messageSummary.getComponentMessageSummaries().size()) {
				currentComponentNumber = -1;
			}
		}
		Loggers.method().exit(LOG, result);
		return result;
	}

	private String formatDate(String date) {

		Loggers.method().enter(LOG, date);
		/*
		 * Date is in YYMMDD format - need to reformat to YYYY-MM-DD with 90 being the
		 * easliest year (representing 1990)
		 */
		String formated = date;
		if (Character.isDigit(date.charAt(0)) && Character.isDigit(date.charAt(1)) && Character.isDigit(date.charAt(2))
				&& Character.isDigit(date.charAt(3))) {
			formated = date.substring(0, 2) + "-" + date.substring(2, 4) + "-" + date.substring(4);

			if ("9".equals(date.substring(0, 1))) {
				formated = "19" + formated;
			} else {
				formated = "20" + formated;
			}
		}
		Loggers.method().exit(LOG, formated);
		return formated;
	}

	/**
	 * Check if the time is hh:mm format, if it is not, convert into it
	 * 
	 * @param time
	 * @return
	 */
	private String formatTime(String time) {
		Loggers.method().enter(LOG, time);
		String format = time;
		if (!time.contains(":") || !Character.isDigit(time.charAt(0)) || !Character.isDigit(time.charAt(1))
				|| !Character.isDigit(time.charAt(3)) || !Character.isDigit(time.charAt(4))) {
			format = time.substring(0, 2) + ":" + time.substring(2, 4);
		}
		Loggers.method().exit(LOG, format);
		return format;
	}
}
