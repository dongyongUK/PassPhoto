package com.misys.tiplus2.swift.test;

import org.junit.BeforeClass;

import com.misys.tiplus2.swift.adaptor.DefaultSWIFTAdaptor;
import com.misys.tiplus2.swift.rules.RulesetController;

public class UnitTestMT798ScoreSetup {

	static DefaultSWIFTAdaptor swiftAdaptor = null;
	static RulesetController rulesetController = null;

	final static String springContextFile = "classpath:unittestmt798ScoreSwiftSpringContext.xml";

	@BeforeClass
	public static void beforeClass() throws Exception {

		AdaptorAndController adaptorAndController = ContextTestHelper.getAdaptorAndController(springContextFile);
		swiftAdaptor = adaptorAndController.getAdaptor();
		rulesetController = adaptorAndController.getController();
	}

	public DefaultSWIFTAdaptor getSwiftAdaptor() {
		return swiftAdaptor;
	}

	public RulesetController getRulesetController() {
		return rulesetController;
	}
}
