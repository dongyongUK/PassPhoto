package com.misys.tiplus2.swift.test;

import com.misys.tiplus2.swift.adaptor.DefaultSWIFTAdaptor;
import com.misys.tiplus2.swift.rules.RulesetController;

public class AdaptorAndController {

	DefaultSWIFTAdaptor adaptor;
	RulesetController controller;

	public DefaultSWIFTAdaptor getAdaptor() {
		return adaptor;
	}

	public void setAdaptor(DefaultSWIFTAdaptor adaptor) {
		this.adaptor = adaptor;
	}

	public RulesetController getController() {
		return controller;
	}

	public void setController(RulesetController controller) {
		this.controller = controller;
	}

}
