package com.misys.tiplus2.swift.test.driver;

import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.adaptor.SWIFTAdaptor;

public interface TestSwiftDriver {

	SWIFTAdaptor getSWIFTAdaptor();
	
	void setFilter(String pattern) throws Exception;

	void setZFilter(String pattern) throws Exception;

	void setXFilter(String pattern) throws Exception;

	void setControl(String ref, String ignore, String trans, String excl) throws Exception;

	void setNotFullValidation();

	public void setAllowLargeNarratives(boolean allow);

	public String getRuleYears();

	boolean next() throws Exception;

	void summary(Object pane, StringBuilder messageBuffer, String rulesYear) throws Exception;

	boolean format(Object pane, String msgType, StringBuilder strBuilder, StringBuilder errorBuilder,
			boolean transliterate, boolean uppercase, boolean allowLargeNarrative, boolean validate, String rulesYear)
			throws Exception;

	boolean scanData(Object pane, String msgType, String msgData, StringBuilder error, boolean trans, String rulesYear)
			throws Exception;

	boolean scanData(Object pane, String msgType, String msgData, StringBuilder error, boolean trans, boolean validate,String rulesYear)
			throws Exception;
	
	boolean expand(StringBuilder shortMsg, StringBuilder expMsg, StringBuilder nwShort, StringBuilder nwExp,
	            boolean trans) throws Exception;
 
	MessageResults validateRawMessage(String rawMessage) throws Exception;
	

}
