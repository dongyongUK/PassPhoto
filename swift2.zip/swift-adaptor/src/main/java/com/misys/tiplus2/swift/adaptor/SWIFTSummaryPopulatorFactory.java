package com.misys.tiplus2.swift.adaptor;

/**
 * 
 * This interface provides a means to create a populator for summary data for
 * each message and if necessary each component message.
 * 
 * @author DaiD1
 *
 */
public interface SWIFTSummaryPopulatorFactory {
    
    SWIFTSummaryPopulator createSummaryPopulator(Object target);
}
