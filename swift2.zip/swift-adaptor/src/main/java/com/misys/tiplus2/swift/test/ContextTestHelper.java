package com.misys.tiplus2.swift.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.misys.tiplus2.foundations.lang.logging.Loggers;
import com.misys.tiplus2.foundations.spring.beans.BeanFactory;
import com.misys.tiplus2.swift.adaptor.DefaultSWIFTAdaptor;
import com.misys.tiplus2.swift.rules.RulesetController;

public class ContextTestHelper {

	private static final String SWIFT_ADAPTOR = "default.swift.adaptor";
	private static final String RULESET_CONTROLLER = "ruleset.controller";
	private static BeanFactory beanFactory;

	private static final Logger LOG = LoggerFactory.getLogger(ContextTestHelper.class);

	public static void initialiseSpringContext(String springContextFile) {

		try {
			ApplicationContext ctx = new ClassPathXmlApplicationContext(springContextFile);
			BeanFactory.getInstance().setApplicationContext(ctx);
		} catch (Exception e) {
			Loggers.general().info(LOG, "Exception :[{}]", e.getStackTrace().toString());
			System.out.println(e.getMessage());
		}
	}

	public static AdaptorAndController getAdaptorAndController(String springContextFile) {

		AdaptorAndController result = new AdaptorAndController();
		try {
			ApplicationContext ctx = new ClassPathXmlApplicationContext(springContextFile);
			beanFactory = BeanFactory.getInstance();
			beanFactory.setApplicationContext(ctx);
			DefaultSWIFTAdaptor adaptor = (DefaultSWIFTAdaptor) getBeanByName(SWIFT_ADAPTOR);
			RulesetController controller = (RulesetController)  getBeanByName(RULESET_CONTROLLER);
			result.setAdaptor(adaptor);
			result.setController(controller);
		} catch (Exception e) {
			Loggers.general().info(LOG, "Exception :[{}]", e.getStackTrace().toString());
			System.out.println(e.getMessage());
		}

		return result;
	}

	public static Object getBeanByName(String beanName) {

		Object result = null;
		try {
			result = beanFactory.getBean(beanName);
		} catch (Exception e) {
			Loggers.general().info(LOG, "Exception :[{}]", e.getStackTrace().toString());
			System.out.println(e.getMessage());
		}
		return result;
	}

}
