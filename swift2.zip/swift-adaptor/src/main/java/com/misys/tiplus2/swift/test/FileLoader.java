package com.misys.tiplus2.swift.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class FileLoader {

	static String fileDirectory = System.getProperty("user.dir") + "\\src\\test\\resources\\message";

	public static String loadFile(String fileName) throws Exception {

		File messageFile = new File(fileDirectory, fileName);

		InputStreamReader in = new InputStreamReader(new FileInputStream(messageFile));
		StringBuffer stringBuf = new StringBuffer();
		char[] charBuf = new char[4096];
		int len;

		while ((len = in.read(charBuf)) != -1) {
			stringBuf.append(charBuf, 0, len);
		}
		in.close();
		return stringBuf.toString();
	}

	public static String loadFile(String year, String fileName) throws Exception {

		File messageFile = new File(fileDirectory + "\\" + year, fileName);

		InputStreamReader in = new InputStreamReader(new FileInputStream(messageFile));
		StringBuffer stringBuf = new StringBuffer();
		char[] charBuf = new char[4096];
		int len;

		while ((len = in.read(charBuf)) != -1) {
			stringBuf.append(charBuf, 0, len);
		}
		in.close();
		return stringBuf.toString();
	}
}
