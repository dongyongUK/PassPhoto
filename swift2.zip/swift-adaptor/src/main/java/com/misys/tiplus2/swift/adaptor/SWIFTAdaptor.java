package com.misys.tiplus2.swift.adaptor;

import java.util.List;

import com.misys.tiplus2.swift.Directives;
import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.TransliterationDirectives;

/**
 * Interface for swift adaptor
 * 
 * @author DaiD1
 *
 */
public interface SWIFTAdaptor {

	MessageResults convertToRawMessage(String ruleSetId, String type, Object source, Directives directives,
			boolean validate);

	MessageResults convertFromRawMessage(String ruleSetId, Object target, String rawMessage,
			TransliterationDirectives directives);

	void generateIncomingMessageSummary(Object target, String rawMessage, String ruleSetId);

	boolean generateNextMessageSummary();

	List<String> getRulesetIds();

	MessageResults validateRawMessage(String rawMessage);

	String getSwiftVersion();
}
