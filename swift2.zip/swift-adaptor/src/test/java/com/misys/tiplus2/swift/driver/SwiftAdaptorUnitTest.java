package com.misys.tiplus2.swift.driver;

import org.junit.Before;
import org.junit.Test;

import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.adaptor.DefaultSWIFTAdaptor;
import com.misys.tiplus2.swift.test.FileLoader;
import com.misys.tiplus2.swift.test.UnitTestSetup;

public class SwiftAdaptorUnitTest extends UnitTestSetup {

	DefaultSWIFTAdaptor swiftAdaptor;

	@Before
	public void setUp() {
		swiftAdaptor = getSwiftAdaptor();
	}

	@Test
	public void test_ValidateMessage() throws Exception {
		String swiftFINMsg = FileLoader.loadFile("mx", "pacs.008.001.08-test.xml");
		MessageResults result = swiftAdaptor.validateRawMessage(swiftFINMsg);
		String rltMsg = result.getRawMessage();
	}
}
