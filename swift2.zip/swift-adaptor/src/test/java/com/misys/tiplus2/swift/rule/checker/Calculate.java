package com.misys.tiplus2.swift.rule.checker;

public class Calculate {

	public int add(int a, int b) {
		return a + b;
	}

	public int mul(int a, int b) {
		return a * b;
	}

	public String append(String a, String b) {
		return a + b;
	}

	public String hello() {
		return "Hello Calculate";
	}
	
	public String hello(String you) {
		return "Hello "+you;
	}
}
