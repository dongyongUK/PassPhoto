package com.misys.tiplus2.swift.lambda;

interface Sayable {
    public String say();
}

interface Addable {
    public int add(int a, int b);
}

public class Example2 {

    public static void main(String[] args) {  
        int w = 20;
        
        Drawable d2=()->{System.out.println("Drawing "+w);};
        
        d2.draw();
        
        Sayable s =()->{ return "Hello World";};
        
        System.out.println(s.say());
        
        Addable ad = (x, y)->(x+y);
        
        System.out.println(ad.add(2, 5));
    }
}
