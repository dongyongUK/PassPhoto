package com.misys.tiplus2.swift.message.rule.validation;

import static org.junit.Assert.assertFalse;

import org.junit.Before;
import org.junit.Test;

import com.misys.tiplus2.swift.Directives;
import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.adaptor.visitor.FieldEntryCollection;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.rules.RulesetController;
import com.misys.tiplus2.swift.test.FileLoader;
import com.misys.tiplus2.swift.test.UnitTestMT798ScoreSetup;

public class XMessagMT798748UnitTest extends UnitTestMT798ScoreSetup {

    Directives directives;
    RulesetController controller;
    FieldEntryCollection targetMessage;
    String msgString;

    @Before
    public void setUp() throws Exception {
        directives = new Directives();
        controller = getRulesetController();
        msgString = FileLoader.loadFile("2021", "MT798(748).txt");
    }

    @Test
    public void testcommandFormatNoError() throws Exception {
       
        MTMessageContainer message = new MTMessageContainer("MT798Score");
        MessageResults msgResult  = controller.convertFromRawMessage(msgString, message, msgString, null);
        //FINMessageResults msgResult = controller.convertFromFINMessage("2021", message, msgString, directives);
     
        MessageResults result = controller.convertToRawMessage("2021", "MT798Score",message, directives, true);  
       
        assertFalse(result.isMessageHasErrors());
    }
}