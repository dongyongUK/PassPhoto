package com.misys.tiplus2.swift.message.rule.validation;

import org.junit.Before;
import org.junit.Test;

import com.misys.tiplus2.swift.Directives;
import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.adaptor.visitor.FieldEntryCollection;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.rules.RulesetController;
import com.misys.tiplus2.swift.test.FileLoader;
import com.misys.tiplus2.swift.test.UnitTestMT798ScoreSetup;

public class XMessagMT798763767UnitTest extends UnitTestMT798ScoreSetup {

    Directives directives;
    RulesetController controller;
    FieldEntryCollection targetMessage;
    //String msgString;

    @Before
    public void setUp() throws Exception {
        directives = new Directives();
        controller = getRulesetController();
      
    }
    
    @Test
    public void testcommandFormatNoError() throws Exception {

        String msgString = FileLoader.loadFile("2021", "MT798(763)(767)In.txt");
       
        MTMessageContainer message = new MTMessageContainer("MT798Score");
        MessageResults msgResult = controller.convertFromRawMessage(msgString, message, msgString, null);
        //MessageResults msgResult = controller.convertFromFINMessage("2021", message, msgString, directives);
        
        //message = (SWIFTMessageContainer) msgResult.getTargetObject();
        //directives.setValidateMessage(true);
        MessageResults result = controller.convertToRawMessage("2021", "MT798Score", message, directives, true);
       
        String error = result.getErrorText();
    }
  
   
}