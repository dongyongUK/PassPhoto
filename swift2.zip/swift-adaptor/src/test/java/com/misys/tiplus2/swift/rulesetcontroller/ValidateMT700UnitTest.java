package com.misys.tiplus2.swift.rulesetcontroller;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.misys.tiplus2.swift.Directives;
import com.misys.tiplus2.swift.adaptor.visitor.FieldEntryCollection;
import com.misys.tiplus2.swift.message.DetailField;
import com.misys.tiplus2.swift.rules.RulesetController;
import com.misys.tiplus2.swift.test.FileLoader;
import com.misys.tiplus2.swift.test.UnitTestSetup;

public class ValidateMT700UnitTest extends UnitTestSetup {

	Directives directives;
	RulesetController controller;
	FieldEntryCollection targetMessage;

	@Before
	public void setUp() {
		directives = new Directives();
		controller = getRulesetController();
	}

	@Test
	public void test_ValidateMessage() throws Exception {

		String swiftFINMsg = FileLoader.loadFile("2021", "MT700Incoming.txt");
		//List<List<DetailField>> messageFieldList = controller.validateFINMessage(swiftFINMsg);
		//int size = messageFieldList.size();
	}

}
