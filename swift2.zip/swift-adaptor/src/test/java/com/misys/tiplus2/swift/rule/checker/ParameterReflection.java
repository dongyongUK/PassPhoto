package com.misys.tiplus2.swift.rule.checker;

import java.lang.reflect.Method;

public class ParameterReflection {

	public static void main(String[] args) {

		String className = "java.lang.String";
		String methodName = "startsWith";
		String initialValue ="ABChello THis is my String";
		String arg1 = "ABC";
		
		try {
			

			// no parameter
			Class nonparams[] = {};

			// String parameter
			Class[] paramString = new Class[1];
			paramString[0] = String.class;

			// String parameters
			Class[] paramStrings = new Class[2];
			paramStrings[0] = String.class;
			paramStrings[1] = String.class;

			// int parameters
			Class[] paramInts = new Class[2];
			paramInts[0] = Integer.TYPE;
			paramInts[1] = Integer.TYPE;
			
            ////////////////////////////////////
			// create class
			Class<?> clazz = Class.forName(className);
			// create instance (with no argument for constructor)
			// Object obj = cls.newInstance();			
		    Object obj = clazz.getConstructor(String.class).newInstance(new Object[] {initialValue});
						
			// get method
			Method method = clazz.getDeclaredMethod(methodName, paramString);
			Object[] arguments = new Object[1];
			arguments[0]=arg1;
			Object result = method.invoke(obj, arguments);
			
            if (result instanceof Boolean) {
            	boolean out = (Boolean) result;
            	System.out.println(out);
            }
            
            /////////////////////////////
            Class<?> clz = Class.forName("com.misys.tiplus2.swift.rule.checker.Calculate");
            Object object = clz.newInstance();
            method = clz.getDeclaredMethod("hello", nonparams);
            result = method.invoke(object,null);
            System.out.println(result);
            
            method = clz.getDeclaredMethod("hello", paramString);
            result = method.invoke(object, new String("World"));
            System.out.println(result);
            
            method = clz.getDeclaredMethod("add", paramInts);
            arguments = new Object[2];
            arguments[0]=5;
            arguments[1]=3;
            result = method.invoke(object, arguments);
            System.out.println(result);
            
            method = clz.getDeclaredMethod("append", paramStrings);
            arguments = new Object[2];
            arguments[0]="This is the first part. ";
            arguments[1]="This is the second part.";
            result = method.invoke(object, arguments);
            System.out.println(result);         
            
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
