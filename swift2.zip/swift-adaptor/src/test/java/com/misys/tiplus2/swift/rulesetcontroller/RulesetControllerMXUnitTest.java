package com.misys.tiplus2.swift.rulesetcontroller;

import org.junit.Before;
import org.junit.Test;

import com.misys.tiplus2.swift.Directives;
import com.misys.tiplus2.swift.MessageResults;
import com.misys.tiplus2.swift.adaptor.visitor.FieldEntryCollection;
import com.misys.tiplus2.swift.message.MTMessageContainer;
import com.misys.tiplus2.swift.rules.RulesetController;
import com.misys.tiplus2.swift.test.FileLoader;
import com.misys.tiplus2.swift.test.UnitTestSetup;

public class RulesetControllerMXUnitTest extends UnitTestSetup {

	Directives directives;
	RulesetController controller;
	FieldEntryCollection targetMessage;

	@Before
	public void setUp() {
		directives = new Directives();
		controller = getRulesetController();
	}

	@Test
	public void test_ConvertFromRawMessage() throws Exception {

		String swiftFINMsg = FileLoader.loadFile("2021", "MT760In9.txt");

		// targetMessage = new FieldEntryCollection();
		MessageResults result = controller.convertFromRawMessage("2021", targetMessage, swiftFINMsg, null);

		String sgortMsg = result.getShortRawMessage();

	}

	@Test
	public void test_ConvertToRawMessage() throws Exception {
		String swiftFINMsg = FileLoader.loadFile("2021", "MT760In9.txt");

		MTMessageContainer message = new MTMessageContainer("MT760");
		MessageResults msgResult = controller.convertFromRawMessage("2021", message, swiftFINMsg, null);
		// MessageResults msgResult = controller.convertFromFINMessage("2021", message,
		// swiftFINMsg, directives);

		// directives.setValidateMessage(true);
		// MessageResults result = controller.convertToFINMessage("2021", "MT760",
		// message, directives);
		MessageResults result = controller.convertToRawMessage("2021", "MT760", message, directives, true);
	}

	@Test
	public void test_ValidateMessage() throws Exception {

		String swiftFINMsg = FileLoader.loadFile("2021", "MT760In9.txt");

		// directives.setValidateMessage(true);
		MessageResults result = controller.convertFromRawMessage("2021", targetMessage, swiftFINMsg, null);

		// String sgortMsg = result.getShortFINMessage();
		// List<List<DetailField>> messageFieldList = result.getMessageFieldList();
		// int size = messageFieldList.size();
	}

}
