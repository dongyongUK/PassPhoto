package com.misys.tiplus2.swift.lambda;

public class Example4 {

    interface FieldValidator{
       
        public boolean validate(String ...arg);
    }
    
    public static void main(String[] args) {  
        
        FieldValidator fv1 = (pars)-> {
           boolean result = false;
           if (pars.length>1) {
               if (pars[0].length() <pars[1].length()) {
                   result = true;
               }
           }
          return result;
        };
        
        String[] vs = {"ABC","DEFG"};
        System.out.println(fv1.validate(vs));
        
        String[] vs2 = {"ABCDEFG","DEFG"};
        System.out.println(fv1.validate(vs2));
        
        FieldValidator fv2 = (pars)-> {
            boolean result = false;
            if (pars.length>3) {
                if (pars[0].length() <pars[1].length() && pars[2].equals(pars[3])) {
                    result = true;
                }
                
            }
           return result;
         };
        
         String[] vs3 = {"ABC","DEFG", "sin", "sin"};
         System.out.println(fv2.validate(vs3));
         
         String[] vs4 = {"ABC","DEFG", "sin", "cos"};
         System.out.println(fv2.validate(vs4));
    }
}
