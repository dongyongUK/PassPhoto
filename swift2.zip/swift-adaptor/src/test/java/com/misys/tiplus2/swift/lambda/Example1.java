package com.misys.tiplus2.swift.lambda;

interface Drawable{
    public void draw();
}
public class Example1 {

    public static void main(String[] args) {
         int w=10;
         
         Drawable drawSomething = new Drawable() {
            public void draw()
            {System.out.println("Drawing: "+w);}
         };
         
         drawSomething.draw();
    }
}
